--
-- PostgreSQL database dump
--

\restrict QTJ5zy0KPH5PRhFLeMbWGZ38AO1u4vYoBtU6jWi6Kxeqc0Y3YHCTaTnWIKCuyXx

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounting_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounting_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "autoGenerateInvoice" boolean DEFAULT false NOT NULL,
    "companyName" text,
    "companyTaxId" text,
    "companyTaxOffice" text,
    "companyAddress" text,
    "companyPhone" text,
    "companyEmail" text,
    provider text DEFAULT 'NONE'::text NOT NULL,
    "autoSync" boolean DEFAULT false NOT NULL,
    "parasutCompanyId" text,
    "parasutClientId" text,
    "parasutClientSecret" text,
    "parasutUsername" text,
    "parasutPassword" text,
    "logoApiUrl" text,
    "logoUsername" text,
    "logoPassword" text,
    "logoFirmNumber" text,
    "foribaApiUrl" text,
    "foribaUsername" text,
    "foribaPassword" text,
    "foribaServiceType" text,
    "invoicePrefix" text DEFAULT 'FTR'::text NOT NULL,
    "nextInvoiceNumber" integer DEFAULT 1 NOT NULL,
    "defaultPaymentTermDays" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.accounting_settings OWNER TO postgres;

--
-- Name: analytics_heatmap_cache; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_heatmap_cache (
    id text NOT NULL,
    "startTime" timestamp(3) without time zone NOT NULL,
    "endTime" timestamp(3) without time zone NOT NULL,
    granularity text NOT NULL,
    "gridWidth" integer NOT NULL,
    "gridDepth" integer NOT NULL,
    "cellSize" double precision NOT NULL,
    "heatmapData" jsonb NOT NULL,
    "maxValue" double precision NOT NULL,
    "minValue" double precision NOT NULL,
    metric text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.analytics_heatmap_cache OWNER TO postgres;

--
-- Name: analytics_insights; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_insights (
    id text NOT NULL,
    type text NOT NULL,
    category text DEFAULT 'OPERATIONAL'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    recommendation text NOT NULL,
    "affectedTableIds" text[] DEFAULT ARRAY[]::text[],
    "affectedAreaData" jsonb,
    "supportingData" jsonb,
    "potentialImpact" text,
    "confidenceScore" double precision DEFAULT 0.8 NOT NULL,
    status text DEFAULT 'NEW'::text NOT NULL,
    "reviewedAt" timestamp(3) without time zone,
    "reviewedBy" text,
    "implementedAt" timestamp(3) without time zone,
    "dismissedReason" text,
    "validFrom" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "validUntil" timestamp(3) without time zone,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.analytics_insights OWNER TO postgres;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_keys (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    "keyHash" text NOT NULL,
    "keyPrefix" text NOT NULL,
    scopes text[],
    "webhookUrl" text,
    "webhookEvents" text[] DEFAULT ARRAY[]::text[],
    "isActive" boolean DEFAULT true NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "lastUsedAt" timestamp(3) without time zone,
    "usageCount" integer DEFAULT 0 NOT NULL,
    "ipWhitelist" text[] DEFAULT ARRAY[]::text[],
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.api_keys OWNER TO postgres;

--
-- Name: attendances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attendances (
    id text NOT NULL,
    date date NOT NULL,
    "clockIn" timestamp(3) without time zone NOT NULL,
    "clockOut" timestamp(3) without time zone,
    "breakStart" timestamp(3) without time zone,
    "breakEnd" timestamp(3) without time zone,
    "totalWorkedMinutes" integer DEFAULT 0 NOT NULL,
    "totalBreakMinutes" integer DEFAULT 0 NOT NULL,
    "overtimeMinutes" integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'CLOCKED_IN'::text NOT NULL,
    "isLate" boolean DEFAULT false NOT NULL,
    "lateMinutes" integer DEFAULT 0 NOT NULL,
    notes text,
    "shiftAssignmentId" text,
    "userId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.attendances OWNER TO postgres;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    action text NOT NULL,
    "entityType" text NOT NULL,
    "entityId" text,
    "actorId" text NOT NULL,
    "actorEmail" text NOT NULL,
    "previousData" jsonb,
    "newData" jsonb,
    metadata jsonb,
    "targetTenantId" text,
    "targetTenantName" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: bill_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bill_requests (
    id text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "sessionId" text NOT NULL,
    "tenantId" text NOT NULL,
    "tableId" text,
    "acknowledgedAt" timestamp(3) without time zone,
    "acknowledgedById" text,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.bill_requests OWNER TO postgres;

--
-- Name: cameras; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cameras (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "streamUrl" text NOT NULL,
    "streamType" text DEFAULT 'RTSP'::text NOT NULL,
    "calibrationData" jsonb,
    "voxelX" double precision,
    "voxelY" double precision DEFAULT 2.5,
    "voxelZ" double precision,
    "rotationY" double precision DEFAULT 0,
    fov double precision DEFAULT 90,
    status text DEFAULT 'OFFLINE'::text NOT NULL,
    "lastSeenAt" timestamp(3) without time zone,
    "errorMessage" text,
    "edgeDeviceId" text,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.cameras OWNER TO postgres;

--
-- Name: cash_drawer_movements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cash_drawer_movements (
    id text NOT NULL,
    type text NOT NULL,
    amount numeric(10,2) NOT NULL,
    reason text,
    notes text,
    "denominationBreakdown" jsonb,
    "zReportId" text,
    "userId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.cash_drawer_movements OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: commissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.commissions (
    id text NOT NULL,
    amount numeric(10,2) NOT NULL,
    type text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    period text NOT NULL,
    "tenantId" text,
    "leadId" text,
    notes text,
    "marketingUserId" text NOT NULL,
    "approvedAt" timestamp(3) without time zone,
    "paidAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.commissions OWNER TO postgres;

--
-- Name: contact_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact_messages (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    message text NOT NULL,
    status text DEFAULT 'NEW'::text NOT NULL,
    "adminNotes" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.contact_messages OWNER TO postgres;

--
-- Name: customer_referrals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_referrals (
    id text NOT NULL,
    "referrerId" text NOT NULL,
    "referredId" text NOT NULL,
    "referralCode" text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "referrerReward" integer DEFAULT 0 NOT NULL,
    "referredReward" integer DEFAULT 0 NOT NULL,
    "rewardedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone
);


ALTER TABLE public.customer_referrals OWNER TO postgres;

--
-- Name: customer_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_sessions (
    id text NOT NULL,
    "sessionId" text NOT NULL,
    "customerId" text,
    "tableId" text,
    phone text,
    "isActive" boolean DEFAULT true NOT NULL,
    "userAgent" text,
    "ipAddress" text,
    latitude double precision,
    longitude double precision,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "lastActivity" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.customer_sessions OWNER TO postgres;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id text NOT NULL,
    name text NOT NULL,
    email text,
    phone text,
    "phoneVerified" boolean DEFAULT false NOT NULL,
    "loyaltyPoints" integer DEFAULT 0 NOT NULL,
    "loyaltyTier" text DEFAULT 'BRONZE'::text NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[],
    notes text,
    "referralCode" text,
    "referredBy" text,
    "totalOrders" integer DEFAULT 0 NOT NULL,
    "totalSpent" numeric(10,2) DEFAULT 0 NOT NULL,
    "averageOrder" numeric(10,2) DEFAULT 0 NOT NULL,
    birthday timestamp(3) without time zone,
    preferences jsonb,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "lastVisit" timestamp(3) without time zone
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: delivery_platform_configs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.delivery_platform_configs (
    id text NOT NULL,
    platform text NOT NULL,
    "isEnabled" boolean DEFAULT false NOT NULL,
    credentials jsonb,
    "accessToken" text,
    "tokenExpiresAt" timestamp(3) without time zone,
    "remoteRestaurantId" text,
    "restaurantOpen" boolean DEFAULT false NOT NULL,
    "lastOrderPollAt" timestamp(3) without time zone,
    "lastMenuSyncAt" timestamp(3) without time zone,
    "lastError" text,
    "lastErrorAt" timestamp(3) without time zone,
    "errorCount" integer DEFAULT 0 NOT NULL,
    "autoAccept" boolean DEFAULT true NOT NULL,
    "notifySound" text,
    "deletedAt" timestamp(3) without time zone,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.delivery_platform_configs OWNER TO postgres;

--
-- Name: delivery_platform_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.delivery_platform_logs (
    id text NOT NULL,
    platform text NOT NULL,
    direction text NOT NULL,
    action text NOT NULL,
    "orderId" text,
    "externalId" text,
    request jsonb,
    response jsonb,
    "statusCode" integer,
    success boolean NOT NULL,
    error text,
    "retryCount" integer DEFAULT 0 NOT NULL,
    "maxRetries" integer DEFAULT 3 NOT NULL,
    "nextRetryAt" timestamp(3) without time zone,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.delivery_platform_logs OWNER TO postgres;

--
-- Name: desktop_releases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.desktop_releases (
    id text NOT NULL,
    version text NOT NULL,
    "releaseTag" text NOT NULL,
    published boolean DEFAULT false NOT NULL,
    "pubDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "windowsUrl" text,
    "windowsSignature" text,
    "macArmUrl" text,
    "macArmSignature" text,
    "macIntelUrl" text,
    "macIntelSignature" text,
    "linuxUrl" text,
    "linuxSignature" text,
    "releaseNotes" text NOT NULL,
    changelog text,
    "downloadCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.desktop_releases OWNER TO postgres;

--
-- Name: edge_devices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.edge_devices (
    id text NOT NULL,
    "deviceId" text NOT NULL,
    name text NOT NULL,
    description text,
    "hardwareType" text,
    "firmwareVersion" text,
    "ipAddress" text,
    "macAddress" text,
    status text DEFAULT 'OFFLINE'::text NOT NULL,
    "lastHeartbeat" timestamp(3) without time zone,
    "lastSeenAt" timestamp(3) without time zone,
    "errorMessage" text,
    capabilities jsonb,
    config jsonb,
    "cpuUsage" double precision,
    "memoryUsage" double precision,
    "gpuUsage" double precision,
    temperature double precision,
    uptime integer,
    "framesProcessed" bigint DEFAULT 0 NOT NULL,
    "detectionsTotal" bigint DEFAULT 0 NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.edge_devices OWNER TO postgres;

--
-- Name: ingredient_movements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ingredient_movements (
    id text NOT NULL,
    type text NOT NULL,
    quantity numeric(10,3) NOT NULL,
    "costPerUnit" numeric(10,4),
    notes text,
    "referenceType" text,
    "referenceId" text,
    "createdById" text,
    "stockItemId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.ingredient_movements OWNER TO postgres;

--
-- Name: integration_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integration_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "integrationType" text NOT NULL,
    provider text NOT NULL,
    name text NOT NULL,
    config jsonb NOT NULL,
    "isEnabled" boolean DEFAULT false NOT NULL,
    "isConfigured" boolean DEFAULT false NOT NULL,
    "lastSyncedAt" timestamp(3) without time zone,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.integration_settings OWNER TO postgres;

--
-- Name: invoice_counters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice_counters (
    scope text NOT NULL,
    sequence integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.invoice_counters OWNER TO postgres;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    "paymentId" text,
    "invoiceNumber" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    tax numeric(10,2) DEFAULT 0 NOT NULL,
    total numeric(10,2) NOT NULL,
    currency text DEFAULT 'TRY'::text NOT NULL,
    "periodStart" timestamp(3) without time zone NOT NULL,
    "periodEnd" timestamp(3) without time zone NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "paidAt" timestamp(3) without time zone,
    "voidedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    description text,
    notes text,
    "pdfUrl" text
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: lead_activities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lead_activities (
    id text NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    description text,
    outcome text,
    duration integer,
    "leadId" text NOT NULL,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.lead_activities OWNER TO postgres;

--
-- Name: lead_offers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lead_offers (
    id text NOT NULL,
    "planId" text,
    "customPrice" numeric(10,2),
    discount numeric(5,2),
    "trialDays" integer,
    notes text,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    "validUntil" timestamp(3) without time zone,
    "sentAt" timestamp(3) without time zone,
    "respondedAt" timestamp(3) without time zone,
    "leadId" text NOT NULL,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.lead_offers OWNER TO postgres;

--
-- Name: leads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.leads (
    id text NOT NULL,
    "businessName" text NOT NULL,
    "contactPerson" text NOT NULL,
    phone text,
    whatsapp text,
    email text,
    address text,
    city text,
    region text,
    "businessType" text NOT NULL,
    "tableCount" integer,
    "branchCount" integer,
    "currentSystem" text,
    source text NOT NULL,
    status text DEFAULT 'NEW'::text NOT NULL,
    "lostReason" text,
    notes text,
    "nextFollowUp" timestamp(3) without time zone,
    priority text DEFAULT 'MEDIUM'::text NOT NULL,
    "assignedToId" text,
    "convertedTenantId" text,
    "convertedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.leads OWNER TO postgres;

--
-- Name: loyalty_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.loyalty_transactions (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "customerId" text NOT NULL,
    type text NOT NULL,
    points integer NOT NULL,
    description text NOT NULL,
    "orderId" text,
    "orderNumber" text,
    "orderAmount" numeric(10,2),
    "referredCustomerId" text,
    "balanceBefore" integer NOT NULL,
    "balanceAfter" integer NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.loyalty_transactions OWNER TO postgres;

--
-- Name: marketing_notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marketing_notifications (
    id text NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    "isRead" boolean DEFAULT false NOT NULL,
    metadata jsonb,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.marketing_notifications OWNER TO postgres;

--
-- Name: marketing_tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marketing_tasks (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    type text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    priority text DEFAULT 'MEDIUM'::text NOT NULL,
    "dueDate" timestamp(3) without time zone NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "leadId" text,
    "assignedToId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.marketing_tasks OWNER TO postgres;

--
-- Name: marketing_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marketing_users (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    phone text,
    avatar text,
    role text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "lastLogin" timestamp(3) without time zone,
    "lastLoginIp" text,
    "failedLogins" integer DEFAULT 0 NOT NULL,
    "lockedUntil" timestamp(3) without time zone,
    "tokenVersion" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.marketing_users OWNER TO postgres;

--
-- Name: menu_item_mappings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_item_mappings (
    id text NOT NULL,
    platform text NOT NULL,
    "externalItemId" text NOT NULL,
    "externalData" jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastSyncedAt" timestamp(3) without time zone,
    "productId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.menu_item_mappings OWNER TO postgres;

--
-- Name: modifier_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.modifier_groups (
    id text NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "selectionType" text DEFAULT 'SINGLE'::text NOT NULL,
    "minSelections" integer DEFAULT 0 NOT NULL,
    "maxSelections" integer,
    "isRequired" boolean DEFAULT false NOT NULL,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.modifier_groups OWNER TO postgres;

--
-- Name: modifiers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.modifiers (
    id text NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "priceAdjustment" numeric(10,2) DEFAULT 0 NOT NULL,
    "isAvailable" boolean DEFAULT true NOT NULL,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "groupId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.modifiers OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    type text NOT NULL,
    data jsonb,
    "userId" text,
    "tenantId" text NOT NULL,
    "isGlobal" boolean DEFAULT false NOT NULL,
    priority text DEFAULT 'NORMAL'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: occupancy_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.occupancy_records (
    id text NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "trackingId" text NOT NULL,
    "positionX" double precision NOT NULL,
    "positionZ" double precision NOT NULL,
    "positionY" double precision DEFAULT 0 NOT NULL,
    state text NOT NULL,
    confidence double precision DEFAULT 0.9 NOT NULL,
    "tableId" text,
    "cameraId" text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.occupancy_records OWNER TO postgres;

--
-- Name: order_item_modifiers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_item_modifiers (
    id text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    "priceAdjustment" numeric(10,2) NOT NULL,
    "orderItemId" text NOT NULL,
    "modifierId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.order_item_modifiers OWNER TO postgres;

--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id text NOT NULL,
    quantity integer NOT NULL,
    "unitPrice" numeric(10,2) NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    "modifierTotal" numeric(10,2) DEFAULT 0 NOT NULL,
    "taxRate" integer DEFAULT 10 NOT NULL,
    "taxAmount" numeric(10,2) DEFAULT 0 NOT NULL,
    notes text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "orderId" text NOT NULL,
    "productId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id text NOT NULL,
    "orderNumber" text NOT NULL,
    type text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "totalAmount" numeric(10,2) NOT NULL,
    discount numeric(10,2) DEFAULT 0 NOT NULL,
    "finalAmount" numeric(10,2) NOT NULL,
    "taxAmount" numeric(10,2) DEFAULT 0 NOT NULL,
    notes text,
    "customerName" text,
    source text,
    "externalOrderId" text,
    "externalData" jsonb,
    "sessionId" text,
    "customerPhone" text,
    "requiresApproval" boolean DEFAULT false NOT NULL,
    "approvedAt" timestamp(3) without time zone,
    "stockDeducted" boolean DEFAULT false NOT NULL,
    "tableId" text,
    "customerId" text,
    "userId" text,
    "approvedById" text,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "preparingAt" timestamp(3) without time zone,
    "readyAt" timestamp(3) without time zone
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: page_views; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.page_views (
    id text NOT NULL,
    page text NOT NULL,
    path text NOT NULL,
    referrer text,
    country text,
    "countryCode" text,
    city text,
    region text,
    "sessionId" text,
    "userAgent" text,
    "ipHash" text,
    "deviceType" text,
    browser text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.page_views OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id text NOT NULL,
    amount numeric(10,2) NOT NULL,
    method text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "transactionId" text,
    "idempotencyKey" text,
    notes text,
    "tenantId" text NOT NULL,
    "orderId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "paidAt" timestamp(3) without time zone
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: phone_verifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.phone_verifications (
    id text NOT NULL,
    phone text NOT NULL,
    code text NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "sessionId" text,
    "tenantId" text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    "maxAttempts" integer DEFAULT 3 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "verifiedAt" timestamp(3) without time zone
);


ALTER TABLE public.phone_verifications OWNER TO postgres;

--
-- Name: pos_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pos_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "enableTablelessMode" boolean DEFAULT false NOT NULL,
    "enableTwoStepCheckout" boolean DEFAULT false NOT NULL,
    "showProductImages" boolean DEFAULT true NOT NULL,
    "enableCustomerOrdering" boolean DEFAULT true NOT NULL,
    "defaultMapView" text DEFAULT '2d'::text NOT NULL,
    "requireServedForDineInPayment" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.pos_settings OWNER TO postgres;

--
-- Name: product_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_images (
    id text NOT NULL,
    url text NOT NULL,
    filename text NOT NULL,
    size integer NOT NULL,
    "mimeType" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_images OWNER TO postgres;

--
-- Name: product_modifier_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_modifier_groups (
    id text NOT NULL,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "productId" text NOT NULL,
    "groupId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_modifier_groups OWNER TO postgres;

--
-- Name: product_to_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_to_images (
    id text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "productId" text NOT NULL,
    "imageId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_to_images OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    image text,
    "isAvailable" boolean DEFAULT true NOT NULL,
    "stockTracked" boolean DEFAULT false NOT NULL,
    "currentStock" integer DEFAULT 0 NOT NULL,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "taxRate" integer DEFAULT 10 NOT NULL,
    "categoryId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: public_reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.public_reviews (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    restaurant text,
    avatar text,
    rating integer NOT NULL,
    comment text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "approvedAt" timestamp(3) without time zone,
    country text,
    city text,
    "isVerified" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.public_reviews OWNER TO postgres;

--
-- Name: public_stats_cache; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.public_stats_cache (
    id text DEFAULT 'main'::text NOT NULL,
    "totalViews" integer DEFAULT 0 NOT NULL,
    "uniqueVisitors" integer DEFAULT 0 NOT NULL,
    "totalReviews" integer DEFAULT 0 NOT NULL,
    "averageRating" double precision DEFAULT 0 NOT NULL,
    "totalTenants" integer DEFAULT 0 NOT NULL,
    "totalOrders" integer DEFAULT 0 NOT NULL,
    "totalRevenue" double precision DEFAULT 0 NOT NULL,
    "countryDistribution" jsonb,
    "cityDistribution" jsonb,
    "viewsToday" integer DEFAULT 0 NOT NULL,
    "viewsThisWeek" integer DEFAULT 0 NOT NULL,
    "viewsThisMonth" integer DEFAULT 0 NOT NULL,
    "lastUpdated" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.public_stats_cache OWNER TO postgres;

--
-- Name: purchase_order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase_order_items (
    id text NOT NULL,
    "quantityOrdered" numeric(10,3) NOT NULL,
    "quantityReceived" numeric(10,3) DEFAULT 0 NOT NULL,
    "unitPrice" numeric(10,4) NOT NULL,
    "purchaseOrderId" text NOT NULL,
    "stockItemId" text NOT NULL
);


ALTER TABLE public.purchase_order_items OWNER TO postgres;

--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase_orders (
    id text NOT NULL,
    "orderNumber" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    notes text,
    "expectedDate" timestamp(3) without time zone,
    "createdById" text,
    "supplierId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "submittedAt" timestamp(3) without time zone,
    "receivedAt" timestamp(3) without time zone
);


ALTER TABLE public.purchase_orders OWNER TO postgres;

--
-- Name: qr_menu_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qr_menu_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "primaryColor" text DEFAULT '#3B82F6'::text NOT NULL,
    "secondaryColor" text DEFAULT '#1F2937'::text NOT NULL,
    "backgroundColor" text DEFAULT '#F9FAFB'::text NOT NULL,
    "fontFamily" text DEFAULT 'Inter'::text NOT NULL,
    "logoUrl" text,
    "showRestaurantInfo" boolean DEFAULT true NOT NULL,
    "showPrices" boolean DEFAULT true NOT NULL,
    "showDescription" boolean DEFAULT true NOT NULL,
    "showImages" boolean DEFAULT true NOT NULL,
    "layoutStyle" text DEFAULT 'GRID'::text NOT NULL,
    "itemsPerRow" integer DEFAULT 2 NOT NULL,
    "enableTableQR" boolean DEFAULT true NOT NULL,
    "tableQRMessage" text DEFAULT 'Scan to view our menu'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.qr_menu_settings OWNER TO postgres;

--
-- Name: recipe_ingredients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recipe_ingredients (
    id text NOT NULL,
    quantity numeric(10,3) NOT NULL,
    "recipeId" text NOT NULL,
    "stockItemId" text NOT NULL
);


ALTER TABLE public.recipe_ingredients OWNER TO postgres;

--
-- Name: recipes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recipes (
    id text NOT NULL,
    name text,
    notes text,
    yield integer DEFAULT 1 NOT NULL,
    "productId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.recipes OWNER TO postgres;

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.refresh_tokens (
    id text NOT NULL,
    "tokenHash" text NOT NULL,
    "userId" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "revokedAt" timestamp(3) without time zone,
    ip text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.refresh_tokens OWNER TO postgres;

--
-- Name: reservation_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reservation_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "isEnabled" boolean DEFAULT true NOT NULL,
    "requireApproval" boolean DEFAULT true NOT NULL,
    "timeSlotInterval" integer DEFAULT 30 NOT NULL,
    "minAdvanceBooking" integer DEFAULT 60 NOT NULL,
    "maxAdvanceDays" integer DEFAULT 30 NOT NULL,
    "defaultDuration" integer DEFAULT 90 NOT NULL,
    "operatingHours" jsonb,
    "maxGuestsPerReservation" integer DEFAULT 20 NOT NULL,
    "maxReservationsPerSlot" integer,
    "bannerImageUrl" text,
    "bannerTitle" text,
    "bannerDescription" text,
    "customMessage" text,
    "allowCancellation" boolean DEFAULT true NOT NULL,
    "cancellationDeadline" integer DEFAULT 120 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.reservation_settings OWNER TO postgres;

--
-- Name: reservations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reservations (
    id text NOT NULL,
    "reservationNumber" text NOT NULL,
    date date NOT NULL,
    "startTime" text NOT NULL,
    "endTime" text NOT NULL,
    "guestCount" integer NOT NULL,
    notes text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "customerName" text NOT NULL,
    "customerPhone" text NOT NULL,
    "customerEmail" text,
    "adminNotes" text,
    "confirmedAt" timestamp(3) without time zone,
    "confirmedById" text,
    "rejectionReason" text,
    "cancelledAt" timestamp(3) without time zone,
    "cancelledBy" text,
    "seatedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "tableId" text,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.reservations OWNER TO postgres;

--
-- Name: reserved_subdomains; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reserved_subdomains (
    id text NOT NULL,
    subdomain text NOT NULL,
    reason text NOT NULL,
    "reservedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "availableAfter" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.reserved_subdomains OWNER TO postgres;

--
-- Name: restaurant_layouts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.restaurant_layouts (
    id text NOT NULL,
    name text DEFAULT 'Main Floor'::text NOT NULL,
    width integer DEFAULT 32 NOT NULL,
    height integer DEFAULT 8 NOT NULL,
    depth integer DEFAULT 32 NOT NULL,
    "worldData" jsonb NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.restaurant_layouts OWNER TO postgres;

--
-- Name: sales_invoice_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_invoice_items (
    id text NOT NULL,
    description text NOT NULL,
    quantity integer NOT NULL,
    "unitPrice" numeric(10,2) NOT NULL,
    "taxRate" integer DEFAULT 10 NOT NULL,
    "taxAmount" numeric(10,2) NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    total numeric(10,2) NOT NULL,
    "invoiceId" text NOT NULL
);


ALTER TABLE public.sales_invoice_items OWNER TO postgres;

--
-- Name: sales_invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_invoices (
    id text NOT NULL,
    "invoiceNumber" text NOT NULL,
    type text DEFAULT 'SALES'::text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    "customerName" text,
    "customerPhone" text,
    "customerEmail" text,
    "customerTaxId" text,
    "customerTaxOffice" text,
    subtotal numeric(10,2) NOT NULL,
    "taxAmount" numeric(10,2) NOT NULL,
    "totalAmount" numeric(10,2) NOT NULL,
    discount numeric(10,2) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'TRY'::text NOT NULL,
    "taxBreakdown" jsonb,
    "orderId" text,
    "paymentMethod" text,
    "externalId" text,
    "externalProvider" text,
    "externalStatus" text,
    "syncedAt" timestamp(3) without time zone,
    "syncError" text,
    "pdfUrl" text,
    "issueDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.sales_invoices OWNER TO postgres;

--
-- Name: shift_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shift_assignments (
    id text NOT NULL,
    date date NOT NULL,
    status text DEFAULT 'SCHEDULED'::text NOT NULL,
    notes text,
    "userId" text NOT NULL,
    "shiftTemplateId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.shift_assignments OWNER TO postgres;

--
-- Name: shift_swap_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shift_swap_requests (
    id text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    reason text,
    "targetRespondedAt" timestamp(3) without time zone,
    "targetApproved" boolean,
    "requesterId" text NOT NULL,
    "targetId" text NOT NULL,
    "requesterAssignmentId" text NOT NULL,
    "targetAssignmentId" text NOT NULL,
    "approvedById" text,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.shift_swap_requests OWNER TO postgres;

--
-- Name: shift_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shift_templates (
    id text NOT NULL,
    name text NOT NULL,
    "startTime" text NOT NULL,
    "endTime" text NOT NULL,
    color text DEFAULT '#3B82F6'::text NOT NULL,
    "gracePeriodMinutes" integer DEFAULT 15 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.shift_templates OWNER TO postgres;

--
-- Name: sms_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sms_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "isEnabled" boolean DEFAULT false NOT NULL,
    "smsOnReservationCreated" boolean DEFAULT true NOT NULL,
    "smsOnReservationConfirmed" boolean DEFAULT true NOT NULL,
    "smsOnReservationRejected" boolean DEFAULT true NOT NULL,
    "smsOnReservationCancelled" boolean DEFAULT true NOT NULL,
    "smsOnOrderCreated" boolean DEFAULT true NOT NULL,
    "smsOnOrderApproved" boolean DEFAULT true NOT NULL,
    "smsOnOrderPreparing" boolean DEFAULT true NOT NULL,
    "smsOnOrderReady" boolean DEFAULT true NOT NULL,
    "smsOnOrderCancelled" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.sms_settings OWNER TO postgres;

--
-- Name: stock_batches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_batches (
    id text NOT NULL,
    "batchNumber" text,
    quantity numeric(10,3) NOT NULL,
    "costPerUnit" numeric(10,4) NOT NULL,
    "receivedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiryDate" timestamp(3) without time zone,
    "stockItemId" text NOT NULL,
    "purchaseOrderItemId" text,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.stock_batches OWNER TO postgres;

--
-- Name: stock_count_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_count_items (
    id text NOT NULL,
    "expectedQty" numeric(10,3) NOT NULL,
    "countedQty" numeric(10,3),
    variance numeric(10,3),
    "stockCountId" text NOT NULL,
    "stockItemId" text NOT NULL
);


ALTER TABLE public.stock_count_items OWNER TO postgres;

--
-- Name: stock_counts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_counts (
    id text NOT NULL,
    name text,
    status text DEFAULT 'IN_PROGRESS'::text NOT NULL,
    notes text,
    "createdById" text,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "completedAt" timestamp(3) without time zone
);


ALTER TABLE public.stock_counts OWNER TO postgres;

--
-- Name: stock_item_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_item_categories (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    color text,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.stock_item_categories OWNER TO postgres;

--
-- Name: stock_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_items (
    id text NOT NULL,
    name text NOT NULL,
    sku text,
    unit text NOT NULL,
    description text,
    "currentStock" numeric(10,3) DEFAULT 0 NOT NULL,
    "minStock" numeric(10,3) DEFAULT 0 NOT NULL,
    "costPerUnit" numeric(10,4) DEFAULT 0 NOT NULL,
    "trackExpiry" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "categoryId" text,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.stock_items OWNER TO postgres;

--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_movements (
    id text NOT NULL,
    type text NOT NULL,
    quantity integer NOT NULL,
    reason text,
    notes text,
    "productId" text NOT NULL,
    "userId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.stock_movements OWNER TO postgres;

--
-- Name: stock_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "enableAutoDeduction" boolean DEFAULT true NOT NULL,
    "deductOnStatus" text DEFAULT 'PREPARING'::text NOT NULL,
    "lowStockAlertDays" integer DEFAULT 3 NOT NULL,
    "poNumberPrefix" text DEFAULT 'PO'::text NOT NULL,
    "allowNegativeStock" boolean DEFAULT false NOT NULL,
    "poSequence" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.stock_settings OWNER TO postgres;

--
-- Name: subscription_payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscription_payments (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'TRY'::text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "paymentProvider" text NOT NULL,
    "externalReference" text,
    "paymentMethod" text,
    last4 text,
    "cardBrand" text,
    "failureCode" text,
    "failureMessage" text,
    "retryCount" integer DEFAULT 0 NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "refundedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.subscription_payments OWNER TO postgres;

--
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscription_plans (
    id text NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "monthlyPrice" numeric(10,2) NOT NULL,
    "yearlyPrice" numeric(10,2) NOT NULL,
    currency text DEFAULT 'TRY'::text NOT NULL,
    "trialDays" integer DEFAULT 0 NOT NULL,
    "maxUsers" integer DEFAULT 1 NOT NULL,
    "maxTables" integer DEFAULT 5 NOT NULL,
    "maxProducts" integer DEFAULT 50 NOT NULL,
    "maxCategories" integer DEFAULT 10 NOT NULL,
    "maxMonthlyOrders" integer DEFAULT 100 NOT NULL,
    "advancedReports" boolean DEFAULT false NOT NULL,
    "multiLocation" boolean DEFAULT false NOT NULL,
    "customBranding" boolean DEFAULT false NOT NULL,
    "apiAccess" boolean DEFAULT false NOT NULL,
    "prioritySupport" boolean DEFAULT false NOT NULL,
    "inventoryTracking" boolean DEFAULT false NOT NULL,
    "kdsIntegration" boolean DEFAULT true NOT NULL,
    "reservationSystem" boolean DEFAULT false NOT NULL,
    "personnelManagement" boolean DEFAULT false NOT NULL,
    "deliveryIntegration" boolean DEFAULT false NOT NULL,
    "discountPercentage" integer,
    "discountLabel" text,
    "discountStartDate" timestamp(3) without time zone,
    "discountEndDate" timestamp(3) without time zone,
    "isDiscountActive" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.subscription_plans OWNER TO postgres;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscriptions (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "planId" text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "billingCycle" text NOT NULL,
    "paymentProvider" text NOT NULL,
    "startDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "currentPeriodStart" timestamp(3) without time zone NOT NULL,
    "currentPeriodEnd" timestamp(3) without time zone NOT NULL,
    "cancelledAt" timestamp(3) without time zone,
    "endedAt" timestamp(3) without time zone,
    "isTrialPeriod" boolean DEFAULT false NOT NULL,
    "trialStart" timestamp(3) without time zone,
    "trialEnd" timestamp(3) without time zone,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'TRY'::text NOT NULL,
    "autoRenew" boolean DEFAULT true NOT NULL,
    "cancelAtPeriodEnd" boolean DEFAULT false NOT NULL,
    "cancellationReason" text,
    "scheduledDowngradePlanId" text,
    "scheduledDowngradeBillingCycle" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.subscriptions OWNER TO postgres;

--
-- Name: super_admins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.super_admins (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "twoFactorSecret" text,
    "twoFactorEnabled" boolean DEFAULT false NOT NULL,
    "pendingTwoFactorSecret" text,
    "backupCodes" text[] DEFAULT ARRAY[]::text[],
    "lastTotpStep" bigint,
    "lastTotpStepExpiresAt" timestamp(3) without time zone,
    "tokenVersion" integer DEFAULT 0 NOT NULL,
    "lastLogin" timestamp(3) without time zone,
    "lastLoginIp" text,
    "failedLogins" integer DEFAULT 0 NOT NULL,
    "lockedUntil" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.super_admins OWNER TO postgres;

--
-- Name: supplier_stock_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.supplier_stock_items (
    id text NOT NULL,
    "supplierSku" text,
    "unitPrice" numeric(10,4) NOT NULL,
    "isPreferred" boolean DEFAULT false NOT NULL,
    "supplierId" text NOT NULL,
    "stockItemId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.supplier_stock_items OWNER TO postgres;

--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.suppliers (
    id text NOT NULL,
    name text NOT NULL,
    "contactName" text,
    email text,
    phone text,
    address text,
    "paymentTerms" text,
    notes text,
    "isActive" boolean DEFAULT true NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.suppliers OWNER TO postgres;

--
-- Name: table_analytics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.table_analytics (
    id text NOT NULL,
    date date NOT NULL,
    "tableId" text NOT NULL,
    "totalOccupiedMinutes" integer DEFAULT 0 NOT NULL,
    "totalDiningMinutes" integer DEFAULT 0 NOT NULL,
    "totalIdleMinutes" integer DEFAULT 0 NOT NULL,
    "totalEmptyMinutes" integer DEFAULT 0 NOT NULL,
    "totalSessions" integer DEFAULT 0 NOT NULL,
    "avgSessionDuration" double precision,
    "avgDiningDuration" double precision,
    "avgIdleDuration" double precision,
    "revenueGenerated" numeric(10,2) DEFAULT 0 NOT NULL,
    "ordersCount" integer DEFAULT 0 NOT NULL,
    "avgOrderValue" numeric(10,2),
    "revenuePerMinute" numeric(10,4),
    "utilizationScore" double precision,
    "peakHours" jsonb,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.table_analytics OWNER TO postgres;

--
-- Name: tables; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tables (
    id text NOT NULL,
    number text NOT NULL,
    capacity integer NOT NULL,
    section text,
    status text DEFAULT 'AVAILABLE'::text NOT NULL,
    "groupId" text,
    "voxelX" integer,
    "voxelY" integer DEFAULT 0,
    "voxelZ" integer,
    "voxelRotation" integer DEFAULT 0,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.tables OWNER TO postgres;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    id text NOT NULL,
    name text NOT NULL,
    subdomain text,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "currentPlanId" text,
    "paymentRegion" text DEFAULT 'INTERNATIONAL'::text NOT NULL,
    "trialUsed" boolean DEFAULT false NOT NULL,
    "trialStartedAt" timestamp(3) without time zone,
    "trialEndsAt" timestamp(3) without time zone,
    currency text DEFAULT 'TRY'::text NOT NULL,
    latitude double precision,
    longitude double precision,
    "locationRadius" integer DEFAULT 100 NOT NULL,
    "closingTime" text DEFAULT '23:00'::text,
    timezone text DEFAULT 'UTC'::text NOT NULL,
    "reportEmailEnabled" boolean DEFAULT false NOT NULL,
    "reportEmails" text[] DEFAULT ARRAY[]::text[],
    "wifiSsid" text,
    "wifiPassword" text,
    "socialInstagram" text,
    "socialFacebook" text,
    "socialTwitter" text,
    "socialTiktok" text,
    "socialYoutube" text,
    "socialWhatsapp" text,
    "featureOverrides" jsonb,
    "limitOverrides" jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: traffic_flow_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.traffic_flow_records (
    id text NOT NULL,
    "hourBucket" timestamp(3) without time zone NOT NULL,
    "cellX" integer NOT NULL,
    "cellZ" integer NOT NULL,
    "cellSize" double precision DEFAULT 1.0 NOT NULL,
    "personCount" integer NOT NULL,
    "avgDwellTime" double precision,
    entrances integer DEFAULT 0 NOT NULL,
    exits integer DEFAULT 0 NOT NULL,
    "flowDirections" jsonb,
    "tenantId" text NOT NULL
);


ALTER TABLE public.traffic_flow_records OWNER TO postgres;

--
-- Name: user_activities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_activities (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tenantId" text NOT NULL,
    action text NOT NULL,
    ip text,
    "userAgent" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_activities OWNER TO postgres;

--
-- Name: user_notification_reads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_notification_reads (
    id text NOT NULL,
    "notificationId" text NOT NULL,
    "userId" text NOT NULL,
    "readAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_notification_reads OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    role text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "approvedAt" timestamp(3) without time zone,
    "approvedById" text,
    "reactivatedAt" timestamp(3) without time zone,
    "reactivatedById" text,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "emailVerificationCodeHash" text,
    "emailVerificationCodeExpires" timestamp(3) without time zone,
    "resetTokenHash" text,
    "resetTokenExpiry" timestamp(3) without time zone,
    "tokenVersion" integer DEFAULT 0 NOT NULL,
    avatar text,
    phone text,
    "lastLogin" timestamp(3) without time zone,
    "googleId" text,
    "appleId" text,
    "authProvider" text DEFAULT 'local'::text NOT NULL,
    "onboardingData" jsonb,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: waiter_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.waiter_requests (
    id text NOT NULL,
    message text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "sessionId" text NOT NULL,
    "tenantId" text NOT NULL,
    "tableId" text,
    "acknowledgedAt" timestamp(3) without time zone,
    "acknowledgedById" text,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.waiter_requests OWNER TO postgres;

--
-- Name: waste_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.waste_logs (
    id text NOT NULL,
    quantity numeric(10,3) NOT NULL,
    reason text NOT NULL,
    notes text,
    cost numeric(10,4),
    "createdById" text,
    "stockItemId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.waste_logs OWNER TO postgres;

--
-- Name: z_reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.z_reports (
    id text NOT NULL,
    "reportNumber" text NOT NULL,
    "reportDate" timestamp(3) without time zone NOT NULL,
    "closingTime" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "closingType" text DEFAULT 'MANUAL'::text NOT NULL,
    "closedById" text NOT NULL,
    "branchName" text,
    "terminalId" text,
    "totalSales" numeric(10,2) NOT NULL,
    "totalOrders" integer NOT NULL,
    "totalDiscount" numeric(10,2) DEFAULT 0 NOT NULL,
    "totalRefunds" numeric(10,2) DEFAULT 0 NOT NULL,
    "netSales" numeric(10,2) NOT NULL,
    "totalTax" numeric(10,2) DEFAULT 0 NOT NULL,
    "taxBreakdown" jsonb,
    "dineInSales" numeric(10,2) DEFAULT 0 NOT NULL,
    "dineInOrders" integer DEFAULT 0 NOT NULL,
    "takeawaySales" numeric(10,2) DEFAULT 0 NOT NULL,
    "takeawayOrders" integer DEFAULT 0 NOT NULL,
    "deliverySales" numeric(10,2) DEFAULT 0 NOT NULL,
    "deliveryOrders" integer DEFAULT 0 NOT NULL,
    "cashPayments" numeric(10,2) DEFAULT 0 NOT NULL,
    "cashPaymentCount" integer DEFAULT 0 NOT NULL,
    "cardPayments" numeric(10,2) DEFAULT 0 NOT NULL,
    "cardPaymentCount" integer DEFAULT 0 NOT NULL,
    "digitalPayments" numeric(10,2) DEFAULT 0 NOT NULL,
    "digitalPaymentCount" integer DEFAULT 0 NOT NULL,
    "openingCash" numeric(10,2) NOT NULL,
    "expectedCash" numeric(10,2) NOT NULL,
    "countedCash" numeric(10,2) NOT NULL,
    "cashDifference" numeric(10,2) NOT NULL,
    "cashInOut" numeric(10,2) DEFAULT 0 NOT NULL,
    "cancelledOrders" integer DEFAULT 0 NOT NULL,
    "cancelledOrdersAmount" numeric(10,2) DEFAULT 0 NOT NULL,
    "refundedPayments" integer DEFAULT 0 NOT NULL,
    "refundedAmount" numeric(10,2) DEFAULT 0 NOT NULL,
    "staffPerformance" jsonb,
    "categoryBreakdown" jsonb,
    "topProducts" jsonb,
    "openChecks" integer DEFAULT 0 NOT NULL,
    "openChecksAmount" numeric(10,2) DEFAULT 0 NOT NULL,
    notes text,
    "systemGenerated" boolean DEFAULT false NOT NULL,
    "pdfExported" boolean DEFAULT false NOT NULL,
    "pdfUrl" text,
    "excelExported" boolean DEFAULT false NOT NULL,
    "excelUrl" text,
    "emailSent" boolean DEFAULT false NOT NULL,
    "emailSentAt" timestamp(3) without time zone,
    "emailRecipients" text[] DEFAULT ARRAY[]::text[],
    "emailError" text,
    "isFinalized" boolean DEFAULT false NOT NULL,
    "finalizedAt" timestamp(3) without time zone,
    "finalizedById" text,
    "payloadHash" text,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.z_reports OWNER TO postgres;

--
-- Data for Name: accounting_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounting_settings (id, "tenantId", "autoGenerateInvoice", "companyName", "companyTaxId", "companyTaxOffice", "companyAddress", "companyPhone", "companyEmail", provider, "autoSync", "parasutCompanyId", "parasutClientId", "parasutClientSecret", "parasutUsername", "parasutPassword", "logoApiUrl", "logoUsername", "logoPassword", "logoFirmNumber", "foribaApiUrl", "foribaUsername", "foribaPassword", "foribaServiceType", "invoicePrefix", "nextInvoiceNumber", "defaultPaymentTermDays", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: analytics_heatmap_cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_heatmap_cache (id, "startTime", "endTime", granularity, "gridWidth", "gridDepth", "cellSize", "heatmapData", "maxValue", "minValue", metric, "tenantId", "createdAt", "expiresAt") FROM stdin;
\.


--
-- Data for Name: analytics_insights; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_insights (id, type, category, severity, title, description, recommendation, "affectedTableIds", "affectedAreaData", "supportingData", "potentialImpact", "confidenceScore", status, "reviewedAt", "reviewedBy", "implementedAt", "dismissedReason", "validFrom", "validUntil", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_keys (id, "tenantId", name, "keyHash", "keyPrefix", scopes, "webhookUrl", "webhookEvents", "isActive", "expiresAt", "lastUsedAt", "usageCount", "ipWhitelist", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: attendances; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attendances (id, date, "clockIn", "clockOut", "breakStart", "breakEnd", "totalWorkedMinutes", "totalBreakMinutes", "overtimeMinutes", status, "isLate", "lateMinutes", notes, "shiftAssignmentId", "userId", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, action, "entityType", "entityId", "actorId", "actorEmail", "previousData", "newData", metadata, "targetTenantId", "targetTenantName", "createdAt") FROM stdin;
\.


--
-- Data for Name: bill_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bill_requests (id, status, "sessionId", "tenantId", "tableId", "acknowledgedAt", "acknowledgedById", "completedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: cameras; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cameras (id, name, description, "streamUrl", "streamType", "calibrationData", "voxelX", "voxelY", "voxelZ", "rotationY", fov, status, "lastSeenAt", "errorMessage", "edgeDeviceId", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: cash_drawer_movements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cash_drawer_movements (id, type, amount, reason, notes, "denominationBreakdown", "zReportId", "userId", "tenantId", "createdAt") FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, description, "displayOrder", "isActive", "tenantId", "createdAt", "updatedAt") FROM stdin;
cdeb05b0-70f0-4c4c-ac11-4ca7fbc97297	1	1	0	t	6e75a35e-f17f-4748-807a-6cd6ca3a648d	2026-04-21 17:54:29.809	2026-04-21 17:54:29.809
\.


--
-- Data for Name: commissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.commissions (id, amount, type, status, period, "tenantId", "leadId", notes, "marketingUserId", "approvedAt", "paidAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: contact_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact_messages (id, name, email, phone, message, status, "adminNotes", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: customer_referrals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_referrals (id, "referrerId", "referredId", "referralCode", status, "referrerReward", "referredReward", "rewardedAt", "createdAt", "completedAt") FROM stdin;
\.


--
-- Data for Name: customer_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_sessions (id, "sessionId", "customerId", "tableId", phone, "isActive", "userAgent", "ipAddress", latitude, longitude, "expiresAt", "lastActivity", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (id, name, email, phone, "phoneVerified", "loyaltyPoints", "loyaltyTier", tags, notes, "referralCode", "referredBy", "totalOrders", "totalSpent", "averageOrder", birthday, preferences, "tenantId", "createdAt", "updatedAt", "lastVisit") FROM stdin;
\.


--
-- Data for Name: delivery_platform_configs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.delivery_platform_configs (id, platform, "isEnabled", credentials, "accessToken", "tokenExpiresAt", "remoteRestaurantId", "restaurantOpen", "lastOrderPollAt", "lastMenuSyncAt", "lastError", "lastErrorAt", "errorCount", "autoAccept", "notifySound", "deletedAt", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: delivery_platform_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.delivery_platform_logs (id, platform, direction, action, "orderId", "externalId", request, response, "statusCode", success, error, "retryCount", "maxRetries", "nextRetryAt", "tenantId", "createdAt") FROM stdin;
\.


--
-- Data for Name: desktop_releases; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.desktop_releases (id, version, "releaseTag", published, "pubDate", "windowsUrl", "windowsSignature", "macArmUrl", "macArmSignature", "macIntelUrl", "macIntelSignature", "linuxUrl", "linuxSignature", "releaseNotes", changelog, "downloadCount", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: edge_devices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.edge_devices (id, "deviceId", name, description, "hardwareType", "firmwareVersion", "ipAddress", "macAddress", status, "lastHeartbeat", "lastSeenAt", "errorMessage", capabilities, config, "cpuUsage", "memoryUsage", "gpuUsage", temperature, uptime, "framesProcessed", "detectionsTotal", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ingredient_movements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ingredient_movements (id, type, quantity, "costPerUnit", notes, "referenceType", "referenceId", "createdById", "stockItemId", "tenantId", "createdAt") FROM stdin;
\.


--
-- Data for Name: integration_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.integration_settings (id, "tenantId", "integrationType", provider, name, config, "isEnabled", "isConfigured", "lastSyncedAt", notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: invoice_counters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice_counters (scope, sequence) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (id, "subscriptionId", "paymentId", "invoiceNumber", status, subtotal, tax, total, currency, "periodStart", "periodEnd", "dueDate", "paidAt", "voidedAt", "createdAt", "updatedAt", description, notes, "pdfUrl") FROM stdin;
\.


--
-- Data for Name: lead_activities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lead_activities (id, type, title, description, outcome, duration, "leadId", "createdById", "createdAt") FROM stdin;
\.


--
-- Data for Name: lead_offers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lead_offers (id, "planId", "customPrice", discount, "trialDays", notes, status, "validUntil", "sentAt", "respondedAt", "leadId", "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.leads (id, "businessName", "contactPerson", phone, whatsapp, email, address, city, region, "businessType", "tableCount", "branchCount", "currentSystem", source, status, "lostReason", notes, "nextFollowUp", priority, "assignedToId", "convertedTenantId", "convertedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: loyalty_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.loyalty_transactions (id, "tenantId", "customerId", type, points, description, "orderId", "orderNumber", "orderAmount", "referredCustomerId", "balanceBefore", "balanceAfter", metadata, "createdAt") FROM stdin;
\.


--
-- Data for Name: marketing_notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marketing_notifications (id, type, title, message, "isRead", metadata, "userId", "createdAt") FROM stdin;
\.


--
-- Data for Name: marketing_tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marketing_tasks (id, title, description, type, status, priority, "dueDate", "completedAt", "leadId", "assignedToId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: marketing_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marketing_users (id, email, password, "firstName", "lastName", phone, avatar, role, status, "lastLogin", "lastLoginIp", "failedLogins", "lockedUntil", "tokenVersion", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: menu_item_mappings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_item_mappings (id, platform, "externalItemId", "externalData", "isActive", "lastSyncedAt", "productId", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: modifier_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.modifier_groups (id, name, "displayName", description, "selectionType", "minSelections", "maxSelections", "isRequired", "displayOrder", "isActive", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: modifiers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.modifiers (id, name, "displayName", description, "priceAdjustment", "isAvailable", "displayOrder", "groupId", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, title, message, type, data, "userId", "tenantId", "isGlobal", priority, "createdAt", "expiresAt") FROM stdin;
\.


--
-- Data for Name: occupancy_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.occupancy_records (id, "timestamp", "trackingId", "positionX", "positionZ", "positionY", state, confidence, "tableId", "cameraId", "tenantId") FROM stdin;
\.


--
-- Data for Name: order_item_modifiers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_item_modifiers (id, quantity, "priceAdjustment", "orderItemId", "modifierId", "createdAt") FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, quantity, "unitPrice", subtotal, "modifierTotal", "taxRate", "taxAmount", notes, status, "orderId", "productId", "createdAt", "updatedAt") FROM stdin;
043a3b09-fae9-4b1a-9b5a-4b78a33b10eb	1	1.00	1.00	0.00	10	0.09	\N	PENDING	6e5b6465-ab62-49c3-b2db-9d9b16fa78b9	f35f747e-5776-4365-b153-10aaa73b10d7	2026-04-21 17:55:02.898	2026-04-21 17:55:02.898
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, "orderNumber", type, status, "totalAmount", discount, "finalAmount", "taxAmount", notes, "customerName", source, "externalOrderId", "externalData", "sessionId", "customerPhone", "requiresApproval", "approvedAt", "stockDeducted", "tableId", "customerId", "userId", "approvedById", "tenantId", "createdAt", "updatedAt", "paidAt", "preparingAt", "readyAt") FROM stdin;
6e5b6465-ab62-49c3-b2db-9d9b16fa78b9	ORD-1776794102895-DD03B8C4	DINE_IN	READY	1.00	0.00	1.00	0.09	\N	\N	\N	\N	\N	\N	\N	f	\N	f	64d91332-13b8-4db8-a936-3cc294a09c77	\N	dbcdfe84-49b8-4716-9531-4fa9ff0cbc88	\N	6e75a35e-f17f-4748-807a-6cd6ca3a648d	2026-04-21 17:55:02.898	2026-04-21 17:55:10.267	\N	2026-04-21 17:55:08.517	2026-04-21 17:55:10.266
\.


--
-- Data for Name: page_views; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.page_views (id, page, path, referrer, country, "countryCode", city, region, "sessionId", "userAgent", "ipHash", "deviceType", browser, "createdAt") FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, amount, method, status, "transactionId", "idempotencyKey", notes, "tenantId", "orderId", "createdAt", "paidAt") FROM stdin;
\.


--
-- Data for Name: phone_verifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.phone_verifications (id, phone, code, verified, "expiresAt", "sessionId", "tenantId", attempts, "maxAttempts", "createdAt", "verifiedAt") FROM stdin;
\.


--
-- Data for Name: pos_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pos_settings (id, "tenantId", "enableTablelessMode", "enableTwoStepCheckout", "showProductImages", "enableCustomerOrdering", "defaultMapView", "requireServedForDineInPayment", "createdAt", "updatedAt") FROM stdin;
3db14e5a-3138-44a8-bca9-6ca6c0c2a0d1	6e75a35e-f17f-4748-807a-6cd6ca3a648d	f	t	t	t	2d	f	2026-04-20 13:59:40.667	2026-04-20 13:59:40.667
\.


--
-- Data for Name: product_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_images (id, url, filename, size, "mimeType", "tenantId", "createdAt") FROM stdin;
9ba3a041-7b47-47ac-bd57-a8794c38fd1a	https://staging.hummytummy.com/uploads/products/6e75a35e-f17f-4748-807a-6cd6ca3a648d/6704893e-14f6-4160-a841-5f72919646eb.jpg	nohutlu-tarhana-corbasi-d.jpg	104571	image/jpeg	6e75a35e-f17f-4748-807a-6cd6ca3a648d	2026-04-21 17:54:43.901
\.


--
-- Data for Name: product_modifier_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_modifier_groups (id, "displayOrder", "productId", "groupId", "createdAt") FROM stdin;
\.


--
-- Data for Name: product_to_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_to_images (id, "order", "productId", "imageId", "createdAt") FROM stdin;
d56f7c62-fb3e-4ae5-b32c-177d39ec1fc8	0	f35f747e-5776-4365-b153-10aaa73b10d7	9ba3a041-7b47-47ac-bd57-a8794c38fd1a	2026-04-21 17:54:50.575
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, name, description, price, image, "isAvailable", "stockTracked", "currentStock", "displayOrder", "taxRate", "categoryId", "tenantId", "createdAt", "updatedAt") FROM stdin;
f35f747e-5776-4365-b153-10aaa73b10d7	1	1	1.00		t	f	1	0	10	cdeb05b0-70f0-4c4c-ac11-4ca7fbc97297	6e75a35e-f17f-4748-807a-6cd6ca3a648d	2026-04-21 17:54:40.334	2026-04-21 17:54:50.558
\.


--
-- Data for Name: public_reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.public_reviews (id, name, email, restaurant, avatar, rating, comment, status, "approvedAt", country, city, "isVerified", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: public_stats_cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.public_stats_cache (id, "totalViews", "uniqueVisitors", "totalReviews", "averageRating", "totalTenants", "totalOrders", "totalRevenue", "countryDistribution", "cityDistribution", "viewsToday", "viewsThisWeek", "viewsThisMonth", "lastUpdated") FROM stdin;
main	0	0	0	0	1	1	1	{}	{}	0	0	0	2026-04-23 10:40:00.021
\.


--
-- Data for Name: purchase_order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase_order_items (id, "quantityOrdered", "quantityReceived", "unitPrice", "purchaseOrderId", "stockItemId") FROM stdin;
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase_orders (id, "orderNumber", status, notes, "expectedDate", "createdById", "supplierId", "tenantId", "createdAt", "updatedAt", "submittedAt", "receivedAt") FROM stdin;
\.


--
-- Data for Name: qr_menu_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qr_menu_settings (id, "tenantId", "primaryColor", "secondaryColor", "backgroundColor", "fontFamily", "logoUrl", "showRestaurantInfo", "showPrices", "showDescription", "showImages", "layoutStyle", "itemsPerRow", "enableTableQR", "tableQRMessage", "createdAt", "updatedAt") FROM stdin;
1b38ebdd-84a4-41dd-863d-463b0699585e	6e75a35e-f17f-4748-807a-6cd6ca3a648d	#3B82F6	#1F2937	#F9FAFB	Inter	\N	t	t	t	t	GRID	2	t	Scan to view our menu	2026-04-20 13:59:43.566	2026-04-20 13:59:43.566
\.


--
-- Data for Name: recipe_ingredients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recipe_ingredients (id, quantity, "recipeId", "stockItemId") FROM stdin;
\.


--
-- Data for Name: recipes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recipes (id, name, notes, yield, "productId", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.refresh_tokens (id, "tokenHash", "userId", "expiresAt", "revokedAt", ip, "userAgent", "createdAt") FROM stdin;
aa84210f-3c57-42aa-83cc-6a5427d16eec	1b46a6b4c9740a6db2b58b46a2b2a649bb19e3bfbcc2c5bd055a030ebd166d6f	dbcdfe84-49b8-4716-9531-4fa9ff0cbc88	2026-05-23 10:27:05	2026-04-23 10:31:27.029	\N	\N	2026-04-23 10:27:06.016
591126cd-9195-413a-8f8c-7732ce2c952e	0ab2e0d8175d0bd872efde3b4de341882219af3b8c9810ebe4c9e7f0b20aea03	dbcdfe84-49b8-4716-9531-4fa9ff0cbc88	2026-05-20 13:59:34	2026-04-23 10:31:27.04	\N	\N	2026-04-20 13:59:34.582
0bba9040-f8ab-491c-bd3e-1720f3cac6a7	03c58faa955f567e6e1fae8adb213eaf5ef38465b8fb037a4a609009e7ea8223	dbcdfe84-49b8-4716-9531-4fa9ff0cbc88	2026-05-21 16:58:53	2026-04-23 10:31:27.04	\N	\N	2026-04-21 16:58:53.359
e4e34fd4-742d-4a90-9d09-757f800a04b3	3d217cefc2c87b28dcf9f64efe3e2b4585fb42c5756ba2837a59c0be2fb3e7f5	dbcdfe84-49b8-4716-9531-4fa9ff0cbc88	2026-05-22 22:55:46	2026-04-23 10:31:27.04	\N	\N	2026-04-22 22:55:46.353
bc57910a-a0f6-45f5-8e61-4841aa5b03e3	b7b5902a511939af63ff608017b8da15d57b22725db0d6b6a510df6b1bfeb023	dbcdfe84-49b8-4716-9531-4fa9ff0cbc88	2026-05-23 10:31:27	2026-04-23 10:31:28.549	172.69.199.190	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 OPR/130.0.0.0	2026-04-23 10:31:27.04
e772025d-e967-480f-bfb2-5a3424c4f996	2ee0efd0235172190c0f13f99f78e95b76f94c16e76e1725e90e5db8895f9f1c	dbcdfe84-49b8-4716-9531-4fa9ff0cbc88	2026-05-23 10:31:33	\N	\N	\N	2026-04-23 10:31:33.159
\.


--
-- Data for Name: reservation_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reservation_settings (id, "tenantId", "isEnabled", "requireApproval", "timeSlotInterval", "minAdvanceBooking", "maxAdvanceDays", "defaultDuration", "operatingHours", "maxGuestsPerReservation", "maxReservationsPerSlot", "bannerImageUrl", "bannerTitle", "bannerDescription", "customMessage", "allowCancellation", "cancellationDeadline", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: reservations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reservations (id, "reservationNumber", date, "startTime", "endTime", "guestCount", notes, status, "customerName", "customerPhone", "customerEmail", "adminNotes", "confirmedAt", "confirmedById", "rejectionReason", "cancelledAt", "cancelledBy", "seatedAt", "completedAt", "tableId", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: reserved_subdomains; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reserved_subdomains (id, subdomain, reason, "reservedAt", "availableAfter") FROM stdin;
\.


--
-- Data for Name: restaurant_layouts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.restaurant_layouts (id, name, width, height, depth, "worldData", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: sales_invoice_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_invoice_items (id, description, quantity, "unitPrice", "taxRate", "taxAmount", subtotal, total, "invoiceId") FROM stdin;
\.


--
-- Data for Name: sales_invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_invoices (id, "invoiceNumber", type, status, "customerName", "customerPhone", "customerEmail", "customerTaxId", "customerTaxOffice", subtotal, "taxAmount", "totalAmount", discount, currency, "taxBreakdown", "orderId", "paymentMethod", "externalId", "externalProvider", "externalStatus", "syncedAt", "syncError", "pdfUrl", "issueDate", "dueDate", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: shift_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shift_assignments (id, date, status, notes, "userId", "shiftTemplateId", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: shift_swap_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shift_swap_requests (id, status, reason, "targetRespondedAt", "targetApproved", "requesterId", "targetId", "requesterAssignmentId", "targetAssignmentId", "approvedById", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: shift_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shift_templates (id, name, "startTime", "endTime", color, "gracePeriodMinutes", "isActive", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: sms_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sms_settings (id, "tenantId", "isEnabled", "smsOnReservationCreated", "smsOnReservationConfirmed", "smsOnReservationRejected", "smsOnReservationCancelled", "smsOnOrderCreated", "smsOnOrderApproved", "smsOnOrderPreparing", "smsOnOrderReady", "smsOnOrderCancelled", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: stock_batches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_batches (id, "batchNumber", quantity, "costPerUnit", "receivedAt", "expiryDate", "stockItemId", "purchaseOrderItemId", "tenantId", "createdAt") FROM stdin;
\.


--
-- Data for Name: stock_count_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_count_items (id, "expectedQty", "countedQty", variance, "stockCountId", "stockItemId") FROM stdin;
\.


--
-- Data for Name: stock_counts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_counts (id, name, status, notes, "createdById", "tenantId", "createdAt", "updatedAt", "completedAt") FROM stdin;
\.


--
-- Data for Name: stock_item_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_item_categories (id, name, description, color, "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: stock_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_items (id, name, sku, unit, description, "currentStock", "minStock", "costPerUnit", "trackExpiry", "isActive", "categoryId", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_movements (id, type, quantity, reason, notes, "productId", "userId", "tenantId", "createdAt") FROM stdin;
\.


--
-- Data for Name: stock_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_settings (id, "tenantId", "enableAutoDeduction", "deductOnStatus", "lowStockAlertDays", "poNumberPrefix", "allowNegativeStock", "poSequence", "createdAt", "updatedAt") FROM stdin;
6c96803e-4922-4b13-9c9f-6052b132a2b3	6e75a35e-f17f-4748-807a-6cd6ca3a648d	t	PREPARING	3	PO	f	0	2026-04-21 17:55:02.955	2026-04-21 17:55:02.955
\.


--
-- Data for Name: subscription_payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscription_payments (id, "subscriptionId", amount, currency, status, "paymentProvider", "externalReference", "paymentMethod", last4, "cardBrand", "failureCode", "failureMessage", "retryCount", "paidAt", "refundedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscription_plans (id, name, "displayName", description, "monthlyPrice", "yearlyPrice", currency, "trialDays", "maxUsers", "maxTables", "maxProducts", "maxCategories", "maxMonthlyOrders", "advancedReports", "multiLocation", "customBranding", "apiAccess", "prioritySupport", "inventoryTracking", "kdsIntegration", "reservationSystem", "personnelManagement", "deliveryIntegration", "discountPercentage", "discountLabel", "discountStartDate", "discountEndDate", "isDiscountActive", "isActive", "createdAt", "updatedAt") FROM stdin;
fb4cea91-d8b3-493e-90d8-08c59d41c95e	FREE	Free Plan	Perfect for small restaurants getting started	0.00	0.00	USD	0	2	5	25	5	50	f	f	f	f	f	f	t	f	f	f	\N	\N	\N	\N	f	t	2025-11-15 23:59:17.709	2025-11-15 23:59:17.709
54c07493-3d9a-47fd-8d41-328cdab8d729	BASIC	Basic Plan	Great for growing restaurants	29.99	299.99	USD	14	5	20	100	20	500	f	f	f	f	f	t	t	f	f	f	\N	\N	\N	\N	f	t	2025-11-15 23:59:17.743	2025-11-15 23:59:17.743
de655aab-5a46-42cd-b2d3-74ada571c6ed	PRO	Pro Plan	For established restaurants with multiple locations	79.99	799.99	USD	14	15	50	500	50	2000	t	t	t	f	t	t	t	t	t	f	\N	\N	\N	\N	f	t	2025-11-15 23:59:17.75	2025-11-15 23:59:17.75
228c3989-ac15-4e7c-960f-fd508a98fef9	BUSINESS	Business Plan	Enterprise solution for large restaurant chains	199.99	1999.99	USD	14	-1	-1	-1	-1	-1	t	t	t	t	t	t	t	t	t	f	\N	\N	\N	\N	f	t	2025-11-15 23:59:17.756	2025-11-15 23:59:17.756
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscriptions (id, "tenantId", "planId", status, "billingCycle", "paymentProvider", "startDate", "currentPeriodStart", "currentPeriodEnd", "cancelledAt", "endedAt", "isTrialPeriod", "trialStart", "trialEnd", amount, currency, "autoRenew", "cancelAtPeriodEnd", "cancellationReason", "scheduledDowngradePlanId", "scheduledDowngradeBillingCycle", "createdAt", "updatedAt") FROM stdin;
f74f805a-407f-4d7f-b358-90d9d3d8d524	6e75a35e-f17f-4748-807a-6cd6ca3a648d	fb4cea91-d8b3-493e-90d8-08c59d41c95e	ACTIVE	MONTHLY	EMAIL	2026-04-20 13:59:34.517	2026-04-20 13:59:34.517	2036-04-20 13:59:34.517	\N	\N	f	\N	\N	0.00	USD	t	f	\N	\N	\N	2026-04-20 13:59:34.542	2026-04-20 13:59:34.542
\.


--
-- Data for Name: super_admins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.super_admins (id, email, password, "firstName", "lastName", status, "twoFactorSecret", "twoFactorEnabled", "pendingTwoFactorSecret", "backupCodes", "lastTotpStep", "lastTotpStepExpiresAt", "tokenVersion", "lastLogin", "lastLoginIp", "failedLogins", "lockedUntil", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: supplier_stock_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.supplier_stock_items (id, "supplierSku", "unitPrice", "isPreferred", "supplierId", "stockItemId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.suppliers (id, name, "contactName", email, phone, address, "paymentTerms", notes, "isActive", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: table_analytics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.table_analytics (id, date, "tableId", "totalOccupiedMinutes", "totalDiningMinutes", "totalIdleMinutes", "totalEmptyMinutes", "totalSessions", "avgSessionDuration", "avgDiningDuration", "avgIdleDuration", "revenueGenerated", "ordersCount", "avgOrderValue", "revenuePerMinute", "utilizationScore", "peakHours", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: tables; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tables (id, number, capacity, section, status, "groupId", "voxelX", "voxelY", "voxelZ", "voxelRotation", "tenantId", "createdAt", "updatedAt") FROM stdin;
c5a6eff2-74f7-4d8d-8765-fd08e7558241	2	4	\N	AVAILABLE	\N	\N	0	\N	0	6e75a35e-f17f-4748-807a-6cd6ca3a648d	2026-04-21 17:54:18.61	2026-04-21 17:54:18.61
64d91332-13b8-4db8-a936-3cc294a09c77	1	4	\N	OCCUPIED	\N	\N	0	\N	0	6e75a35e-f17f-4748-807a-6cd6ca3a648d	2026-04-21 17:54:23.553	2026-04-21 17:55:03.106
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (id, name, subdomain, status, "currentPlanId", "paymentRegion", "trialUsed", "trialStartedAt", "trialEndsAt", currency, latitude, longitude, "locationRadius", "closingTime", timezone, "reportEmailEnabled", "reportEmails", "wifiSsid", "wifiPassword", "socialInstagram", "socialFacebook", "socialTwitter", "socialTiktok", "socialYoutube", "socialWhatsapp", "featureOverrides", "limitOverrides", "createdAt", "updatedAt") FROM stdin;
6e75a35e-f17f-4748-807a-6cd6ca3a648d	Tarık's Restaurant	tar-k-s-restaurant	ACTIVE	fb4cea91-d8b3-493e-90d8-08c59d41c95e	INTERNATIONAL	f	\N	\N	TRY	\N	\N	100	23:00	UTC	f	{}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-04-20 13:59:34.528	2026-04-20 13:59:34.528
\.


--
-- Data for Name: traffic_flow_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.traffic_flow_records (id, "hourBucket", "cellX", "cellZ", "cellSize", "personCount", "avgDwellTime", entrances, exits, "flowDirections", "tenantId") FROM stdin;
\.


--
-- Data for Name: user_activities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_activities (id, "userId", "tenantId", action, ip, "userAgent", metadata, "createdAt") FROM stdin;
47e476c3-bbc2-460c-9927-247b345a86ee	dbcdfe84-49b8-4716-9531-4fa9ff0cbc88	6e75a35e-f17f-4748-807a-6cd6ca3a648d	LOGIN_FAILED	::ffff:172.18.0.1	curl/8.5.0	\N	2026-04-23 08:59:53.124
d2b11b88-1df4-4062-b14e-60765d69ff86	dbcdfe84-49b8-4716-9531-4fa9ff0cbc88	6e75a35e-f17f-4748-807a-6cd6ca3a648d	LOGIN_FAILED	::ffff:172.18.0.1	curl/8.5.0	\N	2026-04-23 09:00:09.603
e24e1bce-2217-4cf8-a58b-60a6fac96f20	dbcdfe84-49b8-4716-9531-4fa9ff0cbc88	6e75a35e-f17f-4748-807a-6cd6ca3a648d	LOGIN_FAILED	::ffff:172.18.0.1	curl/8.5.0	\N	2026-04-23 09:00:18.117
87651c5a-67d0-4345-a4a5-0879b39c6cc5	dbcdfe84-49b8-4716-9531-4fa9ff0cbc88	6e75a35e-f17f-4748-807a-6cd6ca3a648d	LOGIN_FAILED	::ffff:172.18.0.1	curl/8.5.0	\N	2026-04-23 10:37:26.783
\.


--
-- Data for Name: user_notification_reads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_notification_reads (id, "notificationId", "userId", "readAt") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password, "firstName", "lastName", role, status, "approvedAt", "approvedById", "reactivatedAt", "reactivatedById", "emailVerified", "emailVerificationCodeHash", "emailVerificationCodeExpires", "resetTokenHash", "resetTokenExpiry", "tokenVersion", avatar, phone, "lastLogin", "googleId", "appleId", "authProvider", "onboardingData", "tenantId", "createdAt", "updatedAt") FROM stdin;
dbcdfe84-49b8-4716-9531-4fa9ff0cbc88	tarik42777@gmail.com		Tarık	Uçar	ADMIN	ACTIVE	\N	\N	\N	\N	t	\N	\N	\N	\N	0	\N	\N	\N	103540710481107596238	\N	google	\N	6e75a35e-f17f-4748-807a-6cd6ca3a648d	2026-04-20 13:59:34.552	2026-04-20 13:59:34.552
\.


--
-- Data for Name: waiter_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.waiter_requests (id, message, status, "sessionId", "tenantId", "tableId", "acknowledgedAt", "acknowledgedById", "completedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: waste_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.waste_logs (id, quantity, reason, notes, cost, "createdById", "stockItemId", "tenantId", "createdAt") FROM stdin;
\.


--
-- Data for Name: z_reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.z_reports (id, "reportNumber", "reportDate", "closingTime", "closingType", "closedById", "branchName", "terminalId", "totalSales", "totalOrders", "totalDiscount", "totalRefunds", "netSales", "totalTax", "taxBreakdown", "dineInSales", "dineInOrders", "takeawaySales", "takeawayOrders", "deliverySales", "deliveryOrders", "cashPayments", "cashPaymentCount", "cardPayments", "cardPaymentCount", "digitalPayments", "digitalPaymentCount", "openingCash", "expectedCash", "countedCash", "cashDifference", "cashInOut", "cancelledOrders", "cancelledOrdersAmount", "refundedPayments", "refundedAmount", "staffPerformance", "categoryBreakdown", "topProducts", "openChecks", "openChecksAmount", notes, "systemGenerated", "pdfExported", "pdfUrl", "excelExported", "excelUrl", "emailSent", "emailSentAt", "emailRecipients", "emailError", "isFinalized", "finalizedAt", "finalizedById", "payloadHash", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: accounting_settings accounting_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounting_settings
    ADD CONSTRAINT accounting_settings_pkey PRIMARY KEY (id);


--
-- Name: analytics_heatmap_cache analytics_heatmap_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_heatmap_cache
    ADD CONSTRAINT analytics_heatmap_cache_pkey PRIMARY KEY (id);


--
-- Name: analytics_insights analytics_insights_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_insights
    ADD CONSTRAINT analytics_insights_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: attendances attendances_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bill_requests bill_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_requests
    ADD CONSTRAINT bill_requests_pkey PRIMARY KEY (id);


--
-- Name: cameras cameras_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cameras
    ADD CONSTRAINT cameras_pkey PRIMARY KEY (id);


--
-- Name: cash_drawer_movements cash_drawer_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cash_drawer_movements
    ADD CONSTRAINT cash_drawer_movements_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: commissions commissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commissions
    ADD CONSTRAINT commissions_pkey PRIMARY KEY (id);


--
-- Name: contact_messages contact_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_messages
    ADD CONSTRAINT contact_messages_pkey PRIMARY KEY (id);


--
-- Name: customer_referrals customer_referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_referrals
    ADD CONSTRAINT customer_referrals_pkey PRIMARY KEY (id);


--
-- Name: customer_sessions customer_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_sessions
    ADD CONSTRAINT customer_sessions_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: delivery_platform_configs delivery_platform_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_platform_configs
    ADD CONSTRAINT delivery_platform_configs_pkey PRIMARY KEY (id);


--
-- Name: delivery_platform_logs delivery_platform_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_platform_logs
    ADD CONSTRAINT delivery_platform_logs_pkey PRIMARY KEY (id);


--
-- Name: desktop_releases desktop_releases_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.desktop_releases
    ADD CONSTRAINT desktop_releases_pkey PRIMARY KEY (id);


--
-- Name: edge_devices edge_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.edge_devices
    ADD CONSTRAINT edge_devices_pkey PRIMARY KEY (id);


--
-- Name: ingredient_movements ingredient_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingredient_movements
    ADD CONSTRAINT ingredient_movements_pkey PRIMARY KEY (id);


--
-- Name: integration_settings integration_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_settings
    ADD CONSTRAINT integration_settings_pkey PRIMARY KEY (id);


--
-- Name: invoice_counters invoice_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_counters
    ADD CONSTRAINT invoice_counters_pkey PRIMARY KEY (scope);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: lead_activities lead_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_activities
    ADD CONSTRAINT lead_activities_pkey PRIMARY KEY (id);


--
-- Name: lead_offers lead_offers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_offers
    ADD CONSTRAINT lead_offers_pkey PRIMARY KEY (id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: loyalty_transactions loyalty_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT loyalty_transactions_pkey PRIMARY KEY (id);


--
-- Name: marketing_notifications marketing_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_notifications
    ADD CONSTRAINT marketing_notifications_pkey PRIMARY KEY (id);


--
-- Name: marketing_tasks marketing_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_tasks
    ADD CONSTRAINT marketing_tasks_pkey PRIMARY KEY (id);


--
-- Name: marketing_users marketing_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_users
    ADD CONSTRAINT marketing_users_pkey PRIMARY KEY (id);


--
-- Name: menu_item_mappings menu_item_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item_mappings
    ADD CONSTRAINT menu_item_mappings_pkey PRIMARY KEY (id);


--
-- Name: modifier_groups modifier_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifier_groups
    ADD CONSTRAINT modifier_groups_pkey PRIMARY KEY (id);


--
-- Name: modifiers modifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifiers
    ADD CONSTRAINT modifiers_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: occupancy_records occupancy_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.occupancy_records
    ADD CONSTRAINT occupancy_records_pkey PRIMARY KEY (id);


--
-- Name: order_item_modifiers order_item_modifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item_modifiers
    ADD CONSTRAINT order_item_modifiers_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: page_views page_views_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_views
    ADD CONSTRAINT page_views_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: phone_verifications phone_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.phone_verifications
    ADD CONSTRAINT phone_verifications_pkey PRIMARY KEY (id);


--
-- Name: pos_settings pos_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pos_settings
    ADD CONSTRAINT pos_settings_pkey PRIMARY KEY (id);


--
-- Name: product_images product_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_pkey PRIMARY KEY (id);


--
-- Name: product_modifier_groups product_modifier_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_modifier_groups
    ADD CONSTRAINT product_modifier_groups_pkey PRIMARY KEY (id);


--
-- Name: product_to_images product_to_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_to_images
    ADD CONSTRAINT product_to_images_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: public_reviews public_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.public_reviews
    ADD CONSTRAINT public_reviews_pkey PRIMARY KEY (id);


--
-- Name: public_stats_cache public_stats_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.public_stats_cache
    ADD CONSTRAINT public_stats_cache_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_items purchase_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: qr_menu_settings qr_menu_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qr_menu_settings
    ADD CONSTRAINT qr_menu_settings_pkey PRIMARY KEY (id);


--
-- Name: recipe_ingredients recipe_ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_pkey PRIMARY KEY (id);


--
-- Name: recipes recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: reservation_settings reservation_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservation_settings
    ADD CONSTRAINT reservation_settings_pkey PRIMARY KEY (id);


--
-- Name: reservations reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT reservations_pkey PRIMARY KEY (id);


--
-- Name: reserved_subdomains reserved_subdomains_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reserved_subdomains
    ADD CONSTRAINT reserved_subdomains_pkey PRIMARY KEY (id);


--
-- Name: restaurant_layouts restaurant_layouts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant_layouts
    ADD CONSTRAINT restaurant_layouts_pkey PRIMARY KEY (id);


--
-- Name: sales_invoice_items sales_invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_invoice_items
    ADD CONSTRAINT sales_invoice_items_pkey PRIMARY KEY (id);


--
-- Name: sales_invoices sales_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_invoices
    ADD CONSTRAINT sales_invoices_pkey PRIMARY KEY (id);


--
-- Name: shift_assignments shift_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift_assignments
    ADD CONSTRAINT shift_assignments_pkey PRIMARY KEY (id);


--
-- Name: shift_swap_requests shift_swap_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift_swap_requests
    ADD CONSTRAINT shift_swap_requests_pkey PRIMARY KEY (id);


--
-- Name: shift_templates shift_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift_templates
    ADD CONSTRAINT shift_templates_pkey PRIMARY KEY (id);


--
-- Name: sms_settings sms_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sms_settings
    ADD CONSTRAINT sms_settings_pkey PRIMARY KEY (id);


--
-- Name: stock_batches stock_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_batches
    ADD CONSTRAINT stock_batches_pkey PRIMARY KEY (id);


--
-- Name: stock_count_items stock_count_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_count_items
    ADD CONSTRAINT stock_count_items_pkey PRIMARY KEY (id);


--
-- Name: stock_counts stock_counts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_counts
    ADD CONSTRAINT stock_counts_pkey PRIMARY KEY (id);


--
-- Name: stock_item_categories stock_item_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_item_categories
    ADD CONSTRAINT stock_item_categories_pkey PRIMARY KEY (id);


--
-- Name: stock_items stock_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_items
    ADD CONSTRAINT stock_items_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: stock_settings stock_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_settings
    ADD CONSTRAINT stock_settings_pkey PRIMARY KEY (id);


--
-- Name: subscription_payments subscription_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT subscription_payments_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: super_admins super_admins_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.super_admins
    ADD CONSTRAINT super_admins_pkey PRIMARY KEY (id);


--
-- Name: supplier_stock_items supplier_stock_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_stock_items
    ADD CONSTRAINT supplier_stock_items_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: table_analytics table_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.table_analytics
    ADD CONSTRAINT table_analytics_pkey PRIMARY KEY (id);


--
-- Name: tables tables_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT tables_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: traffic_flow_records traffic_flow_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.traffic_flow_records
    ADD CONSTRAINT traffic_flow_records_pkey PRIMARY KEY (id);


--
-- Name: user_activities user_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activities
    ADD CONSTRAINT user_activities_pkey PRIMARY KEY (id);


--
-- Name: user_notification_reads user_notification_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_reads
    ADD CONSTRAINT user_notification_reads_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: waiter_requests waiter_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waiter_requests
    ADD CONSTRAINT waiter_requests_pkey PRIMARY KEY (id);


--
-- Name: waste_logs waste_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waste_logs
    ADD CONSTRAINT waste_logs_pkey PRIMARY KEY (id);


--
-- Name: z_reports z_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.z_reports
    ADD CONSTRAINT z_reports_pkey PRIMARY KEY (id);


--
-- Name: accounting_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "accounting_settings_tenantId_idx" ON public.accounting_settings USING btree ("tenantId");


--
-- Name: accounting_settings_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "accounting_settings_tenantId_key" ON public.accounting_settings USING btree ("tenantId");


--
-- Name: analytics_heatmap_cache_expiresAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "analytics_heatmap_cache_expiresAt_idx" ON public.analytics_heatmap_cache USING btree ("expiresAt");


--
-- Name: analytics_heatmap_cache_tenantId_metric_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "analytics_heatmap_cache_tenantId_metric_idx" ON public.analytics_heatmap_cache USING btree ("tenantId", metric);


--
-- Name: analytics_heatmap_cache_tenantId_startTime_endTime_granular_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "analytics_heatmap_cache_tenantId_startTime_endTime_granular_key" ON public.analytics_heatmap_cache USING btree ("tenantId", "startTime", "endTime", granularity, metric);


--
-- Name: analytics_insights_severity_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_insights_severity_idx ON public.analytics_insights USING btree (severity);


--
-- Name: analytics_insights_tenantId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "analytics_insights_tenantId_createdAt_idx" ON public.analytics_insights USING btree ("tenantId", "createdAt");


--
-- Name: analytics_insights_tenantId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "analytics_insights_tenantId_status_idx" ON public.analytics_insights USING btree ("tenantId", status);


--
-- Name: analytics_insights_tenantId_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "analytics_insights_tenantId_type_idx" ON public.analytics_insights USING btree ("tenantId", type);


--
-- Name: api_keys_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "api_keys_isActive_idx" ON public.api_keys USING btree ("isActive");


--
-- Name: api_keys_keyHash_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "api_keys_keyHash_key" ON public.api_keys USING btree ("keyHash");


--
-- Name: api_keys_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "api_keys_tenantId_idx" ON public.api_keys USING btree ("tenantId");


--
-- Name: attendances_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attendances_status_idx ON public.attendances USING btree (status);


--
-- Name: attendances_tenantId_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "attendances_tenantId_date_idx" ON public.attendances USING btree ("tenantId", date);


--
-- Name: attendances_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "attendances_tenantId_idx" ON public.attendances USING btree ("tenantId");


--
-- Name: attendances_userId_date_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "attendances_userId_date_key" ON public.attendances USING btree ("userId", date);


--
-- Name: attendances_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "attendances_userId_idx" ON public.attendances USING btree ("userId");


--
-- Name: audit_logs_actorId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "audit_logs_actorId_idx" ON public.audit_logs USING btree ("actorId");


--
-- Name: audit_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "audit_logs_createdAt_idx" ON public.audit_logs USING btree ("createdAt");


--
-- Name: audit_logs_entityType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "audit_logs_entityType_idx" ON public.audit_logs USING btree ("entityType");


--
-- Name: audit_logs_targetTenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "audit_logs_targetTenantId_idx" ON public.audit_logs USING btree ("targetTenantId");


--
-- Name: bill_requests_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "bill_requests_sessionId_idx" ON public.bill_requests USING btree ("sessionId");


--
-- Name: bill_requests_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bill_requests_status_idx ON public.bill_requests USING btree (status);


--
-- Name: bill_requests_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "bill_requests_tableId_idx" ON public.bill_requests USING btree ("tableId");


--
-- Name: bill_requests_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "bill_requests_tenantId_idx" ON public.bill_requests USING btree ("tenantId");


--
-- Name: bill_requests_tenantId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "bill_requests_tenantId_status_idx" ON public.bill_requests USING btree ("tenantId", status);


--
-- Name: cameras_edgeDeviceId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "cameras_edgeDeviceId_idx" ON public.cameras USING btree ("edgeDeviceId");


--
-- Name: cameras_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cameras_status_idx ON public.cameras USING btree (status);


--
-- Name: cameras_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "cameras_tenantId_idx" ON public.cameras USING btree ("tenantId");


--
-- Name: cameras_tenantId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "cameras_tenantId_name_key" ON public.cameras USING btree ("tenantId", name);


--
-- Name: cash_drawer_movements_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "cash_drawer_movements_createdAt_idx" ON public.cash_drawer_movements USING btree ("createdAt");


--
-- Name: cash_drawer_movements_tenantId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "cash_drawer_movements_tenantId_createdAt_idx" ON public.cash_drawer_movements USING btree ("tenantId", "createdAt");


--
-- Name: cash_drawer_movements_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "cash_drawer_movements_tenantId_idx" ON public.cash_drawer_movements USING btree ("tenantId");


--
-- Name: cash_drawer_movements_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "cash_drawer_movements_userId_idx" ON public.cash_drawer_movements USING btree ("userId");


--
-- Name: cash_drawer_movements_zReportId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "cash_drawer_movements_zReportId_idx" ON public.cash_drawer_movements USING btree ("zReportId");


--
-- Name: categories_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "categories_tenantId_idx" ON public.categories USING btree ("tenantId");


--
-- Name: commissions_leadId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "commissions_leadId_idx" ON public.commissions USING btree ("leadId");


--
-- Name: commissions_marketingUserId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "commissions_marketingUserId_idx" ON public.commissions USING btree ("marketingUserId");


--
-- Name: commissions_period_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX commissions_period_idx ON public.commissions USING btree (period);


--
-- Name: commissions_period_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX commissions_period_status_idx ON public.commissions USING btree (period, status);


--
-- Name: commissions_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX commissions_status_idx ON public.commissions USING btree (status);


--
-- Name: commissions_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "commissions_tenantId_idx" ON public.commissions USING btree ("tenantId");


--
-- Name: contact_messages_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "contact_messages_createdAt_idx" ON public.contact_messages USING btree ("createdAt");


--
-- Name: contact_messages_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX contact_messages_status_idx ON public.contact_messages USING btree (status);


--
-- Name: customer_referrals_referralCode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_referrals_referralCode_idx" ON public.customer_referrals USING btree ("referralCode");


--
-- Name: customer_referrals_referredId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_referrals_referredId_idx" ON public.customer_referrals USING btree ("referredId");


--
-- Name: customer_referrals_referredId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customer_referrals_referredId_key" ON public.customer_referrals USING btree ("referredId");


--
-- Name: customer_referrals_referrerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_referrals_referrerId_idx" ON public.customer_referrals USING btree ("referrerId");


--
-- Name: customer_referrals_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customer_referrals_status_idx ON public.customer_referrals USING btree (status);


--
-- Name: customer_sessions_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_sessions_customerId_idx" ON public.customer_sessions USING btree ("customerId");


--
-- Name: customer_sessions_expiresAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_sessions_expiresAt_idx" ON public.customer_sessions USING btree ("expiresAt");


--
-- Name: customer_sessions_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_sessions_sessionId_idx" ON public.customer_sessions USING btree ("sessionId");


--
-- Name: customer_sessions_sessionId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customer_sessions_sessionId_key" ON public.customer_sessions USING btree ("sessionId");


--
-- Name: customer_sessions_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_sessions_tenantId_idx" ON public.customer_sessions USING btree ("tenantId");


--
-- Name: customers_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customers_email_idx ON public.customers USING btree (email);


--
-- Name: customers_loyaltyTier_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customers_loyaltyTier_idx" ON public.customers USING btree ("loyaltyTier");


--
-- Name: customers_phone_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customers_phone_idx ON public.customers USING btree (phone);


--
-- Name: customers_referralCode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customers_referralCode_idx" ON public.customers USING btree ("referralCode");


--
-- Name: customers_referralCode_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customers_referralCode_key" ON public.customers USING btree ("referralCode");


--
-- Name: customers_tenantId_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customers_tenantId_email_key" ON public.customers USING btree ("tenantId", email);


--
-- Name: customers_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customers_tenantId_idx" ON public.customers USING btree ("tenantId");


--
-- Name: customers_tenantId_phone_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customers_tenantId_phone_key" ON public.customers USING btree ("tenantId", phone);


--
-- Name: delivery_platform_configs_isEnabled_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "delivery_platform_configs_isEnabled_idx" ON public.delivery_platform_configs USING btree ("isEnabled");


--
-- Name: delivery_platform_configs_platform_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX delivery_platform_configs_platform_idx ON public.delivery_platform_configs USING btree (platform);


--
-- Name: delivery_platform_configs_platform_remoteRestaurantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "delivery_platform_configs_platform_remoteRestaurantId_key" ON public.delivery_platform_configs USING btree (platform, "remoteRestaurantId");


--
-- Name: delivery_platform_configs_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "delivery_platform_configs_tenantId_idx" ON public.delivery_platform_configs USING btree ("tenantId");


--
-- Name: delivery_platform_configs_tenantId_platform_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "delivery_platform_configs_tenantId_platform_key" ON public.delivery_platform_configs USING btree ("tenantId", platform);


--
-- Name: delivery_platform_logs_nextRetryAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "delivery_platform_logs_nextRetryAt_idx" ON public.delivery_platform_logs USING btree ("nextRetryAt");


--
-- Name: delivery_platform_logs_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "delivery_platform_logs_orderId_idx" ON public.delivery_platform_logs USING btree ("orderId");


--
-- Name: delivery_platform_logs_platform_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX delivery_platform_logs_platform_idx ON public.delivery_platform_logs USING btree (platform);


--
-- Name: delivery_platform_logs_success_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX delivery_platform_logs_success_idx ON public.delivery_platform_logs USING btree (success);


--
-- Name: delivery_platform_logs_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "delivery_platform_logs_tenantId_idx" ON public.delivery_platform_logs USING btree ("tenantId");


--
-- Name: desktop_releases_published_pubDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "desktop_releases_published_pubDate_idx" ON public.desktop_releases USING btree (published, "pubDate");


--
-- Name: desktop_releases_releaseTag_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "desktop_releases_releaseTag_key" ON public.desktop_releases USING btree ("releaseTag");


--
-- Name: desktop_releases_version_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX desktop_releases_version_idx ON public.desktop_releases USING btree (version);


--
-- Name: desktop_releases_version_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX desktop_releases_version_key ON public.desktop_releases USING btree (version);


--
-- Name: edge_devices_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX edge_devices_status_idx ON public.edge_devices USING btree (status);


--
-- Name: edge_devices_tenantId_deviceId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "edge_devices_tenantId_deviceId_key" ON public.edge_devices USING btree ("tenantId", "deviceId");


--
-- Name: edge_devices_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "edge_devices_tenantId_idx" ON public.edge_devices USING btree ("tenantId");


--
-- Name: ingredient_movements_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ingredient_movements_createdAt_idx" ON public.ingredient_movements USING btree ("createdAt");


--
-- Name: ingredient_movements_referenceType_referenceId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ingredient_movements_referenceType_referenceId_idx" ON public.ingredient_movements USING btree ("referenceType", "referenceId");


--
-- Name: ingredient_movements_stockItemId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ingredient_movements_stockItemId_idx" ON public.ingredient_movements USING btree ("stockItemId");


--
-- Name: ingredient_movements_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ingredient_movements_tenantId_idx" ON public.ingredient_movements USING btree ("tenantId");


--
-- Name: ingredient_movements_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ingredient_movements_type_idx ON public.ingredient_movements USING btree (type);


--
-- Name: integration_settings_integrationType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "integration_settings_integrationType_idx" ON public.integration_settings USING btree ("integrationType");


--
-- Name: integration_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "integration_settings_tenantId_idx" ON public.integration_settings USING btree ("tenantId");


--
-- Name: integration_settings_tenantId_integrationType_provider_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "integration_settings_tenantId_integrationType_provider_key" ON public.integration_settings USING btree ("tenantId", "integrationType", provider);


--
-- Name: invoices_dueDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_dueDate_idx" ON public.invoices USING btree ("dueDate");


--
-- Name: invoices_invoiceNumber_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_invoiceNumber_idx" ON public.invoices USING btree ("invoiceNumber");


--
-- Name: invoices_invoiceNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "invoices_invoiceNumber_key" ON public.invoices USING btree ("invoiceNumber");


--
-- Name: invoices_paymentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "invoices_paymentId_key" ON public.invoices USING btree ("paymentId");


--
-- Name: invoices_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX invoices_status_idx ON public.invoices USING btree (status);


--
-- Name: invoices_subscriptionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_subscriptionId_idx" ON public.invoices USING btree ("subscriptionId");


--
-- Name: lead_activities_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "lead_activities_createdAt_idx" ON public.lead_activities USING btree ("createdAt");


--
-- Name: lead_activities_createdById_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "lead_activities_createdById_idx" ON public.lead_activities USING btree ("createdById");


--
-- Name: lead_activities_leadId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "lead_activities_leadId_idx" ON public.lead_activities USING btree ("leadId");


--
-- Name: lead_activities_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX lead_activities_type_idx ON public.lead_activities USING btree (type);


--
-- Name: lead_offers_createdById_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "lead_offers_createdById_idx" ON public.lead_offers USING btree ("createdById");


--
-- Name: lead_offers_leadId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "lead_offers_leadId_idx" ON public.lead_offers USING btree ("leadId");


--
-- Name: lead_offers_leadId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "lead_offers_leadId_status_idx" ON public.lead_offers USING btree ("leadId", status);


--
-- Name: lead_offers_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX lead_offers_status_idx ON public.lead_offers USING btree (status);


--
-- Name: leads_assignedToId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "leads_assignedToId_idx" ON public.leads USING btree ("assignedToId");


--
-- Name: leads_assignedToId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "leads_assignedToId_status_idx" ON public.leads USING btree ("assignedToId", status);


--
-- Name: leads_businessType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "leads_businessType_idx" ON public.leads USING btree ("businessType");


--
-- Name: leads_city_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX leads_city_idx ON public.leads USING btree (city);


--
-- Name: leads_convertedTenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "leads_convertedTenantId_key" ON public.leads USING btree ("convertedTenantId");


--
-- Name: leads_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "leads_createdAt_idx" ON public.leads USING btree ("createdAt");


--
-- Name: leads_nextFollowUp_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "leads_nextFollowUp_idx" ON public.leads USING btree ("nextFollowUp");


--
-- Name: leads_priority_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX leads_priority_idx ON public.leads USING btree (priority);


--
-- Name: leads_source_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX leads_source_idx ON public.leads USING btree (source);


--
-- Name: leads_status_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "leads_status_createdAt_idx" ON public.leads USING btree (status, "createdAt");


--
-- Name: leads_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX leads_status_idx ON public.leads USING btree (status);


--
-- Name: loyalty_transactions_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "loyalty_transactions_createdAt_idx" ON public.loyalty_transactions USING btree ("createdAt");


--
-- Name: loyalty_transactions_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "loyalty_transactions_customerId_idx" ON public.loyalty_transactions USING btree ("customerId");


--
-- Name: loyalty_transactions_tenantId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "loyalty_transactions_tenantId_createdAt_idx" ON public.loyalty_transactions USING btree ("tenantId", "createdAt");


--
-- Name: loyalty_transactions_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "loyalty_transactions_tenantId_idx" ON public.loyalty_transactions USING btree ("tenantId");


--
-- Name: loyalty_transactions_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX loyalty_transactions_type_idx ON public.loyalty_transactions USING btree (type);


--
-- Name: marketing_notifications_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "marketing_notifications_createdAt_idx" ON public.marketing_notifications USING btree ("createdAt");


--
-- Name: marketing_notifications_userId_isRead_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "marketing_notifications_userId_isRead_idx" ON public.marketing_notifications USING btree ("userId", "isRead");


--
-- Name: marketing_tasks_assignedToId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "marketing_tasks_assignedToId_idx" ON public.marketing_tasks USING btree ("assignedToId");


--
-- Name: marketing_tasks_assignedToId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "marketing_tasks_assignedToId_status_idx" ON public.marketing_tasks USING btree ("assignedToId", status);


--
-- Name: marketing_tasks_dueDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "marketing_tasks_dueDate_idx" ON public.marketing_tasks USING btree ("dueDate");


--
-- Name: marketing_tasks_dueDate_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "marketing_tasks_dueDate_status_idx" ON public.marketing_tasks USING btree ("dueDate", status);


--
-- Name: marketing_tasks_leadId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "marketing_tasks_leadId_idx" ON public.marketing_tasks USING btree ("leadId");


--
-- Name: marketing_tasks_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX marketing_tasks_status_idx ON public.marketing_tasks USING btree (status);


--
-- Name: marketing_users_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX marketing_users_email_idx ON public.marketing_users USING btree (email);


--
-- Name: marketing_users_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX marketing_users_email_key ON public.marketing_users USING btree (email);


--
-- Name: marketing_users_role_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX marketing_users_role_idx ON public.marketing_users USING btree (role);


--
-- Name: marketing_users_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX marketing_users_status_idx ON public.marketing_users USING btree (status);


--
-- Name: menu_item_mappings_platform_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX menu_item_mappings_platform_idx ON public.menu_item_mappings USING btree (platform);


--
-- Name: menu_item_mappings_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "menu_item_mappings_productId_idx" ON public.menu_item_mappings USING btree ("productId");


--
-- Name: menu_item_mappings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "menu_item_mappings_tenantId_idx" ON public.menu_item_mappings USING btree ("tenantId");


--
-- Name: menu_item_mappings_tenantId_platform_externalItemId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "menu_item_mappings_tenantId_platform_externalItemId_key" ON public.menu_item_mappings USING btree ("tenantId", platform, "externalItemId");


--
-- Name: modifier_groups_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifier_groups_isActive_idx" ON public.modifier_groups USING btree ("isActive");


--
-- Name: modifier_groups_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifier_groups_tenantId_idx" ON public.modifier_groups USING btree ("tenantId");


--
-- Name: modifiers_groupId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifiers_groupId_idx" ON public.modifiers USING btree ("groupId");


--
-- Name: modifiers_isAvailable_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifiers_isAvailable_idx" ON public.modifiers USING btree ("isAvailable");


--
-- Name: modifiers_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifiers_tenantId_idx" ON public.modifiers USING btree ("tenantId");


--
-- Name: notifications_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "notifications_createdAt_idx" ON public.notifications USING btree ("createdAt");


--
-- Name: notifications_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "notifications_tenantId_idx" ON public.notifications USING btree ("tenantId");


--
-- Name: notifications_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "notifications_userId_idx" ON public.notifications USING btree ("userId");


--
-- Name: occupancy_records_state_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX occupancy_records_state_idx ON public.occupancy_records USING btree (state);


--
-- Name: occupancy_records_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "occupancy_records_tableId_idx" ON public.occupancy_records USING btree ("tableId");


--
-- Name: occupancy_records_tenantId_timestamp_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "occupancy_records_tenantId_timestamp_idx" ON public.occupancy_records USING btree ("tenantId", "timestamp");


--
-- Name: occupancy_records_trackingId_timestamp_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "occupancy_records_trackingId_timestamp_idx" ON public.occupancy_records USING btree ("trackingId", "timestamp");


--
-- Name: order_item_modifiers_modifierId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_item_modifiers_modifierId_idx" ON public.order_item_modifiers USING btree ("modifierId");


--
-- Name: order_item_modifiers_orderItemId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_item_modifiers_orderItemId_idx" ON public.order_item_modifiers USING btree ("orderItemId");


--
-- Name: order_items_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_items_orderId_idx" ON public.order_items USING btree ("orderId");


--
-- Name: order_items_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_items_productId_idx" ON public.order_items USING btree ("productId");


--
-- Name: orders_approvedById_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_approvedById_idx" ON public.orders USING btree ("approvedById");


--
-- Name: orders_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_customerId_idx" ON public.orders USING btree ("customerId");


--
-- Name: orders_externalOrderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_externalOrderId_idx" ON public.orders USING btree ("externalOrderId");


--
-- Name: orders_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_sessionId_idx" ON public.orders USING btree ("sessionId");


--
-- Name: orders_source_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orders_source_idx ON public.orders USING btree (source);


--
-- Name: orders_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orders_status_idx ON public.orders USING btree (status);


--
-- Name: orders_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_tableId_idx" ON public.orders USING btree ("tableId");


--
-- Name: orders_tenantId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_tenantId_createdAt_idx" ON public.orders USING btree ("tenantId", "createdAt");


--
-- Name: orders_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_tenantId_idx" ON public.orders USING btree ("tenantId");


--
-- Name: orders_tenantId_orderNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "orders_tenantId_orderNumber_key" ON public.orders USING btree ("tenantId", "orderNumber");


--
-- Name: orders_tenantId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_tenantId_status_idx" ON public.orders USING btree ("tenantId", status);


--
-- Name: orders_tenantId_tableId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_tenantId_tableId_status_idx" ON public.orders USING btree ("tenantId", "tableId", status);


--
-- Name: orders_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_userId_idx" ON public.orders USING btree ("userId");


--
-- Name: page_views_city_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX page_views_city_idx ON public.page_views USING btree (city);


--
-- Name: page_views_country_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX page_views_country_idx ON public.page_views USING btree (country);


--
-- Name: page_views_page_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "page_views_page_createdAt_idx" ON public.page_views USING btree (page, "createdAt");


--
-- Name: page_views_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "page_views_sessionId_idx" ON public.page_views USING btree ("sessionId");


--
-- Name: payments_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "payments_orderId_idx" ON public.payments USING btree ("orderId");


--
-- Name: payments_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payments_status_idx ON public.payments USING btree (status);


--
-- Name: payments_tenantId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "payments_tenantId_createdAt_idx" ON public.payments USING btree ("tenantId", "createdAt");


--
-- Name: payments_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "payments_tenantId_idx" ON public.payments USING btree ("tenantId");


--
-- Name: payments_tenantId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "payments_tenantId_status_idx" ON public.payments USING btree ("tenantId", status);


--
-- Name: phone_verifications_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX phone_verifications_code_idx ON public.phone_verifications USING btree (code);


--
-- Name: phone_verifications_expiresAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "phone_verifications_expiresAt_idx" ON public.phone_verifications USING btree ("expiresAt");


--
-- Name: phone_verifications_phone_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "phone_verifications_phone_tenantId_idx" ON public.phone_verifications USING btree (phone, "tenantId");


--
-- Name: pos_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pos_settings_tenantId_idx" ON public.pos_settings USING btree ("tenantId");


--
-- Name: pos_settings_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "pos_settings_tenantId_key" ON public.pos_settings USING btree ("tenantId");


--
-- Name: product_images_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_images_tenantId_idx" ON public.product_images USING btree ("tenantId");


--
-- Name: product_modifier_groups_groupId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_modifier_groups_groupId_idx" ON public.product_modifier_groups USING btree ("groupId");


--
-- Name: product_modifier_groups_productId_groupId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "product_modifier_groups_productId_groupId_key" ON public.product_modifier_groups USING btree ("productId", "groupId");


--
-- Name: product_modifier_groups_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_modifier_groups_productId_idx" ON public.product_modifier_groups USING btree ("productId");


--
-- Name: product_to_images_imageId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_to_images_imageId_idx" ON public.product_to_images USING btree ("imageId");


--
-- Name: product_to_images_productId_imageId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "product_to_images_productId_imageId_key" ON public.product_to_images USING btree ("productId", "imageId");


--
-- Name: product_to_images_productId_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_to_images_productId_order_idx" ON public.product_to_images USING btree ("productId", "order");


--
-- Name: products_categoryId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "products_categoryId_idx" ON public.products USING btree ("categoryId");


--
-- Name: products_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "products_tenantId_idx" ON public.products USING btree ("tenantId");


--
-- Name: public_reviews_rating_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX public_reviews_rating_idx ON public.public_reviews USING btree (rating);


--
-- Name: public_reviews_status_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "public_reviews_status_createdAt_idx" ON public.public_reviews USING btree (status, "createdAt");


--
-- Name: purchase_order_items_purchaseOrderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "purchase_order_items_purchaseOrderId_idx" ON public.purchase_order_items USING btree ("purchaseOrderId");


--
-- Name: purchase_order_items_stockItemId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "purchase_order_items_stockItemId_idx" ON public.purchase_order_items USING btree ("stockItemId");


--
-- Name: purchase_orders_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX purchase_orders_status_idx ON public.purchase_orders USING btree (status);


--
-- Name: purchase_orders_supplierId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "purchase_orders_supplierId_idx" ON public.purchase_orders USING btree ("supplierId");


--
-- Name: purchase_orders_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "purchase_orders_tenantId_idx" ON public.purchase_orders USING btree ("tenantId");


--
-- Name: purchase_orders_tenantId_orderNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "purchase_orders_tenantId_orderNumber_key" ON public.purchase_orders USING btree ("tenantId", "orderNumber");


--
-- Name: qr_menu_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "qr_menu_settings_tenantId_idx" ON public.qr_menu_settings USING btree ("tenantId");


--
-- Name: qr_menu_settings_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "qr_menu_settings_tenantId_key" ON public.qr_menu_settings USING btree ("tenantId");


--
-- Name: recipe_ingredients_recipeId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "recipe_ingredients_recipeId_idx" ON public.recipe_ingredients USING btree ("recipeId");


--
-- Name: recipe_ingredients_recipeId_stockItemId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "recipe_ingredients_recipeId_stockItemId_key" ON public.recipe_ingredients USING btree ("recipeId", "stockItemId");


--
-- Name: recipe_ingredients_stockItemId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "recipe_ingredients_stockItemId_idx" ON public.recipe_ingredients USING btree ("stockItemId");


--
-- Name: recipes_productId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "recipes_productId_key" ON public.recipes USING btree ("productId");


--
-- Name: recipes_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "recipes_tenantId_idx" ON public.recipes USING btree ("tenantId");


--
-- Name: refresh_tokens_expiresAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "refresh_tokens_expiresAt_idx" ON public.refresh_tokens USING btree ("expiresAt");


--
-- Name: refresh_tokens_tokenHash_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "refresh_tokens_tokenHash_key" ON public.refresh_tokens USING btree ("tokenHash");


--
-- Name: refresh_tokens_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "refresh_tokens_userId_idx" ON public.refresh_tokens USING btree ("userId");


--
-- Name: reservation_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "reservation_settings_tenantId_idx" ON public.reservation_settings USING btree ("tenantId");


--
-- Name: reservation_settings_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "reservation_settings_tenantId_key" ON public.reservation_settings USING btree ("tenantId");


--
-- Name: reservations_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "reservations_tableId_idx" ON public.reservations USING btree ("tableId");


--
-- Name: reservations_tenantId_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "reservations_tenantId_date_idx" ON public.reservations USING btree ("tenantId", date);


--
-- Name: reservations_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "reservations_tenantId_idx" ON public.reservations USING btree ("tenantId");


--
-- Name: reservations_tenantId_reservationNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "reservations_tenantId_reservationNumber_key" ON public.reservations USING btree ("tenantId", "reservationNumber");


--
-- Name: reservations_tenantId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "reservations_tenantId_status_idx" ON public.reservations USING btree ("tenantId", status);


--
-- Name: reserved_subdomains_availableAfter_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "reserved_subdomains_availableAfter_idx" ON public.reserved_subdomains USING btree ("availableAfter");


--
-- Name: reserved_subdomains_subdomain_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX reserved_subdomains_subdomain_key ON public.reserved_subdomains USING btree (subdomain);


--
-- Name: restaurant_layouts_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "restaurant_layouts_tenantId_idx" ON public.restaurant_layouts USING btree ("tenantId");


--
-- Name: restaurant_layouts_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "restaurant_layouts_tenantId_key" ON public.restaurant_layouts USING btree ("tenantId");


--
-- Name: sales_invoice_items_invoiceId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "sales_invoice_items_invoiceId_idx" ON public.sales_invoice_items USING btree ("invoiceId");


--
-- Name: sales_invoices_issueDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "sales_invoices_issueDate_idx" ON public.sales_invoices USING btree ("issueDate");


--
-- Name: sales_invoices_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "sales_invoices_orderId_idx" ON public.sales_invoices USING btree ("orderId");


--
-- Name: sales_invoices_orderId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "sales_invoices_orderId_key" ON public.sales_invoices USING btree ("orderId");


--
-- Name: sales_invoices_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sales_invoices_status_idx ON public.sales_invoices USING btree (status);


--
-- Name: sales_invoices_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "sales_invoices_tenantId_idx" ON public.sales_invoices USING btree ("tenantId");


--
-- Name: sales_invoices_tenantId_invoiceNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "sales_invoices_tenantId_invoiceNumber_key" ON public.sales_invoices USING btree ("tenantId", "invoiceNumber");


--
-- Name: shift_assignments_shiftTemplateId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "shift_assignments_shiftTemplateId_idx" ON public.shift_assignments USING btree ("shiftTemplateId");


--
-- Name: shift_assignments_tenantId_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "shift_assignments_tenantId_date_idx" ON public.shift_assignments USING btree ("tenantId", date);


--
-- Name: shift_assignments_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "shift_assignments_tenantId_idx" ON public.shift_assignments USING btree ("tenantId");


--
-- Name: shift_assignments_userId_date_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "shift_assignments_userId_date_key" ON public.shift_assignments USING btree ("userId", date);


--
-- Name: shift_assignments_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "shift_assignments_userId_idx" ON public.shift_assignments USING btree ("userId");


--
-- Name: shift_swap_requests_requesterId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "shift_swap_requests_requesterId_idx" ON public.shift_swap_requests USING btree ("requesterId");


--
-- Name: shift_swap_requests_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shift_swap_requests_status_idx ON public.shift_swap_requests USING btree (status);


--
-- Name: shift_swap_requests_targetId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "shift_swap_requests_targetId_idx" ON public.shift_swap_requests USING btree ("targetId");


--
-- Name: shift_swap_requests_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "shift_swap_requests_tenantId_idx" ON public.shift_swap_requests USING btree ("tenantId");


--
-- Name: shift_templates_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "shift_templates_tenantId_idx" ON public.shift_templates USING btree ("tenantId");


--
-- Name: sms_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "sms_settings_tenantId_idx" ON public.sms_settings USING btree ("tenantId");


--
-- Name: sms_settings_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "sms_settings_tenantId_key" ON public.sms_settings USING btree ("tenantId");


--
-- Name: stock_batches_expiryDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_batches_expiryDate_idx" ON public.stock_batches USING btree ("expiryDate");


--
-- Name: stock_batches_stockItemId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_batches_stockItemId_idx" ON public.stock_batches USING btree ("stockItemId");


--
-- Name: stock_batches_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_batches_tenantId_idx" ON public.stock_batches USING btree ("tenantId");


--
-- Name: stock_count_items_stockCountId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_count_items_stockCountId_idx" ON public.stock_count_items USING btree ("stockCountId");


--
-- Name: stock_count_items_stockCountId_stockItemId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "stock_count_items_stockCountId_stockItemId_key" ON public.stock_count_items USING btree ("stockCountId", "stockItemId");


--
-- Name: stock_count_items_stockItemId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_count_items_stockItemId_idx" ON public.stock_count_items USING btree ("stockItemId");


--
-- Name: stock_counts_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX stock_counts_status_idx ON public.stock_counts USING btree (status);


--
-- Name: stock_counts_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_counts_tenantId_idx" ON public.stock_counts USING btree ("tenantId");


--
-- Name: stock_item_categories_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_item_categories_tenantId_idx" ON public.stock_item_categories USING btree ("tenantId");


--
-- Name: stock_item_categories_tenantId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "stock_item_categories_tenantId_name_key" ON public.stock_item_categories USING btree ("tenantId", name);


--
-- Name: stock_items_categoryId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_items_categoryId_idx" ON public.stock_items USING btree ("categoryId");


--
-- Name: stock_items_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_items_isActive_idx" ON public.stock_items USING btree ("isActive");


--
-- Name: stock_items_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_items_tenantId_idx" ON public.stock_items USING btree ("tenantId");


--
-- Name: stock_items_tenantId_sku_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "stock_items_tenantId_sku_key" ON public.stock_items USING btree ("tenantId", sku);


--
-- Name: stock_movements_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_movements_productId_idx" ON public.stock_movements USING btree ("productId");


--
-- Name: stock_movements_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_movements_tenantId_idx" ON public.stock_movements USING btree ("tenantId");


--
-- Name: stock_movements_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_movements_userId_idx" ON public.stock_movements USING btree ("userId");


--
-- Name: stock_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_settings_tenantId_idx" ON public.stock_settings USING btree ("tenantId");


--
-- Name: stock_settings_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "stock_settings_tenantId_key" ON public.stock_settings USING btree ("tenantId");


--
-- Name: subscription_payments_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscription_payments_createdAt_idx" ON public.subscription_payments USING btree ("createdAt");


--
-- Name: subscription_payments_externalReference_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscription_payments_externalReference_key" ON public.subscription_payments USING btree ("externalReference");


--
-- Name: subscription_payments_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX subscription_payments_status_idx ON public.subscription_payments USING btree (status);


--
-- Name: subscription_payments_subscriptionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscription_payments_subscriptionId_idx" ON public.subscription_payments USING btree ("subscriptionId");


--
-- Name: subscription_plans_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX subscription_plans_name_key ON public.subscription_plans USING btree (name);


--
-- Name: subscriptions_currentPeriodEnd_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscriptions_currentPeriodEnd_idx" ON public.subscriptions USING btree ("currentPeriodEnd");


--
-- Name: subscriptions_planId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscriptions_planId_idx" ON public.subscriptions USING btree ("planId");


--
-- Name: subscriptions_scheduledDowngradePlanId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscriptions_scheduledDowngradePlanId_idx" ON public.subscriptions USING btree ("scheduledDowngradePlanId");


--
-- Name: subscriptions_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX subscriptions_status_idx ON public.subscriptions USING btree (status);


--
-- Name: subscriptions_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscriptions_tenantId_idx" ON public.subscriptions USING btree ("tenantId");


--
-- Name: super_admins_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX super_admins_email_key ON public.super_admins USING btree (email);


--
-- Name: supplier_stock_items_stockItemId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "supplier_stock_items_stockItemId_idx" ON public.supplier_stock_items USING btree ("stockItemId");


--
-- Name: supplier_stock_items_supplierId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "supplier_stock_items_supplierId_idx" ON public.supplier_stock_items USING btree ("supplierId");


--
-- Name: supplier_stock_items_supplierId_stockItemId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "supplier_stock_items_supplierId_stockItemId_key" ON public.supplier_stock_items USING btree ("supplierId", "stockItemId");


--
-- Name: suppliers_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "suppliers_isActive_idx" ON public.suppliers USING btree ("isActive");


--
-- Name: suppliers_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "suppliers_tenantId_idx" ON public.suppliers USING btree ("tenantId");


--
-- Name: table_analytics_tableId_date_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "table_analytics_tableId_date_key" ON public.table_analytics USING btree ("tableId", date);


--
-- Name: table_analytics_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "table_analytics_tableId_idx" ON public.table_analytics USING btree ("tableId");


--
-- Name: table_analytics_tenantId_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "table_analytics_tenantId_date_idx" ON public.table_analytics USING btree ("tenantId", date);


--
-- Name: tables_tenantId_groupId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "tables_tenantId_groupId_idx" ON public.tables USING btree ("tenantId", "groupId");


--
-- Name: tables_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "tables_tenantId_idx" ON public.tables USING btree ("tenantId");


--
-- Name: tables_tenantId_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "tables_tenantId_number_key" ON public.tables USING btree ("tenantId", number);


--
-- Name: tenants_currentPlanId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "tenants_currentPlanId_idx" ON public.tenants USING btree ("currentPlanId");


--
-- Name: tenants_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tenants_status_idx ON public.tenants USING btree (status);


--
-- Name: tenants_subdomain_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX tenants_subdomain_key ON public.tenants USING btree (subdomain);


--
-- Name: traffic_flow_records_cellX_cellZ_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "traffic_flow_records_cellX_cellZ_idx" ON public.traffic_flow_records USING btree ("cellX", "cellZ");


--
-- Name: traffic_flow_records_tenantId_hourBucket_cellX_cellZ_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "traffic_flow_records_tenantId_hourBucket_cellX_cellZ_key" ON public.traffic_flow_records USING btree ("tenantId", "hourBucket", "cellX", "cellZ");


--
-- Name: traffic_flow_records_tenantId_hourBucket_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "traffic_flow_records_tenantId_hourBucket_idx" ON public.traffic_flow_records USING btree ("tenantId", "hourBucket");


--
-- Name: user_activities_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_activities_createdAt_idx" ON public.user_activities USING btree ("createdAt");


--
-- Name: user_activities_tenantId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_activities_tenantId_createdAt_idx" ON public.user_activities USING btree ("tenantId", "createdAt");


--
-- Name: user_activities_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_activities_tenantId_idx" ON public.user_activities USING btree ("tenantId");


--
-- Name: user_activities_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_activities_userId_idx" ON public.user_activities USING btree ("userId");


--
-- Name: user_notification_reads_notificationId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_notification_reads_notificationId_idx" ON public.user_notification_reads USING btree ("notificationId");


--
-- Name: user_notification_reads_notificationId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "user_notification_reads_notificationId_userId_key" ON public.user_notification_reads USING btree ("notificationId", "userId");


--
-- Name: user_notification_reads_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_notification_reads_userId_idx" ON public.user_notification_reads USING btree ("userId");


--
-- Name: users_appleId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "users_appleId_key" ON public.users USING btree ("appleId");


--
-- Name: users_approvedById_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "users_approvedById_idx" ON public.users USING btree ("approvedById");


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_googleId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "users_googleId_key" ON public.users USING btree ("googleId");


--
-- Name: users_resetTokenHash_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "users_resetTokenHash_key" ON public.users USING btree ("resetTokenHash");


--
-- Name: users_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "users_tenantId_idx" ON public.users USING btree ("tenantId");


--
-- Name: waiter_requests_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "waiter_requests_sessionId_idx" ON public.waiter_requests USING btree ("sessionId");


--
-- Name: waiter_requests_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX waiter_requests_status_idx ON public.waiter_requests USING btree (status);


--
-- Name: waiter_requests_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "waiter_requests_tableId_idx" ON public.waiter_requests USING btree ("tableId");


--
-- Name: waiter_requests_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "waiter_requests_tenantId_idx" ON public.waiter_requests USING btree ("tenantId");


--
-- Name: waiter_requests_tenantId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "waiter_requests_tenantId_status_idx" ON public.waiter_requests USING btree ("tenantId", status);


--
-- Name: waste_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "waste_logs_createdAt_idx" ON public.waste_logs USING btree ("createdAt");


--
-- Name: waste_logs_reason_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX waste_logs_reason_idx ON public.waste_logs USING btree (reason);


--
-- Name: waste_logs_stockItemId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "waste_logs_stockItemId_idx" ON public.waste_logs USING btree ("stockItemId");


--
-- Name: waste_logs_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "waste_logs_tenantId_idx" ON public.waste_logs USING btree ("tenantId");


--
-- Name: z_reports_closedById_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "z_reports_closedById_idx" ON public.z_reports USING btree ("closedById");


--
-- Name: z_reports_reportDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "z_reports_reportDate_idx" ON public.z_reports USING btree ("reportDate");


--
-- Name: z_reports_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "z_reports_tenantId_idx" ON public.z_reports USING btree ("tenantId");


--
-- Name: z_reports_tenantId_reportNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "z_reports_tenantId_reportNumber_key" ON public.z_reports USING btree ("tenantId", "reportNumber");


--
-- Name: accounting_settings accounting_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounting_settings
    ADD CONSTRAINT "accounting_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: analytics_heatmap_cache analytics_heatmap_cache_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_heatmap_cache
    ADD CONSTRAINT "analytics_heatmap_cache_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: analytics_insights analytics_insights_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_insights
    ADD CONSTRAINT "analytics_insights_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: api_keys api_keys_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT "api_keys_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: attendances attendances_shiftAssignmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT "attendances_shiftAssignmentId_fkey" FOREIGN KEY ("shiftAssignmentId") REFERENCES public.shift_assignments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: attendances attendances_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT "attendances_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: attendances attendances_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT "attendances_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bill_requests bill_requests_acknowledgedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_requests
    ADD CONSTRAINT "bill_requests_acknowledgedById_fkey" FOREIGN KEY ("acknowledgedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bill_requests bill_requests_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_requests
    ADD CONSTRAINT "bill_requests_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bill_requests bill_requests_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_requests
    ADD CONSTRAINT "bill_requests_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cameras cameras_edgeDeviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cameras
    ADD CONSTRAINT "cameras_edgeDeviceId_fkey" FOREIGN KEY ("edgeDeviceId") REFERENCES public.edge_devices(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cameras cameras_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cameras
    ADD CONSTRAINT "cameras_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cash_drawer_movements cash_drawer_movements_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cash_drawer_movements
    ADD CONSTRAINT "cash_drawer_movements_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cash_drawer_movements cash_drawer_movements_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cash_drawer_movements
    ADD CONSTRAINT "cash_drawer_movements_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: cash_drawer_movements cash_drawer_movements_zReportId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cash_drawer_movements
    ADD CONSTRAINT "cash_drawer_movements_zReportId_fkey" FOREIGN KEY ("zReportId") REFERENCES public.z_reports(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: categories categories_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "categories_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commissions commissions_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commissions
    ADD CONSTRAINT "commissions_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: commissions commissions_marketingUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commissions
    ADD CONSTRAINT "commissions_marketingUserId_fkey" FOREIGN KEY ("marketingUserId") REFERENCES public.marketing_users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: commissions commissions_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commissions
    ADD CONSTRAINT "commissions_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: customer_referrals customer_referrals_referredId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_referrals
    ADD CONSTRAINT "customer_referrals_referredId_fkey" FOREIGN KEY ("referredId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_referrals customer_referrals_referrerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_referrals
    ADD CONSTRAINT "customer_referrals_referrerId_fkey" FOREIGN KEY ("referrerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_sessions customer_sessions_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_sessions
    ADD CONSTRAINT "customer_sessions_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: customer_sessions customer_sessions_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_sessions
    ADD CONSTRAINT "customer_sessions_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customers customers_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT "customers_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: delivery_platform_configs delivery_platform_configs_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_platform_configs
    ADD CONSTRAINT "delivery_platform_configs_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: delivery_platform_logs delivery_platform_logs_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_platform_logs
    ADD CONSTRAINT "delivery_platform_logs_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: edge_devices edge_devices_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.edge_devices
    ADD CONSTRAINT "edge_devices_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ingredient_movements ingredient_movements_stockItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingredient_movements
    ADD CONSTRAINT "ingredient_movements_stockItemId_fkey" FOREIGN KEY ("stockItemId") REFERENCES public.stock_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ingredient_movements ingredient_movements_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingredient_movements
    ADD CONSTRAINT "ingredient_movements_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: integration_settings integration_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_settings
    ADD CONSTRAINT "integration_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoices invoices_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public.subscription_payments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lead_activities lead_activities_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_activities
    ADD CONSTRAINT "lead_activities_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.marketing_users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lead_activities lead_activities_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_activities
    ADD CONSTRAINT "lead_activities_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lead_offers lead_offers_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_offers
    ADD CONSTRAINT "lead_offers_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.marketing_users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lead_offers lead_offers_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_offers
    ADD CONSTRAINT "lead_offers_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lead_offers lead_offers_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_offers
    ADD CONSTRAINT "lead_offers_planId_fkey" FOREIGN KEY ("planId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: leads leads_assignedToId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT "leads_assignedToId_fkey" FOREIGN KEY ("assignedToId") REFERENCES public.marketing_users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: leads leads_convertedTenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT "leads_convertedTenantId_fkey" FOREIGN KEY ("convertedTenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: loyalty_transactions loyalty_transactions_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT "loyalty_transactions_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: loyalty_transactions loyalty_transactions_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT "loyalty_transactions_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: marketing_notifications marketing_notifications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_notifications
    ADD CONSTRAINT "marketing_notifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.marketing_users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: marketing_tasks marketing_tasks_assignedToId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_tasks
    ADD CONSTRAINT "marketing_tasks_assignedToId_fkey" FOREIGN KEY ("assignedToId") REFERENCES public.marketing_users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: marketing_tasks marketing_tasks_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_tasks
    ADD CONSTRAINT "marketing_tasks_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: menu_item_mappings menu_item_mappings_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item_mappings
    ADD CONSTRAINT "menu_item_mappings_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: menu_item_mappings menu_item_mappings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item_mappings
    ADD CONSTRAINT "menu_item_mappings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: modifier_groups modifier_groups_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifier_groups
    ADD CONSTRAINT "modifier_groups_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: modifiers modifiers_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifiers
    ADD CONSTRAINT "modifiers_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public.modifier_groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: modifiers modifiers_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifiers
    ADD CONSTRAINT "modifiers_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: occupancy_records occupancy_records_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.occupancy_records
    ADD CONSTRAINT "occupancy_records_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: occupancy_records occupancy_records_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.occupancy_records
    ADD CONSTRAINT "occupancy_records_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_item_modifiers order_item_modifiers_modifierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item_modifiers
    ADD CONSTRAINT "order_item_modifiers_modifierId_fkey" FOREIGN KEY ("modifierId") REFERENCES public.modifiers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: order_item_modifiers order_item_modifiers_orderItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item_modifiers
    ADD CONSTRAINT "order_item_modifiers_orderItemId_fkey" FOREIGN KEY ("orderItemId") REFERENCES public.order_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_items order_items_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "order_items_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_items order_items_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "order_items_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: orders orders_approvedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_approvedById_fkey" FOREIGN KEY ("approvedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orders orders_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payments payments_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payments payments_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phone_verifications phone_verifications_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.phone_verifications
    ADD CONSTRAINT "phone_verifications_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pos_settings pos_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pos_settings
    ADD CONSTRAINT "pos_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_images product_images_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT "product_images_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_modifier_groups product_modifier_groups_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_modifier_groups
    ADD CONSTRAINT "product_modifier_groups_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public.modifier_groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_modifier_groups product_modifier_groups_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_modifier_groups
    ADD CONSTRAINT "product_modifier_groups_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_to_images product_to_images_imageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_to_images
    ADD CONSTRAINT "product_to_images_imageId_fkey" FOREIGN KEY ("imageId") REFERENCES public.product_images(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_to_images product_to_images_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_to_images
    ADD CONSTRAINT "product_to_images_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: products products_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "products_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: products products_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "products_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: purchase_order_items purchase_order_items_purchaseOrderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT "purchase_order_items_purchaseOrderId_fkey" FOREIGN KEY ("purchaseOrderId") REFERENCES public.purchase_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: purchase_order_items purchase_order_items_stockItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT "purchase_order_items_stockItemId_fkey" FOREIGN KEY ("stockItemId") REFERENCES public.stock_items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_orders purchase_orders_supplierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT "purchase_orders_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_orders purchase_orders_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT "purchase_orders_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: qr_menu_settings qr_menu_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qr_menu_settings
    ADD CONSTRAINT "qr_menu_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: recipe_ingredients recipe_ingredients_recipeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT "recipe_ingredients_recipeId_fkey" FOREIGN KEY ("recipeId") REFERENCES public.recipes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: recipe_ingredients recipe_ingredients_stockItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT "recipe_ingredients_stockItemId_fkey" FOREIGN KEY ("stockItemId") REFERENCES public.stock_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: recipes recipes_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT "recipes_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: recipes recipes_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT "recipes_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT "refresh_tokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reservation_settings reservation_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservation_settings
    ADD CONSTRAINT "reservation_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reservations reservations_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT "reservations_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: reservations reservations_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT "reservations_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restaurant_layouts restaurant_layouts_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant_layouts
    ADD CONSTRAINT "restaurant_layouts_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sales_invoice_items sales_invoice_items_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_invoice_items
    ADD CONSTRAINT "sales_invoice_items_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.sales_invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sales_invoices sales_invoices_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_invoices
    ADD CONSTRAINT "sales_invoices_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sales_invoices sales_invoices_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_invoices
    ADD CONSTRAINT "sales_invoices_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shift_assignments shift_assignments_shiftTemplateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift_assignments
    ADD CONSTRAINT "shift_assignments_shiftTemplateId_fkey" FOREIGN KEY ("shiftTemplateId") REFERENCES public.shift_templates(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shift_assignments shift_assignments_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift_assignments
    ADD CONSTRAINT "shift_assignments_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shift_assignments shift_assignments_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift_assignments
    ADD CONSTRAINT "shift_assignments_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shift_swap_requests shift_swap_requests_approvedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift_swap_requests
    ADD CONSTRAINT "shift_swap_requests_approvedById_fkey" FOREIGN KEY ("approvedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: shift_swap_requests shift_swap_requests_requesterAssignmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift_swap_requests
    ADD CONSTRAINT "shift_swap_requests_requesterAssignmentId_fkey" FOREIGN KEY ("requesterAssignmentId") REFERENCES public.shift_assignments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shift_swap_requests shift_swap_requests_requesterId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift_swap_requests
    ADD CONSTRAINT "shift_swap_requests_requesterId_fkey" FOREIGN KEY ("requesterId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shift_swap_requests shift_swap_requests_targetAssignmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift_swap_requests
    ADD CONSTRAINT "shift_swap_requests_targetAssignmentId_fkey" FOREIGN KEY ("targetAssignmentId") REFERENCES public.shift_assignments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shift_swap_requests shift_swap_requests_targetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift_swap_requests
    ADD CONSTRAINT "shift_swap_requests_targetId_fkey" FOREIGN KEY ("targetId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shift_swap_requests shift_swap_requests_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift_swap_requests
    ADD CONSTRAINT "shift_swap_requests_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shift_templates shift_templates_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift_templates
    ADD CONSTRAINT "shift_templates_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sms_settings sms_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sms_settings
    ADD CONSTRAINT "sms_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_batches stock_batches_purchaseOrderItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_batches
    ADD CONSTRAINT "stock_batches_purchaseOrderItemId_fkey" FOREIGN KEY ("purchaseOrderItemId") REFERENCES public.purchase_order_items(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: stock_batches stock_batches_stockItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_batches
    ADD CONSTRAINT "stock_batches_stockItemId_fkey" FOREIGN KEY ("stockItemId") REFERENCES public.stock_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_batches stock_batches_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_batches
    ADD CONSTRAINT "stock_batches_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_count_items stock_count_items_stockCountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_count_items
    ADD CONSTRAINT "stock_count_items_stockCountId_fkey" FOREIGN KEY ("stockCountId") REFERENCES public.stock_counts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_count_items stock_count_items_stockItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_count_items
    ADD CONSTRAINT "stock_count_items_stockItemId_fkey" FOREIGN KEY ("stockItemId") REFERENCES public.stock_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_counts stock_counts_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_counts
    ADD CONSTRAINT "stock_counts_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_item_categories stock_item_categories_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_item_categories
    ADD CONSTRAINT "stock_item_categories_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_items stock_items_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_items
    ADD CONSTRAINT "stock_items_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.stock_item_categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: stock_items stock_items_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_items
    ADD CONSTRAINT "stock_items_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT "stock_movements_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT "stock_movements_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT "stock_movements_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_settings stock_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_settings
    ADD CONSTRAINT "stock_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subscription_payments subscription_payments_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT "subscription_payments_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT "subscriptions_planId_fkey" FOREIGN KEY ("planId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: subscriptions subscriptions_scheduledDowngradePlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT "subscriptions_scheduledDowngradePlanId_fkey" FOREIGN KEY ("scheduledDowngradePlanId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: subscriptions subscriptions_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT "subscriptions_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: supplier_stock_items supplier_stock_items_stockItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_stock_items
    ADD CONSTRAINT "supplier_stock_items_stockItemId_fkey" FOREIGN KEY ("stockItemId") REFERENCES public.stock_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: supplier_stock_items supplier_stock_items_supplierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_stock_items
    ADD CONSTRAINT "supplier_stock_items_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: suppliers suppliers_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT "suppliers_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: table_analytics table_analytics_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.table_analytics
    ADD CONSTRAINT "table_analytics_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: table_analytics table_analytics_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.table_analytics
    ADD CONSTRAINT "table_analytics_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tables tables_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT "tables_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tenants tenants_currentPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT "tenants_currentPlanId_fkey" FOREIGN KEY ("currentPlanId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: traffic_flow_records traffic_flow_records_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.traffic_flow_records
    ADD CONSTRAINT "traffic_flow_records_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_activities user_activities_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activities
    ADD CONSTRAINT "user_activities_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_notification_reads user_notification_reads_notificationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_reads
    ADD CONSTRAINT "user_notification_reads_notificationId_fkey" FOREIGN KEY ("notificationId") REFERENCES public.notifications(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_notification_reads user_notification_reads_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_reads
    ADD CONSTRAINT "user_notification_reads_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_approvedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_approvedById_fkey" FOREIGN KEY ("approvedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: users users_reactivatedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_reactivatedById_fkey" FOREIGN KEY ("reactivatedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: users users_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: waiter_requests waiter_requests_acknowledgedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waiter_requests
    ADD CONSTRAINT "waiter_requests_acknowledgedById_fkey" FOREIGN KEY ("acknowledgedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: waiter_requests waiter_requests_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waiter_requests
    ADD CONSTRAINT "waiter_requests_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: waiter_requests waiter_requests_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waiter_requests
    ADD CONSTRAINT "waiter_requests_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: waste_logs waste_logs_stockItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waste_logs
    ADD CONSTRAINT "waste_logs_stockItemId_fkey" FOREIGN KEY ("stockItemId") REFERENCES public.stock_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: waste_logs waste_logs_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waste_logs
    ADD CONSTRAINT "waste_logs_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: z_reports z_reports_closedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.z_reports
    ADD CONSTRAINT "z_reports_closedById_fkey" FOREIGN KEY ("closedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: z_reports z_reports_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.z_reports
    ADD CONSTRAINT "z_reports_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict QTJ5zy0KPH5PRhFLeMbWGZ38AO1u4vYoBtU6jWi6Kxeqc0Y3YHCTaTnWIKCuyXx

