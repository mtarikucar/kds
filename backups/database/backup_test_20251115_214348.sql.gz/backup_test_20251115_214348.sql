--
-- PostgreSQL database dump
--

\restrict hwLGgq1WSRuvw5zGd2YLhuYHNNDnNBtKjIkO3UraXt0OvlMzad7x5dUxEAaKhsI

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_keys (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    key text NOT NULL,
    "keyPrefix" text NOT NULL,
    scopes text[],
    "webhookUrl" text,
    "webhookEvents" text[] DEFAULT ARRAY[]::text[],
    "isActive" boolean DEFAULT true NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "lastUsedAt" timestamp(3) without time zone,
    "usageCount" integer DEFAULT 0 NOT NULL,
    "ipWhitelist" text[] DEFAULT ARRAY[]::text[],
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.api_keys OWNER TO postgres;

--
-- Name: bill_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bill_requests (
    id text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "sessionId" text NOT NULL,
    "tableId" text NOT NULL,
    "acknowledgedAt" timestamp(3) without time zone,
    "acknowledgedById" text,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.bill_requests OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: contact_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact_messages (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    message text NOT NULL,
    status text DEFAULT 'NEW'::text NOT NULL,
    "adminNotes" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.contact_messages OWNER TO postgres;

--
-- Name: customer_referrals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_referrals (
    id text NOT NULL,
    "referrerId" text NOT NULL,
    "referredId" text NOT NULL,
    "referralCode" text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "referrerReward" integer DEFAULT 0 NOT NULL,
    "referredReward" integer DEFAULT 0 NOT NULL,
    "rewardedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone
);


ALTER TABLE public.customer_referrals OWNER TO postgres;

--
-- Name: customer_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_sessions (
    id text NOT NULL,
    "sessionId" text NOT NULL,
    "customerId" text,
    "tableId" text,
    phone text,
    "isActive" boolean DEFAULT true NOT NULL,
    "userAgent" text,
    "ipAddress" text,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "lastActivity" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.customer_sessions OWNER TO postgres;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id text NOT NULL,
    name text NOT NULL,
    email text,
    phone text,
    "phoneVerified" boolean DEFAULT false NOT NULL,
    "loyaltyPoints" integer DEFAULT 0 NOT NULL,
    "loyaltyTier" text DEFAULT 'BRONZE'::text NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[],
    notes text,
    "referralCode" text,
    "referredBy" text,
    "totalOrders" integer DEFAULT 0 NOT NULL,
    "totalSpent" numeric(10,2) DEFAULT 0 NOT NULL,
    "averageOrder" numeric(10,2) DEFAULT 0 NOT NULL,
    birthday timestamp(3) without time zone,
    preferences jsonb,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "lastVisit" timestamp(3) without time zone
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: desktop_releases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.desktop_releases (
    id text NOT NULL,
    version text NOT NULL,
    "releaseTag" text NOT NULL,
    published boolean DEFAULT false NOT NULL,
    "pubDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "windowsUrl" text,
    "windowsSignature" text,
    "macArmUrl" text,
    "macArmSignature" text,
    "macIntelUrl" text,
    "macIntelSignature" text,
    "linuxUrl" text,
    "linuxSignature" text,
    "releaseNotes" text NOT NULL,
    changelog text,
    "downloadCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.desktop_releases OWNER TO postgres;

--
-- Name: integration_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integration_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "integrationType" text NOT NULL,
    provider text NOT NULL,
    name text NOT NULL,
    config jsonb NOT NULL,
    "isEnabled" boolean DEFAULT false NOT NULL,
    "isConfigured" boolean DEFAULT false NOT NULL,
    "lastSyncedAt" timestamp(3) without time zone,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.integration_settings OWNER TO postgres;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    "paymentId" text,
    "invoiceNumber" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    tax numeric(10,2) DEFAULT 0 NOT NULL,
    total numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "periodStart" timestamp(3) without time zone NOT NULL,
    "periodEnd" timestamp(3) without time zone NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "paidAt" timestamp(3) without time zone,
    "voidedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    description text,
    notes text,
    "pdfUrl" text
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: loyalty_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.loyalty_transactions (
    id text NOT NULL,
    "customerId" text NOT NULL,
    type text NOT NULL,
    points integer NOT NULL,
    description text NOT NULL,
    "orderId" text,
    "orderNumber" text,
    "orderAmount" numeric(10,2),
    "referredCustomerId" text,
    "balanceBefore" integer NOT NULL,
    "balanceAfter" integer NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.loyalty_transactions OWNER TO postgres;

--
-- Name: modifier_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.modifier_groups (
    id text NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "selectionType" text DEFAULT 'SINGLE'::text NOT NULL,
    "minSelections" integer DEFAULT 0 NOT NULL,
    "maxSelections" integer,
    "isRequired" boolean DEFAULT false NOT NULL,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.modifier_groups OWNER TO postgres;

--
-- Name: modifiers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.modifiers (
    id text NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "priceAdjustment" numeric(10,2) DEFAULT 0 NOT NULL,
    "isAvailable" boolean DEFAULT true NOT NULL,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "groupId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.modifiers OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    type text NOT NULL,
    data jsonb,
    "userId" text,
    "tenantId" text NOT NULL,
    "isGlobal" boolean DEFAULT false NOT NULL,
    priority text DEFAULT 'NORMAL'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: order_item_modifiers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_item_modifiers (
    id text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    "priceAdjustment" numeric(10,2) NOT NULL,
    "orderItemId" text NOT NULL,
    "modifierId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.order_item_modifiers OWNER TO postgres;

--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id text NOT NULL,
    quantity integer NOT NULL,
    "unitPrice" numeric(10,2) NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    "modifierTotal" numeric(10,2) DEFAULT 0 NOT NULL,
    notes text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "orderId" text NOT NULL,
    "productId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id text NOT NULL,
    "orderNumber" text NOT NULL,
    type text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "totalAmount" numeric(10,2) NOT NULL,
    discount numeric(10,2) DEFAULT 0 NOT NULL,
    "finalAmount" numeric(10,2) NOT NULL,
    notes text,
    "customerName" text,
    "sessionId" text,
    "customerPhone" text,
    "requiresApproval" boolean DEFAULT false NOT NULL,
    "approvedAt" timestamp(3) without time zone,
    "tableId" text,
    "customerId" text,
    "userId" text,
    "approvedById" text,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "paidAt" timestamp(3) without time zone
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id text NOT NULL,
    amount numeric(10,2) NOT NULL,
    method text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "transactionId" text,
    notes text,
    "orderId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "paidAt" timestamp(3) without time zone
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: pending_plan_changes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pending_plan_changes (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    "currentPlanId" text NOT NULL,
    "newPlanId" text NOT NULL,
    "newBillingCycle" text NOT NULL,
    "isUpgrade" boolean NOT NULL,
    "currentAmount" numeric(10,2) NOT NULL,
    "newAmount" numeric(10,2) NOT NULL,
    "prorationAmount" numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "paymentRequired" boolean DEFAULT true NOT NULL,
    "paymentStatus" text DEFAULT 'PENDING'::text NOT NULL,
    "paymentIntentId" text,
    "paymentProvider" text,
    "scheduledFor" timestamp(3) without time zone,
    "appliedAt" timestamp(3) without time zone,
    reason text,
    "failureReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.pending_plan_changes OWNER TO postgres;

--
-- Name: phone_verifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.phone_verifications (
    id text NOT NULL,
    phone text NOT NULL,
    code text NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "sessionId" text,
    "tenantId" text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    "maxAttempts" integer DEFAULT 3 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "verifiedAt" timestamp(3) without time zone
);


ALTER TABLE public.phone_verifications OWNER TO postgres;

--
-- Name: pos_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pos_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "enableTablelessMode" boolean DEFAULT false NOT NULL,
    "enableTwoStepCheckout" boolean DEFAULT false NOT NULL,
    "showProductImages" boolean DEFAULT true NOT NULL,
    "enableCustomerOrdering" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.pos_settings OWNER TO postgres;

--
-- Name: product_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_images (
    id text NOT NULL,
    url text NOT NULL,
    filename text NOT NULL,
    size integer NOT NULL,
    "mimeType" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_images OWNER TO postgres;

--
-- Name: product_modifier_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_modifier_groups (
    id text NOT NULL,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "productId" text NOT NULL,
    "groupId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_modifier_groups OWNER TO postgres;

--
-- Name: product_to_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_to_images (
    id text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "productId" text NOT NULL,
    "imageId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_to_images OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    image text,
    "isAvailable" boolean DEFAULT true NOT NULL,
    "stockTracked" boolean DEFAULT false NOT NULL,
    "currentStock" integer DEFAULT 0 NOT NULL,
    "categoryId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: qr_menu_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qr_menu_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "primaryColor" text DEFAULT '#3B82F6'::text NOT NULL,
    "secondaryColor" text DEFAULT '#1F2937'::text NOT NULL,
    "backgroundColor" text DEFAULT '#F9FAFB'::text NOT NULL,
    "fontFamily" text DEFAULT 'Inter'::text NOT NULL,
    "logoUrl" text,
    "showRestaurantInfo" boolean DEFAULT true NOT NULL,
    "showPrices" boolean DEFAULT true NOT NULL,
    "showDescription" boolean DEFAULT true NOT NULL,
    "showImages" boolean DEFAULT true NOT NULL,
    "layoutStyle" text DEFAULT 'GRID'::text NOT NULL,
    "itemsPerRow" integer DEFAULT 2 NOT NULL,
    "enableTableQR" boolean DEFAULT true NOT NULL,
    "tableQRMessage" text DEFAULT 'Scan to view our menu'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.qr_menu_settings OWNER TO postgres;

--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_movements (
    id text NOT NULL,
    type text NOT NULL,
    quantity integer NOT NULL,
    reason text,
    notes text,
    "productId" text NOT NULL,
    "userId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.stock_movements OWNER TO postgres;

--
-- Name: subscription_payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscription_payments (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "paymentProvider" text NOT NULL,
    "stripePaymentIntentId" text,
    "iyzicoPaymentId" text,
    "paymentMethod" text,
    last4 text,
    "cardBrand" text,
    "failureCode" text,
    "failureMessage" text,
    "retryCount" integer DEFAULT 0 NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "refundedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.subscription_payments OWNER TO postgres;

--
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscription_plans (
    id text NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "monthlyPrice" numeric(10,2) NOT NULL,
    "yearlyPrice" numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "trialDays" integer DEFAULT 0 NOT NULL,
    "maxUsers" integer DEFAULT 1 NOT NULL,
    "maxTables" integer DEFAULT 5 NOT NULL,
    "maxProducts" integer DEFAULT 50 NOT NULL,
    "maxCategories" integer DEFAULT 10 NOT NULL,
    "maxMonthlyOrders" integer DEFAULT 100 NOT NULL,
    "advancedReports" boolean DEFAULT false NOT NULL,
    "multiLocation" boolean DEFAULT false NOT NULL,
    "customBranding" boolean DEFAULT false NOT NULL,
    "apiAccess" boolean DEFAULT false NOT NULL,
    "prioritySupport" boolean DEFAULT false NOT NULL,
    "inventoryTracking" boolean DEFAULT false NOT NULL,
    "kdsIntegration" boolean DEFAULT true NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.subscription_plans OWNER TO postgres;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscriptions (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "planId" text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "billingCycle" text NOT NULL,
    "paymentProvider" text NOT NULL,
    "startDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "currentPeriodStart" timestamp(3) without time zone NOT NULL,
    "currentPeriodEnd" timestamp(3) without time zone NOT NULL,
    "cancelledAt" timestamp(3) without time zone,
    "endedAt" timestamp(3) without time zone,
    "isTrialPeriod" boolean DEFAULT false NOT NULL,
    "trialStart" timestamp(3) without time zone,
    "trialEnd" timestamp(3) without time zone,
    "stripeSubscriptionId" text,
    "iyzicoSubscriptionId" text,
    "stripeCustomerId" text,
    "iyzicoCustomerId" text,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "autoRenew" boolean DEFAULT true NOT NULL,
    "cancelAtPeriodEnd" boolean DEFAULT false NOT NULL,
    "cancellationReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.subscriptions OWNER TO postgres;

--
-- Name: tables; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tables (
    id text NOT NULL,
    number text NOT NULL,
    capacity integer NOT NULL,
    section text,
    status text DEFAULT 'AVAILABLE'::text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.tables OWNER TO postgres;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    id text NOT NULL,
    name text NOT NULL,
    subdomain text,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "currentPlanId" text,
    "paymentRegion" text DEFAULT 'INTERNATIONAL'::text NOT NULL,
    "trialUsed" boolean DEFAULT false NOT NULL,
    "trialStartedAt" timestamp(3) without time zone,
    "trialEndsAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: user_notification_reads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_notification_reads (
    id text NOT NULL,
    "notificationId" text NOT NULL,
    "userId" text NOT NULL,
    "readAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_notification_reads OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    role text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "resetToken" text,
    "resetTokenExpiry" timestamp(3) without time zone,
    avatar text,
    phone text,
    "lastLogin" timestamp(3) without time zone,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "emailVerificationCode" character varying(6),
    "emailVerificationCodeExpires" timestamp(3) without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: waiter_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.waiter_requests (
    id text NOT NULL,
    message text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "sessionId" text NOT NULL,
    "tableId" text NOT NULL,
    "acknowledgedAt" timestamp(3) without time zone,
    "acknowledgedById" text,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.waiter_requests OWNER TO postgres;

--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_keys (id, "tenantId", name, key, "keyPrefix", scopes, "webhookUrl", "webhookEvents", "isActive", "expiresAt", "lastUsedAt", "usageCount", "ipWhitelist", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: bill_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bill_requests (id, status, "sessionId", "tableId", "acknowledgedAt", "acknowledgedById", "completedAt", "createdAt", "updatedAt") FROM stdin;
08a73734-aa56-497b-80b6-9bbc7c8970a6	COMPLETED	fe8ca43a-5b23-4557-8964-e6d37f9c8854	3721e0fa-91d5-4ae9-9280-e516da9788f6	2025-11-13 17:19:33.069	f44870a3-7248-4cf8-90ce-77349eab149f	2025-11-13 17:19:33.812	2025-11-13 17:18:17.453	2025-11-13 17:19:33.814
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, description, "displayOrder", "isActive", "tenantId", "createdAt", "updatedAt") FROM stdin;
048f309a-3154-439a-81f1-09c5f0568503	Appetizers	Start your meal with our delicious starters	1	t	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.046	2025-11-06 02:21:50.046
d0fdabe3-e267-4795-828c-8ccfdefa94ec	Main Courses	Our signature main dishes	2	t	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.058	2025-11-06 02:21:50.058
3b3bed7c-9a50-4e77-a772-be02f3ded807	Desserts	Sweet endings to your meal	3	t	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.061	2025-11-06 02:21:50.061
d88160d0-611e-4b95-b4c8-7eb50a78099b	Beverages	Refreshing drinks	4	t	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.065	2025-11-06 02:21:50.065
3be00184-eb23-4a4a-bdb7-02de6c8b53c2	denem	den	1	t	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-06 02:22:22.667	2025-11-06 02:22:22.667
3108a5d3-6e3c-4a34-a492-ea15785737ae	Ana yemek	Ana yemekler	1	t	befd2e33-1427-43e0-be8a-6d01cb09620f	2025-11-11 08:33:21.709	2025-11-11 08:33:21.709
\.


--
-- Data for Name: contact_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact_messages (id, name, email, phone, message, status, "adminNotes", "createdAt", "updatedAt") FROM stdin;
36ae1e65-cb5b-431c-8921-c241ccd3b85c	deneme	muhammedtarikucar@gmail.com	+90 506 068 71 00	Merhabalar	NEW	\N	2025-11-15 18:12:31.782	2025-11-15 18:12:31.782
ab655d7f-40cd-4e64-a496-803d0de36e0e	selma	muhammedtarikucar@gmail.com	+90 506 0687100	merhabalasda	NEW	\N	2025-11-15 19:27:47.277	2025-11-15 19:27:47.277
a9b28d43-9316-4615-b25c-87da580b282c	muhammed tarık	muhammedtarikucar@gmail.com	5060687100	nedennnnö  nljnl	NEW	\N	2025-11-15 19:28:26.271	2025-11-15 19:28:26.271
ba63fdf2-bdc6-40bb-b451-9d4db418bf83	asdaf	muhammedtarikucar@gmail.com	+90 506 068 71 00	denemedasda	NEW	\N	2025-11-15 19:38:00.383	2025-11-15 19:38:00.383
0369eb9e-80c0-414a-b67d-0f9af604ad6c	selma	muhammedtarikucar@gmail.com	5060687100	denemekerin anksdlas	NEW	\N	2025-11-15 20:12:11.627	2025-11-15 20:12:11.627
\.


--
-- Data for Name: customer_referrals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_referrals (id, "referrerId", "referredId", "referralCode", status, "referrerReward", "referredReward", "rewardedAt", "createdAt", "completedAt") FROM stdin;
\.


--
-- Data for Name: customer_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_sessions (id, "sessionId", "customerId", "tableId", phone, "isActive", "userAgent", "ipAddress", "expiresAt", "lastActivity", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (id, name, email, phone, "phoneVerified", "loyaltyPoints", "loyaltyTier", tags, notes, "referralCode", "referredBy", "totalOrders", "totalSpent", "averageOrder", birthday, preferences, "tenantId", "createdAt", "updatedAt", "lastVisit") FROM stdin;
\.


--
-- Data for Name: desktop_releases; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.desktop_releases (id, version, "releaseTag", published, "pubDate", "windowsUrl", "windowsSignature", "macArmUrl", "macArmSignature", "macIntelUrl", "macIntelSignature", "linuxUrl", "linuxSignature", "releaseNotes", changelog, "downloadCount", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: integration_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.integration_settings (id, "tenantId", "integrationType", provider, name, config, "isEnabled", "isConfigured", "lastSyncedAt", notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (id, "subscriptionId", "paymentId", "invoiceNumber", status, subtotal, tax, total, currency, "periodStart", "periodEnd", "dueDate", "paidAt", "voidedAt", "createdAt", "updatedAt", description, notes, "pdfUrl") FROM stdin;
\.


--
-- Data for Name: loyalty_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.loyalty_transactions (id, "customerId", type, points, description, "orderId", "orderNumber", "orderAmount", "referredCustomerId", "balanceBefore", "balanceAfter", metadata, "createdAt") FROM stdin;
\.


--
-- Data for Name: modifier_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.modifier_groups (id, name, "displayName", description, "selectionType", "minSelections", "maxSelections", "isRequired", "displayOrder", "isActive", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: modifiers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.modifiers (id, name, "displayName", description, "priceAdjustment", "isAvailable", "displayOrder", "groupId", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, title, message, type, data, "userId", "tenantId", "isGlobal", priority, "createdAt", "expiresAt") FROM stdin;
\.


--
-- Data for Name: order_item_modifiers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_item_modifiers (id, quantity, "priceAdjustment", "orderItemId", "modifierId", "createdAt") FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, quantity, "unitPrice", subtotal, "modifierTotal", notes, status, "orderId", "productId", "createdAt", "updatedAt") FROM stdin;
765ba916-cb89-4ec3-9cfb-a1387feaaece	1	1.00	1.00	0.00	\N	PENDING	03537865-d6e7-4633-ac62-f78211328562	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-06 02:23:17.518	2025-11-06 02:23:17.518
b324f87e-e622-4cff-9876-f40ebd05a20d	1	1.00	1.00	0.00	\N	PENDING	a77346d2-8ffc-4406-a939-422fbad1ca44	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-06 03:01:56.931	2025-11-06 03:01:56.931
a67e2d85-add2-47a6-85cc-b12be5d0c76c	1	1.00	1.00	0.00	\N	PENDING	e446e10c-d073-4cac-aed6-5dc9bac920d6	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-06 03:02:19.208	2025-11-06 03:02:19.208
9c20396e-ddac-442d-803a-ed404a0a49d0	1	1.00	1.00	0.00	\N	PENDING	3f461153-1f30-49b4-aa10-b8e1a8d1e974	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-07 12:06:34.21	2025-11-07 12:06:34.21
b901c20d-68ec-4ffa-994c-abbad4aaad3a	1	1.00	1.00	0.00	\N	PENDING	97fda60f-e2a8-4ba2-bd80-e0612d67a744	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-07 12:24:10.939	2025-11-07 12:24:10.939
329e8b28-448d-4d22-9a7d-c5f35282ee5c	1	200.00	200.00	0.00	\N	PENDING	5d3c3164-ace9-4445-b00c-fd718475d589	5879bae7-04b9-4151-94dc-f56f54dff0b0	2025-11-11 08:36:48.881	2025-11-11 08:36:48.881
a8c58d85-27d2-46b8-ae35-84cc6e493fe6	1	120.00	120.00	0.00	\N	PENDING	5d3c3164-ace9-4445-b00c-fd718475d589	09c766ea-25fb-4128-b05b-cf9c679a21f5	2025-11-11 08:36:48.881	2025-11-11 08:36:48.881
f91e544a-c592-4a45-abac-18e129df959e	1	200.00	200.00	0.00	\N	PENDING	efa33fba-1c44-4430-949d-e7e2989aca38	5879bae7-04b9-4151-94dc-f56f54dff0b0	2025-11-11 08:38:54.264	2025-11-11 08:38:54.264
8624cee7-d958-42e0-918b-7abf6f149686	1	120.00	120.00	0.00	\N	PENDING	efa33fba-1c44-4430-949d-e7e2989aca38	09c766ea-25fb-4128-b05b-cf9c679a21f5	2025-11-11 08:38:54.264	2025-11-11 08:38:54.264
56a03f32-14dd-4955-bcd5-921df8034a35	1	200.00	200.00	0.00	\N	PENDING	a05d7d19-5028-48af-94ed-f0496a4d5983	5879bae7-04b9-4151-94dc-f56f54dff0b0	2025-11-11 08:54:25.857	2025-11-11 08:54:25.857
0e0c8f83-bb6f-4704-acfe-b1b48cb84dd9	1	120.00	120.00	0.00	\N	PENDING	a05d7d19-5028-48af-94ed-f0496a4d5983	09c766ea-25fb-4128-b05b-cf9c679a21f5	2025-11-11 08:54:25.857	2025-11-11 08:54:25.857
07d04f84-d20e-472e-977e-f9d13b13de69	2	1.00	2.00	0.00	\N	PENDING	9a586fe3-d520-41b2-bfed-5eacde0dacc7	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 12:25:11.02	2025-11-11 12:25:11.02
5ae753b8-2168-4b53-8639-9c6fbeef2d88	1	1.00	1.00	0.00	\N	PENDING	194874bd-30ca-49ee-85b8-9f0446925cf8	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 12:25:38.117	2025-11-11 12:25:38.117
96cbfdd7-68ae-4473-99d8-27cc08a31bfc	1	200.00	200.00	0.00	\N	PENDING	19ae4e46-7e89-4020-8069-3dc0d017a714	5879bae7-04b9-4151-94dc-f56f54dff0b0	2025-11-11 13:31:39.049	2025-11-11 13:31:39.049
a22529e9-56b2-4259-9729-f697c23cd532	1	120.00	120.00	0.00	\N	PENDING	19ae4e46-7e89-4020-8069-3dc0d017a714	09c766ea-25fb-4128-b05b-cf9c679a21f5	2025-11-11 13:31:39.049	2025-11-11 13:31:39.049
3c61f757-8d59-4e4b-b39a-05b507a15ebe	1	1.00	1.00	0.00	\N	PENDING	dd4acf77-e6aa-4c59-8a72-c72188829e81	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 16:50:09.94	2025-11-11 16:50:09.94
c884984a-610d-4137-a8d4-c9c9eb459a37	1	1.00	1.00	0.00	\N	PENDING	d55e857a-4042-4d38-a58d-5e73b02dd6fc	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 17:12:08.814	2025-11-11 17:12:08.814
59febd90-ef15-44c1-afa5-85b9322e3756	1	1.00	1.00	0.00	\N	PENDING	f1488f4b-b1ab-4fb1-8029-bfe585392996	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 17:12:53.475	2025-11-11 17:12:53.475
9cfcc88f-d3b9-438f-b9cd-6a982da149ff	1	1.00	1.00	0.00	\N	PENDING	e5d7b3e5-184c-4c14-81df-f5a2258e2645	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 17:48:25.747	2025-11-11 17:48:25.747
15fd336e-1748-4e05-90de-5abcdfccd79e	1	1.00	1.00	0.00	\N	PENDING	742ca666-9223-4b33-a910-b697fd1ad198	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 18:26:12.51	2025-11-11 18:26:12.51
405b25d5-1731-49d6-8885-98f8f511e169	1	1.00	1.00	0.00	\N	PENDING	986e545e-8448-4cb0-9da8-876f4a4d9e7b	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 18:26:43.925	2025-11-11 18:26:43.925
098ed028-fd06-45d3-933b-d52586513e9e	1	1.00	1.00	0.00	\N	PENDING	897ef926-9a1d-46a3-9ec9-d5c1e79da5ba	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 18:27:32.669	2025-11-11 18:27:32.669
e4532420-a158-46ee-a1e3-c60f44cb0aba	1	1.00	1.00	0.00	\N	PENDING	6e6a3347-e0d7-48d2-b687-2273e2048e7e	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 18:53:49.493	2025-11-11 18:53:49.493
9876fbd7-d0a7-4be2-a2b5-7503492b4459	1	1.00	1.00	0.00	\N	PENDING	0c30c234-ce61-4ec9-b16e-d82f4c831e1b	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 18:54:23.964	2025-11-11 18:54:23.964
9e08e627-e5e0-4cc2-b1bd-73238aa62db7	1	1.00	1.00	0.00	\N	PENDING	c5c29053-71da-4811-8c9b-ae9e475b73c0	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 18:56:02.821	2025-11-11 18:56:02.821
e8c2ca6b-87d4-445e-a023-6d53906b0649	1	1.00	1.00	0.00	\N	PENDING	9b425c03-8227-4496-bae9-d6138a5bce8a	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 18:57:11.05	2025-11-11 18:57:11.05
f841967a-adb8-4a35-bede-89f9c4b8711d	1	1.00	1.00	0.00	\N	PENDING	b604be2f-9c03-4143-92a1-8e531ace41ac	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 18:59:57.457	2025-11-11 18:59:57.457
616bbfa9-a61a-44e3-bbdf-810cb39a1bd8	1	1.00	1.00	0.00	\N	PENDING	f3491370-262a-4ed5-aa06-5959fdd75953	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 19:00:54.769	2025-11-11 19:00:54.769
4296e02c-bbdf-40a0-8d2d-bad0f91b02ff	1	1.00	1.00	0.00	\N	PENDING	311ba7d9-19fc-4704-94cd-eb3ca07e051e	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 20:45:47.448	2025-11-11 20:45:47.448
1782037f-0c21-4684-b197-c1373917ef75	1	1.00	1.00	0.00	\N	PENDING	ebf208cc-668b-44e9-821e-6ed95da608dd	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 20:46:15.642	2025-11-11 20:46:15.642
c913e67d-8b71-411b-81d9-8a23c11a14e2	1	1.00	1.00	0.00	\N	PENDING	52751a96-d952-40ce-a341-2166fae979fb	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 23:02:26.453	2025-11-11 23:02:26.453
6b9d1c86-ae9f-4c23-bece-52d85efee38f	5	1.00	5.00	0.00	\N	PENDING	a857aa39-79bd-497e-aea2-e355c34f81ac	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 23:36:29.491	2025-11-11 23:36:29.491
64bce447-7a53-4e0e-a81a-fb629420d0c9	1	1.00	1.00	0.00	\N	PENDING	7f271c9e-9dec-4653-85dc-6b4678b5df8c	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 23:36:52.428	2025-11-11 23:36:52.428
8d9c46bd-7a15-442d-a4d5-40c3230b2c08	1	1.00	1.00	0.00	\N	PENDING	96a9235a-1b28-434d-92b4-11eb86210eb3	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-11 23:51:56.166	2025-11-11 23:51:56.166
002e8c69-24de-48c9-8446-d9ecc7b7fa1b	1	1.00	1.00	0.00	\N	PENDING	f827d4bb-e026-47af-81fb-4525b9058fa2	31e35a89-219a-4fd4-b17e-0018b6782305	2025-11-12 00:30:54.398	2025-11-12 00:30:54.398
e80b97a6-5872-4d42-b330-e9e1d6e07886	1	34.00	34.00	0.00	\N	PENDING	39ae1730-5b69-4e93-85c0-c67d00de58ab	57f8331b-7621-4e9b-b2aa-ae3502517cb0	2025-11-12 00:31:33.279	2025-11-12 00:31:33.279
df4cf483-18c9-4a5f-9733-863e9cb25c97	1	34.00	34.00	0.00	\N	PENDING	baa84f91-b8f1-468c-b689-8b7af0ef29f5	57f8331b-7621-4e9b-b2aa-ae3502517cb0	2025-11-12 00:31:58.064	2025-11-12 00:31:58.064
96843e1d-419e-4ce4-8069-2b02c5329ece	5	34.00	170.00	0.00	\N	PENDING	69ed99ac-316e-4e88-8001-adcdd53ca0cd	57f8331b-7621-4e9b-b2aa-ae3502517cb0	2025-11-12 00:32:29.123	2025-11-12 00:32:29.123
b7b181cc-4eb3-4c85-98fa-a32d9929f02e	2	34.00	68.00	0.00	\N	PENDING	0dd90ca5-8cbe-4a5e-a577-88216a4e1452	57f8331b-7621-4e9b-b2aa-ae3502517cb0	2025-11-12 00:50:07.252	2025-11-12 00:50:07.252
29948285-5e72-47ec-bc87-e89904161026	1	34.00	34.00	0.00	\N	PENDING	11efbc73-fae3-421d-8ae5-da0f9f278c35	57f8331b-7621-4e9b-b2aa-ae3502517cb0	2025-11-13 17:18:01.525	2025-11-13 17:18:01.525
4e4e53da-0d68-4a9e-8daa-e96192cc5209	1	34.00	34.00	0.00	\N	PENDING	8ed69141-84dc-4eb5-bce8-0089886216e3	57f8331b-7621-4e9b-b2aa-ae3502517cb0	2025-11-13 17:19:11.852	2025-11-13 17:19:11.852
f68446a9-5402-4a5c-aad0-ca2e0821ef39	2	34.00	68.00	0.00	\N	PENDING	7495ad3f-fb27-4b6e-add7-b9ef1011deef	57f8331b-7621-4e9b-b2aa-ae3502517cb0	2025-11-15 17:08:06.039	2025-11-15 17:08:06.039
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, "orderNumber", type, status, "totalAmount", discount, "finalAmount", notes, "customerName", "sessionId", "customerPhone", "requiresApproval", "approvedAt", "tableId", "customerId", "userId", "approvedById", "tenantId", "createdAt", "updatedAt", "paidAt") FROM stdin;
03537865-d6e7-4633-ac62-f78211328562	ORD-20251106-0001	DINE_IN	CANCELLED	1.00	0.00	1.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-06 02:23:24.432	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-06 02:23:17.518	2025-11-06 03:01:14.868	\N
a857aa39-79bd-497e-aea2-e355c34f81ac	ORD-1762904177252-803	DINE_IN	READY	5.00	0.00	5.00	\N	\N	\N	\N	f	\N	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	f44870a3-7248-4cf8-90ce-77349eab149f	\N	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 23:36:17.254	2025-11-12 00:32:58.581	\N
efa33fba-1c44-4430-949d-e7e2989aca38	ORD-20251111-0091	DINE_IN	PENDING	320.00	0.00	320.00	\N	\N	3456c285-e956-4398-a600-3f1bdf94b353	\N	f	2025-11-11 08:39:09.201	b1e115a8-2a94-4e22-8349-240f04c84249	\N	\N	44a36c8f-63a0-49ac-9c6f-2cac3c0ed1da	befd2e33-1427-43e0-be8a-6d01cb09620f	2025-11-11 08:38:54.264	2025-11-11 08:39:09.203	\N
a05d7d19-5028-48af-94ed-f0496a4d5983	ORD-20251111-0092	DINE_IN	PENDING	320.00	0.00	320.00	\N	\N	0f2fcdb8-9232-447d-ba8c-5c36c62e4cc8	\N	f	2025-11-11 08:54:34.088	008901a7-eac2-4f41-846b-62e331df7238	\N	\N	44a36c8f-63a0-49ac-9c6f-2cac3c0ed1da	befd2e33-1427-43e0-be8a-6d01cb09620f	2025-11-11 08:54:25.857	2025-11-11 08:54:34.09	\N
19ae4e46-7e89-4020-8069-3dc0d017a714	ORD-20251111-0093	DINE_IN	PENDING	320.00	0.00	320.00	\N	\N	ec8055d8-b0df-44c7-af02-4f9dd7fb1144	\N	f	2025-11-11 13:31:50.948	85d8ece7-cfed-473b-be0e-6deddeef0e36	\N	\N	44a36c8f-63a0-49ac-9c6f-2cac3c0ed1da	befd2e33-1427-43e0-be8a-6d01cb09620f	2025-11-11 13:31:39.049	2025-11-11 13:31:50.95	\N
e5d7b3e5-184c-4c14-81df-f5a2258e2645	ORD-20251111-0005	DINE_IN	SERVED	1.00	0.00	1.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-11 17:49:27.184	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 17:48:25.747	2025-11-11 23:03:15.388	\N
9b425c03-8227-4496-bae9-d6138a5bce8a	ORD-20251111-0011	DINE_IN	PAID	1.00	0.00	1.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-11 18:57:15.849	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 18:57:11.05	2025-11-11 18:57:40.829	2025-11-11 18:57:40.827
0c30c234-ce61-4ec9-b16e-d82f4c831e1b	ORD-20251111-0010	DINE_IN	SERVED	1.00	0.00	1.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-11 18:54:30.1	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 18:54:23.964	2025-11-11 23:03:09.233	\N
6e6a3347-e0d7-48d2-b687-2273e2048e7e	ORD-20251111-0009	DINE_IN	SERVED	1.00	0.00	1.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-11 18:54:03.964	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 18:53:49.493	2025-11-11 23:03:10.959	\N
897ef926-9a1d-46a3-9ec9-d5c1e79da5ba	ORD-20251111-0008	DINE_IN	SERVED	1.00	0.00	1.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-11 18:54:04.778	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 18:27:32.669	2025-11-11 23:03:12.71	\N
986e545e-8448-4cb0-9da8-876f4a4d9e7b	ORD-20251111-0007	DINE_IN	SERVED	1.00	0.00	1.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-11 18:54:05.449	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 18:26:43.925	2025-11-11 23:03:13.646	\N
742ca666-9223-4b33-a910-b697fd1ad198	ORD-20251111-0006	DINE_IN	SERVED	1.00	0.00	1.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-11 18:54:06.011	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 18:26:12.51	2025-11-11 23:03:14.477	\N
3f461153-1f30-49b4-aa10-b8e1a8d1e974	ORD-20251107-0001	DINE_IN	SERVED	1.00	0.00	1.00	\N	\N	fe8ca43a-5b23-4557-8964-e6d37f9c8854	\N	f	2025-11-07 12:23:13.227	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-07 12:06:34.21	2025-11-11 23:03:16.201	\N
e446e10c-d073-4cac-aed6-5dc9bac920d6	ORD-20251106-0003	DINE_IN	SERVED	1.00	0.00	1.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-06 03:02:23.045	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-06 03:02:19.208	2025-11-11 23:03:17.186	\N
a77346d2-8ffc-4406-a939-422fbad1ca44	ORD-20251106-0002	DINE_IN	SERVED	1.00	0.00	1.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-06 03:02:04.976	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-06 03:01:56.931	2025-11-11 23:03:17.85	\N
f1488f4b-b1ab-4fb1-8029-bfe585392996	ORD-20251111-0004	DINE_IN	SERVED	1.00	0.00	1.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-11 17:13:03.809	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 17:12:53.475	2025-11-11 23:03:25.461	\N
d55e857a-4042-4d38-a58d-5e73b02dd6fc	ORD-20251111-0003	DINE_IN	SERVED	1.00	0.00	1.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-11 17:12:22.501	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 17:12:08.814	2025-11-11 23:03:26.551	\N
311ba7d9-19fc-4704-94cd-eb3ca07e051e	ORD-20251111-0014	DINE_IN	SERVED	1.00	0.00	1.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-11 22:52:03.952	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 20:45:47.448	2025-11-11 23:03:47.784	\N
f3491370-262a-4ed5-aa06-5959fdd75953	ORD-20251111-0013	DINE_IN	SERVED	1.00	0.00	1.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-11 20:37:33.866	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 19:00:54.769	2025-11-11 23:03:48.637	\N
b604be2f-9c03-4143-92a1-8e531ace41ac	ORD-20251111-0012	DINE_IN	SERVED	1.00	0.00	1.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-11 20:37:34.692	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 18:59:57.457	2025-11-11 23:03:49.457	\N
dd4acf77-e6aa-4c59-8a72-c72188829e81	ORD-20251111-0002	DINE_IN	SERVED	1.00	0.00	1.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-11 16:50:19.577	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 16:50:09.94	2025-11-11 23:03:51.119	\N
9a586fe3-d520-41b2-bfed-5eacde0dacc7	ORD-20251111-0001	DINE_IN	SERVED	2.00	0.00	2.00	\N	\N	fe8ca43a-5b23-4557-8964-e6d37f9c8854	\N	f	2025-11-11 12:25:26.534	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 12:25:11.02	2025-11-11 23:03:52.014	\N
52751a96-d952-40ce-a341-2166fae979fb	ORD-20251111-0016	DINE_IN	SERVED	1.00	0.00	1.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-11 23:02:31.835	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 23:02:26.453	2025-11-11 23:03:46.293	\N
ebf208cc-668b-44e9-821e-6ed95da608dd	ORD-20251111-0015	DINE_IN	SERVED	1.00	0.00	1.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-11 20:46:30.117	77729663-a17c-4fd7-bcda-0f2876ca0a5b	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 20:46:15.642	2025-11-11 23:03:46.993	\N
39ae1730-5b69-4e93-85c0-c67d00de58ab	ORD-20251112-0002	DINE_IN	READY	34.00	0.00	34.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-12 00:31:38.485	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-12 00:31:33.279	2025-11-12 00:32:50.377	\N
f827d4bb-e026-47af-81fb-4525b9058fa2	ORD-20251112-0001	DINE_IN	READY	1.00	0.00	1.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-12 00:31:41.23	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-12 00:30:54.398	2025-11-12 00:32:53.235	\N
69ed99ac-316e-4e88-8001-adcdd53ca0cd	ORD-20251112-0004	DINE_IN	PAID	170.00	0.00	170.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-12 00:32:19.728	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-12 00:32:16.083	2025-11-12 00:34:15.838	2025-11-12 00:34:15.836
96a9235a-1b28-434d-92b4-11eb86210eb3	ORD-20251111-0018	DINE_IN	PAID	1.00	0.00	1.00	\N	\N	fe8ca43a-5b23-4557-8964-e6d37f9c8854	\N	f	2025-11-11 23:52:10.265	77729663-a17c-4fd7-bcda-0f2876ca0a5b	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 23:51:56.166	2025-11-12 00:34:19.238	2025-11-12 00:34:19.236
7f271c9e-9dec-4653-85dc-6b4678b5df8c	ORD-20251111-0017	DINE_IN	READY	1.00	0.00	1.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-11 23:36:57.886	77729663-a17c-4fd7-bcda-0f2876ca0a5b	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 23:36:52.428	2025-11-12 00:33:01.195	\N
11efbc73-fae3-421d-8ae5-da0f9f278c35	ORD-20251113-0001	DINE_IN	PAID	34.00	0.00	34.00	\N	\N	fe8ca43a-5b23-4557-8964-e6d37f9c8854	\N	f	2025-11-13 17:19:22.402	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-13 17:18:01.525	2025-11-13 17:19:40.214	2025-11-13 17:19:40.212
baa84f91-b8f1-468c-b689-8b7af0ef29f5	ORD-20251112-0003	DINE_IN	SERVED	34.00	0.00	34.00	\N	\N	992e8d0a-f580-41ee-a081-7499d65b01b0	\N	f	2025-11-12 00:32:01.019	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	\N	f44870a3-7248-4cf8-90ce-77349eab149f	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-12 00:31:58.064	2025-11-12 00:33:10.114	\N
97fda60f-e2a8-4ba2-bd80-e0612d67a744	ORD-1762518250936-701	DINE_IN	PAID	1.00	0.00	1.00	\N	\N	\N	\N	f	\N	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	f44870a3-7248-4cf8-90ce-77349eab149f	\N	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-07 12:24:10.939	2025-11-07 12:24:18.17	2025-11-07 12:24:18.168
5d3c3164-ace9-4445-b00c-fd718475d589	ORD-1762850208878-090	TAKEAWAY	PAID	320.00	0.00	320.00	\N	\N	\N	\N	f	\N	\N	\N	44a36c8f-63a0-49ac-9c6f-2cac3c0ed1da	\N	befd2e33-1427-43e0-be8a-6d01cb09620f	2025-11-11 08:36:48.881	2025-11-11 08:36:51.849	2025-11-11 08:36:51.847
194874bd-30ca-49ee-85b8-9f0446925cf8	ORD-1762863938113-084	DINE_IN	PAID	1.00	0.00	1.00	\N	\N	\N	\N	f	\N	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	f44870a3-7248-4cf8-90ce-77349eab149f	\N	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 12:25:38.117	2025-11-11 15:39:26.328	2025-11-11 15:39:26.326
c5c29053-71da-4811-8c9b-ae9e475b73c0	ORD-1762887352089-848	DINE_IN	SERVED	1.00	0.00	1.00	\N	\N	\N	\N	f	\N	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	f44870a3-7248-4cf8-90ce-77349eab149f	\N	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 18:55:52.092	2025-11-11 23:03:50.299	\N
0dd90ca5-8cbe-4a5e-a577-88216a4e1452	ORD-1762908607248-686	DINE_IN	PENDING	68.00	0.00	68.00	\N	\N	\N	\N	f	\N	77729663-a17c-4fd7-bcda-0f2876ca0a5b	\N	f44870a3-7248-4cf8-90ce-77349eab149f	\N	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-12 00:50:07.252	2025-11-12 00:50:07.252	\N
8ed69141-84dc-4eb5-bce8-0089886216e3	ORD-1763054351849-789	DINE_IN	PAID	34.00	0.00	34.00	\N	\N	\N	\N	f	\N	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	f44870a3-7248-4cf8-90ce-77349eab149f	\N	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-13 17:19:11.852	2025-11-13 17:19:16.171	2025-11-13 17:19:16.168
7495ad3f-fb27-4b6e-add7-b9ef1011deef	ORD-1763226486037-115	DINE_IN	PENDING	68.00	0.00	68.00	\N	\N	\N	\N	f	\N	3721e0fa-91d5-4ae9-9280-e516da9788f6	\N	f44870a3-7248-4cf8-90ce-77349eab149f	\N	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-15 17:08:06.039	2025-11-15 17:08:06.039	\N
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, amount, method, status, "transactionId", notes, "orderId", "createdAt", "paidAt") FROM stdin;
a1d33554-4c46-4d23-983c-363614178439	1.00	CASH	COMPLETED	\N	\N	97fda60f-e2a8-4ba2-bd80-e0612d67a744	2025-11-07 12:24:18.138	2025-11-07 12:24:18.136
dcfc13d0-ee69-4a75-93cd-af23ffc7d20b	320.00	CASH	COMPLETED	\N	\N	5d3c3164-ace9-4445-b00c-fd718475d589	2025-11-11 08:36:51.827	2025-11-11 08:36:51.824
acc93662-1953-4e65-960e-ab664720a04e	1.00	CASH	COMPLETED	\N	\N	194874bd-30ca-49ee-85b8-9f0446925cf8	2025-11-11 15:39:26.295	2025-11-11 15:39:26.292
3b332348-b67f-4f56-b700-8221fa2abb6a	1.00	CASH	COMPLETED	\N	\N	9b425c03-8227-4496-bae9-d6138a5bce8a	2025-11-11 18:57:40.802	2025-11-11 18:57:40.8
1ad85e6b-6be5-4018-81d3-5b7b54ccd585	170.00	CASH	COMPLETED	\N	\N	69ed99ac-316e-4e88-8001-adcdd53ca0cd	2025-11-12 00:34:15.79	2025-11-12 00:34:15.786
b9214d4f-5a66-4ad2-b06e-80b029e5ea34	1.00	CASH	COMPLETED	\N	\N	96a9235a-1b28-434d-92b4-11eb86210eb3	2025-11-12 00:34:19.215	2025-11-12 00:34:19.212
8fa52d9d-6051-47be-a504-3b75d20747f2	34.00	CASH	COMPLETED	\N	\N	8ed69141-84dc-4eb5-bce8-0089886216e3	2025-11-13 17:19:16.135	2025-11-13 17:19:16.132
ed8851de-9821-4e5d-82a6-55fd5cad15f6	34.00	CASH	COMPLETED	\N	\N	11efbc73-fae3-421d-8ae5-da0f9f278c35	2025-11-13 17:19:40.197	2025-11-13 17:19:40.195
\.


--
-- Data for Name: pending_plan_changes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pending_plan_changes (id, "subscriptionId", "currentPlanId", "newPlanId", "newBillingCycle", "isUpgrade", "currentAmount", "newAmount", "prorationAmount", currency, "paymentRequired", "paymentStatus", "paymentIntentId", "paymentProvider", "scheduledFor", "appliedAt", reason, "failureReason", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: phone_verifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.phone_verifications (id, phone, code, verified, "expiresAt", "sessionId", "tenantId", attempts, "maxAttempts", "createdAt", "verifiedAt") FROM stdin;
\.


--
-- Data for Name: pos_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pos_settings (id, "tenantId", "enableTablelessMode", "enableTwoStepCheckout", "showProductImages", "enableCustomerOrdering", "createdAt", "updatedAt") FROM stdin;
8293c9ae-679d-46a9-8d96-3098c51146b2	9eb802e1-e856-4e62-8b78-32bafb1de15e	f	t	t	t	2025-11-06 02:22:01.154	2025-11-06 02:22:01.154
17a70075-9453-4893-8e42-392c79370aca	befd2e33-1427-43e0-be8a-6d01cb09620f	f	t	t	t	2025-11-11 08:32:59.962	2025-11-11 08:53:56.208
\.


--
-- Data for Name: product_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_images (id, url, filename, size, "mimeType", "tenantId", "createdAt") FROM stdin;
cd9d0347-b6c0-4712-b8be-ba6144b6a1e7	http://localhost:3000/uploads/products/9eb802e1-e856-4e62-8b78-32bafb1de15e/020524bc-a30e-4c77-98c8-78cf35543f0d.png	ChatGPT Image Oct 17, 2025, 12_00_56 AM.png	82149	image/png	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-06 02:22:29.29
a60b95c0-93fd-439f-8a83-0ac87e624616	http://localhost:3000/uploads/products/befd2e33-1427-43e0-be8a-6d01cb09620f/2935afa9-bdaf-4a37-a8d9-15cefbe4c350.jpg	Dapanji_urumqi.jpg	106867	image/jpeg	befd2e33-1427-43e0-be8a-6d01cb09620f	2025-11-11 08:34:33.693
ce1a3440-5c9a-45a5-a923-b5ae5359fed8	http://localhost:3000/uploads/products/befd2e33-1427-43e0-be8a-6d01cb09620f/9edc8934-24a3-4e0d-963b-067d70701e85.jpg	uzbek-traditional-lagman-with-meat-PN1HNX.jpg	242499	image/jpeg	befd2e33-1427-43e0-be8a-6d01cb09620f	2025-11-11 08:34:33.719
\.


--
-- Data for Name: product_modifier_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_modifier_groups (id, "displayOrder", "productId", "groupId", "createdAt") FROM stdin;
\.


--
-- Data for Name: product_to_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_to_images (id, "order", "productId", "imageId", "createdAt") FROM stdin;
9dffe839-0484-4ffe-ad66-954a55af80c9	0	31e35a89-219a-4fd4-b17e-0018b6782305	cd9d0347-b6c0-4712-b8be-ba6144b6a1e7	2025-11-06 02:22:44.849
62e20e54-6de4-4b89-a66c-db1b0e21eb78	0	09c766ea-25fb-4128-b05b-cf9c679a21f5	ce1a3440-5c9a-45a5-a923-b5ae5359fed8	2025-11-11 08:35:06.375
ce861602-1706-4e96-87b4-21d009ef4585	0	5879bae7-04b9-4151-94dc-f56f54dff0b0	a60b95c0-93fd-439f-8a83-0ac87e624616	2025-11-11 08:35:34.746
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, name, description, price, image, "isAvailable", "stockTracked", "currentStock", "categoryId", "tenantId", "createdAt", "updatedAt") FROM stdin;
e97d0387-c4c1-4663-8a7a-282371bab050	Caesar Salad	Fresh romaine lettuce with Caesar dressing and croutons	8.99	\N	t	t	50	048f309a-3154-439a-81f1-09c5f0568503	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.07	2025-11-06 02:21:50.07
d9284416-97e4-4c8c-81e7-c0aa6f6e98bd	Garlic Bread	Toasted bread with garlic butter	5.99	\N	t	t	30	048f309a-3154-439a-81f1-09c5f0568503	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.07	2025-11-06 02:21:50.07
13b6277b-5553-46a9-b619-76eeaa61d84e	Buffalo Wings	Spicy chicken wings with ranch dressing	12.99	\N	t	t	25	048f309a-3154-439a-81f1-09c5f0568503	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.07	2025-11-06 02:21:50.07
2d559f09-a467-4216-bfdb-349076edeb4a	Grilled Salmon	Fresh Atlantic salmon with vegetables	24.99	\N	t	t	15	d0fdabe3-e267-4795-828c-8ccfdefa94ec	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.07	2025-11-06 02:21:50.07
c9438bce-a980-4996-8188-0660e556b0ec	Beef Burger	Premium beef patty with cheese and fries	15.99	\N	t	t	40	d0fdabe3-e267-4795-828c-8ccfdefa94ec	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.07	2025-11-06 02:21:50.07
72005435-37af-4c41-918b-f48629bcbaad	Pasta Carbonara	Classic Italian pasta with creamy sauce	16.99	\N	t	t	35	d0fdabe3-e267-4795-828c-8ccfdefa94ec	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.07	2025-11-06 02:21:50.07
c8b57ab2-6297-47b1-b006-b48b6f540177	Chicken Tikka Masala	Marinated chicken in spicy tomato sauce	18.99	\N	t	t	20	d0fdabe3-e267-4795-828c-8ccfdefa94ec	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.07	2025-11-06 02:21:50.07
9a98607f-162c-4db5-8590-76d9e540ab00	Chocolate Lava Cake	Warm chocolate cake with molten center	7.99	\N	t	t	22	3b3bed7c-9a50-4e77-a772-be02f3ded807	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.07	2025-11-06 02:21:50.07
14992271-f686-4f06-987b-ef0bb2e32675	Tiramisu	Classic Italian coffee-flavored dessert	8.99	\N	t	t	18	3b3bed7c-9a50-4e77-a772-be02f3ded807	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.07	2025-11-06 02:21:50.07
49cc3acc-9d9b-4f8c-9f27-426ae016e30f	Ice Cream Sundae	Three scoops with toppings	6.99	\N	t	t	50	3b3bed7c-9a50-4e77-a772-be02f3ded807	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.07	2025-11-06 02:21:50.07
ff32e867-d59a-41fc-bfa1-1a6b06075a7e	Coca Cola	Refreshing soft drink	2.99	\N	t	t	100	d88160d0-611e-4b95-b4c8-7eb50a78099b	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.07	2025-11-06 02:21:50.07
5e980c77-207e-4869-844f-b999fcbb1ecc	Fresh Orange Juice	Freshly squeezed orange juice	4.99	\N	t	t	30	d88160d0-611e-4b95-b4c8-7eb50a78099b	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.07	2025-11-06 02:21:50.07
1bc7e9be-1862-4453-9352-08b214981c6f	Coffee	Freshly brewed coffee	3.99	\N	t	f	0	d88160d0-611e-4b95-b4c8-7eb50a78099b	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.07	2025-11-06 02:21:50.07
31e35a89-219a-4fd4-b17e-0018b6782305	w	we	1.00	\N	t	f	2	3be00184-eb23-4a4a-bdb7-02de6c8b53c2	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-06 02:22:44.826	2025-11-06 02:22:44.826
09c766ea-25fb-4128-b05b-cf9c679a21f5	Lagman	Lagmen 	120.00	\N	t	f	122	3108a5d3-6e3c-4a34-a492-ea15785737ae	befd2e33-1427-43e0-be8a-6d01cb09620f	2025-11-11 08:35:06.339	2025-11-11 08:35:06.339
5879bae7-04b9-4151-94dc-f56f54dff0b0	Dapenci	Bin Dokuz Yüz Seksen Dört (özgün adı: Nineteen Eighty-Four), İngiliz yazar George Orwell tarafından kaleme alınmış olan alegorik, distopik ve politik bir romandır. Romanın hikâyesi distopik bir dünyada geçer. Distopya romanlarının en ünlülerindendir. Özellikle kitapta tanımlanan Big Brother (Büyük Birader) kavramı günümüzde de sıklıkla kullanılmaktadır. Aynı zamanda kitapta geçen &quot;düşünce polisi&quot; gibi kavramları da yazar George Orwell günümüze kazandırmıştır.	200.00	\N	t	f	124	3108a5d3-6e3c-4a34-a492-ea15785737ae	befd2e33-1427-43e0-be8a-6d01cb09620f	2025-11-11 08:35:34.732	2025-11-11 08:35:34.732
57f8331b-7621-4e9b-b2aa-ae3502517cb0	sgdgsd	3242	34.00	\N	t	f	1342	3be00184-eb23-4a4a-bdb7-02de6c8b53c2	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-12 00:31:20.58	2025-11-12 00:31:20.58
\.


--
-- Data for Name: qr_menu_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qr_menu_settings (id, "tenantId", "primaryColor", "secondaryColor", "backgroundColor", "fontFamily", "logoUrl", "showRestaurantInfo", "showPrices", "showDescription", "showImages", "layoutStyle", "itemsPerRow", "enableTableQR", "tableQRMessage", "createdAt", "updatedAt") FROM stdin;
9f245919-75c7-4454-a08e-02cf5b37c51c	befd2e33-1427-43e0-be8a-6d01cb09620f	#3B82F6	#1F2937	#F9FAFB	Inter	\N	t	t	t	t	GRID	2	t	Scan to view our menu	2025-11-11 08:38:05.136	2025-11-11 08:38:05.136
70977082-8e20-4865-a44d-230a428c49f9	9eb802e1-e856-4e62-8b78-32bafb1de15e	#10B981	#059669	#F0FDF4	Open Sans	\N	t	t	t	t	GRID	2	t	Scan to view our menu	2025-11-06 02:22:10.97	2025-11-15 18:04:08.312
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_movements (id, type, quantity, reason, notes, "productId", "userId", "tenantId", "createdAt") FROM stdin;
\.


--
-- Data for Name: subscription_payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscription_payments (id, "subscriptionId", amount, currency, status, "paymentProvider", "stripePaymentIntentId", "iyzicoPaymentId", "paymentMethod", last4, "cardBrand", "failureCode", "failureMessage", "retryCount", "paidAt", "refundedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscription_plans (id, name, "displayName", description, "monthlyPrice", "yearlyPrice", currency, "trialDays", "maxUsers", "maxTables", "maxProducts", "maxCategories", "maxMonthlyOrders", "advancedReports", "multiLocation", "customBranding", "apiAccess", "prioritySupport", "inventoryTracking", "kdsIntegration", "isActive", "createdAt", "updatedAt") FROM stdin;
1446df02-3b3b-4729-a6c2-e7b0dbeb4043	FREE	Free Plan	Perfect for small restaurants getting started	0.00	0.00	USD	0	2	5	25	5	50	f	f	f	f	f	f	t	t	2025-11-06 02:21:49.741	2025-11-06 02:21:49.741
b7d51d5d-74a7-464d-8738-fe78d4e69fe2	BASIC	Basic Plan	Great for growing restaurants	29.99	299.99	USD	14	5	20	100	20	500	f	f	f	f	f	t	t	t	2025-11-06 02:21:49.789	2025-11-06 02:21:49.789
b94e8b12-2cfe-4441-ab4d-55dfdeb9c13b	PRO	Pro Plan	For established restaurants with multiple locations	79.99	799.99	USD	14	15	50	500	50	2000	t	t	t	f	t	t	t	t	2025-11-06 02:21:49.797	2025-11-06 02:21:49.797
b711d8f0-0f77-46a3-87a4-0a81d64ec083	BUSINESS	Business Plan	Enterprise solution for large restaurant chains	199.99	1999.99	USD	14	-1	-1	-1	-1	-1	t	t	t	t	t	t	t	t	2025-11-06 02:21:49.806	2025-11-06 02:21:49.806
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscriptions (id, "tenantId", "planId", status, "billingCycle", "paymentProvider", "startDate", "currentPeriodStart", "currentPeriodEnd", "cancelledAt", "endedAt", "isTrialPeriod", "trialStart", "trialEnd", "stripeSubscriptionId", "iyzicoSubscriptionId", "stripeCustomerId", "iyzicoCustomerId", amount, currency, "autoRenew", "cancelAtPeriodEnd", "cancellationReason", "createdAt", "updatedAt") FROM stdin;
9bb8213f-5903-4040-9f77-a196d7305c44	9eb802e1-e856-4e62-8b78-32bafb1de15e	1446df02-3b3b-4729-a6c2-e7b0dbeb4043	ACTIVE	MONTHLY	STRIPE	2025-11-06 02:21:54.247	2025-11-06 02:21:54.247	2035-11-06 02:21:54.247	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	USD	t	f	\N	2025-11-06 02:21:54.249	2025-11-06 02:21:54.249
0241489a-d8e2-4a92-8ee2-93c150d02aba	befd2e33-1427-43e0-be8a-6d01cb09620f	1446df02-3b3b-4729-a6c2-e7b0dbeb4043	ACTIVE	MONTHLY	STRIPE	2025-11-11 08:32:56.001	2025-11-11 08:32:56.001	2035-11-11 08:32:56.001	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	USD	t	f	\N	2025-11-11 08:32:56.004	2025-11-11 08:32:56.004
\.


--
-- Data for Name: tables; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tables (id, number, capacity, section, status, "tenantId", "createdAt", "updatedAt") FROM stdin;
d5370762-96a1-4a70-90b8-5fd57b5fcb8b	1	2	Main Hall	AVAILABLE	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.085	2025-11-06 02:21:50.085
ea6ffb59-4bed-4ea3-9839-35888848f7e8	2	4	Main Hall	AVAILABLE	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.085	2025-11-06 02:21:50.085
109cfe5f-aa56-472c-ae82-7eff65d98de0	3	4	Main Hall	AVAILABLE	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.085	2025-11-06 02:21:50.085
160e1152-21c2-4316-80cc-e334a1d4fa21	4	6	Main Hall	AVAILABLE	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.085	2025-11-06 02:21:50.085
eb5ebbac-8dda-403a-95fe-19141ccd9d05	5	2	Terrace	AVAILABLE	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.085	2025-11-06 02:21:50.085
52b56db4-7922-4f3b-a394-3c0629ab6dab	6	4	Terrace	AVAILABLE	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.085	2025-11-06 02:21:50.085
af842bc7-ada3-4813-bda1-37c689b64a70	7	8	Private Room	AVAILABLE	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.085	2025-11-06 02:21:50.085
b1e115a8-2a94-4e22-8349-240f04c84249	1	4	\N	AVAILABLE	befd2e33-1427-43e0-be8a-6d01cb09620f	2025-11-11 08:35:43.63	2025-11-11 08:35:43.63
85d8ece7-cfed-473b-be0e-6deddeef0e36	2	4	\N	AVAILABLE	befd2e33-1427-43e0-be8a-6d01cb09620f	2025-11-11 08:35:46.294	2025-11-11 08:35:46.294
7d0b5e8b-129e-4e53-a1f6-2f5417c0d2b7	3	4	\N	AVAILABLE	befd2e33-1427-43e0-be8a-6d01cb09620f	2025-11-11 08:35:49.325	2025-11-11 08:35:49.325
008901a7-eac2-4f41-846b-62e331df7238	Bahçe-1	4	\N	AVAILABLE	befd2e33-1427-43e0-be8a-6d01cb09620f	2025-11-11 08:35:56.151	2025-11-11 08:35:56.151
77729663-a17c-4fd7-bcda-0f2876ca0a5b	2	4	\N	OCCUPIED	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-11 19:00:34.522	2025-11-12 00:50:07.641
3721e0fa-91d5-4ae9-9280-e516da9788f6	1	4	\N	OCCUPIED	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-06 02:22:57.451	2025-11-15 17:08:06.234
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (id, name, subdomain, status, "currentPlanId", "paymentRegion", "trialUsed", "trialStartedAt", "trialEndsAt", "createdAt", "updatedAt") FROM stdin;
b213bf7e-0a24-40d9-bfba-36ada95d98f2	Demo Restaurant	demo	ACTIVE	1446df02-3b3b-4729-a6c2-e7b0dbeb4043	INTERNATIONAL	f	\N	\N	2025-11-06 02:21:49.813	2025-11-06 02:21:49.813
9eb802e1-e856-4e62-8b78-32bafb1de15e	admin	admin	ACTIVE	1446df02-3b3b-4729-a6c2-e7b0dbeb4043	INTERNATIONAL	f	\N	\N	2025-11-06 02:21:54.237	2025-11-06 02:21:54.237
befd2e33-1427-43e0-be8a-6d01cb09620f	Dolan	dolan	ACTIVE	1446df02-3b3b-4729-a6c2-e7b0dbeb4043	INTERNATIONAL	f	\N	\N	2025-11-11 08:32:55.968	2025-11-11 08:32:55.968
\.


--
-- Data for Name: user_notification_reads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_notification_reads (id, "notificationId", "userId", "readAt") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password, "firstName", "lastName", role, status, "emailVerified", "resetToken", "resetTokenExpiry", avatar, phone, "lastLogin", "tenantId", "createdAt", "updatedAt", "emailVerificationCode", "emailVerificationCodeExpires") FROM stdin;
fc2293b0-e219-49b3-86bf-6328c2dd80e5	admin@restaurant.com	$2a$10$NS/rpM5GXwEO3wIGrUhLpOW6AXVV2PDXVNYNoTkF6AnErrpYuYbrO	John	Admin	ADMIN	ACTIVE	f	\N	\N	\N	\N	\N	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.016	2025-11-06 02:21:50.016	\N	\N
546360d9-4800-40c9-9283-51d7668cf7c4	waiter@restaurant.com	$2a$10$NS/rpM5GXwEO3wIGrUhLpOW6AXVV2PDXVNYNoTkF6AnErrpYuYbrO	Jane	Waiter	WAITER	ACTIVE	f	\N	\N	\N	\N	\N	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.03	2025-11-06 02:21:50.03	\N	\N
104e4ddc-9e21-4ebc-81ef-837f993b55df	kitchen@restaurant.com	$2a$10$NS/rpM5GXwEO3wIGrUhLpOW6AXVV2PDXVNYNoTkF6AnErrpYuYbrO	Mike	Chef	KITCHEN	ACTIVE	f	\N	\N	\N	\N	\N	b213bf7e-0a24-40d9-bfba-36ada95d98f2	2025-11-06 02:21:50.037	2025-11-06 02:21:50.037	\N	\N
f44870a3-7248-4cf8-90ce-77349eab149f	admin@gmail.com	$2a$10$0uF6F38qEL/ftmHTlo/BZONnkyjt8iKoVYgRbM/0NqNSK1AjQbvRy	admin	admin	ADMIN	ACTIVE	f	\N	\N	\N	\N	\N	9eb802e1-e856-4e62-8b78-32bafb1de15e	2025-11-06 02:21:54.523	2025-11-06 02:21:54.523	\N	\N
44a36c8f-63a0-49ac-9c6f-2cac3c0ed1da	jarulla.f@gmail.com	$2a$10$9lNjaUADbkPUrpM1/GRACuMo7WAwr9VPDzkd/m2ObhvqnlgUj.xp6	carullah	Tursun	ADMIN	ACTIVE	f	\N	\N	\N	\N	\N	befd2e33-1427-43e0-be8a-6d01cb09620f	2025-11-11 08:32:56.22	2025-11-11 08:32:56.22	\N	\N
\.


--
-- Data for Name: waiter_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.waiter_requests (id, message, status, "sessionId", "tableId", "acknowledgedAt", "acknowledgedById", "completedAt", "createdAt", "updatedAt") FROM stdin;
2acc8721-c02d-45a9-8d81-2ca2efe1a022	\N	COMPLETED	fe8ca43a-5b23-4557-8964-e6d37f9c8854	3721e0fa-91d5-4ae9-9280-e516da9788f6	2025-11-13 17:19:26.37	f44870a3-7248-4cf8-90ce-77349eab149f	2025-11-13 17:19:27.553	2025-11-13 17:18:14.178	2025-11-13 17:19:27.555
f1ccdfa7-62a5-49a5-854e-fc3f6b2cf027	\N	COMPLETED	fe8ca43a-5b23-4557-8964-e6d37f9c8854	3721e0fa-91d5-4ae9-9280-e516da9788f6	2025-11-13 17:19:28.391	f44870a3-7248-4cf8-90ce-77349eab149f	2025-11-13 17:19:29.407	2025-11-13 17:18:15.495	2025-11-13 17:19:29.409
\.


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: bill_requests bill_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_requests
    ADD CONSTRAINT bill_requests_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: contact_messages contact_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_messages
    ADD CONSTRAINT contact_messages_pkey PRIMARY KEY (id);


--
-- Name: customer_referrals customer_referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_referrals
    ADD CONSTRAINT customer_referrals_pkey PRIMARY KEY (id);


--
-- Name: customer_sessions customer_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_sessions
    ADD CONSTRAINT customer_sessions_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: desktop_releases desktop_releases_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.desktop_releases
    ADD CONSTRAINT desktop_releases_pkey PRIMARY KEY (id);


--
-- Name: integration_settings integration_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_settings
    ADD CONSTRAINT integration_settings_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: loyalty_transactions loyalty_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT loyalty_transactions_pkey PRIMARY KEY (id);


--
-- Name: modifier_groups modifier_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifier_groups
    ADD CONSTRAINT modifier_groups_pkey PRIMARY KEY (id);


--
-- Name: modifiers modifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifiers
    ADD CONSTRAINT modifiers_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: order_item_modifiers order_item_modifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item_modifiers
    ADD CONSTRAINT order_item_modifiers_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: pending_plan_changes pending_plan_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_plan_changes
    ADD CONSTRAINT pending_plan_changes_pkey PRIMARY KEY (id);


--
-- Name: phone_verifications phone_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.phone_verifications
    ADD CONSTRAINT phone_verifications_pkey PRIMARY KEY (id);


--
-- Name: pos_settings pos_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pos_settings
    ADD CONSTRAINT pos_settings_pkey PRIMARY KEY (id);


--
-- Name: product_images product_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_pkey PRIMARY KEY (id);


--
-- Name: product_modifier_groups product_modifier_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_modifier_groups
    ADD CONSTRAINT product_modifier_groups_pkey PRIMARY KEY (id);


--
-- Name: product_to_images product_to_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_to_images
    ADD CONSTRAINT product_to_images_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: qr_menu_settings qr_menu_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qr_menu_settings
    ADD CONSTRAINT qr_menu_settings_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: subscription_payments subscription_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT subscription_payments_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: tables tables_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT tables_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: user_notification_reads user_notification_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_reads
    ADD CONSTRAINT user_notification_reads_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: waiter_requests waiter_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waiter_requests
    ADD CONSTRAINT waiter_requests_pkey PRIMARY KEY (id);


--
-- Name: api_keys_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "api_keys_isActive_idx" ON public.api_keys USING btree ("isActive");


--
-- Name: api_keys_key_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_keys_key_idx ON public.api_keys USING btree (key);


--
-- Name: api_keys_key_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX api_keys_key_key ON public.api_keys USING btree (key);


--
-- Name: api_keys_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "api_keys_tenantId_idx" ON public.api_keys USING btree ("tenantId");


--
-- Name: bill_requests_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "bill_requests_sessionId_idx" ON public.bill_requests USING btree ("sessionId");


--
-- Name: bill_requests_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bill_requests_status_idx ON public.bill_requests USING btree (status);


--
-- Name: bill_requests_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "bill_requests_tableId_idx" ON public.bill_requests USING btree ("tableId");


--
-- Name: categories_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "categories_tenantId_idx" ON public.categories USING btree ("tenantId");


--
-- Name: contact_messages_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "contact_messages_createdAt_idx" ON public.contact_messages USING btree ("createdAt");


--
-- Name: contact_messages_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX contact_messages_status_idx ON public.contact_messages USING btree (status);


--
-- Name: customer_referrals_referralCode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_referrals_referralCode_idx" ON public.customer_referrals USING btree ("referralCode");


--
-- Name: customer_referrals_referredId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_referrals_referredId_idx" ON public.customer_referrals USING btree ("referredId");


--
-- Name: customer_referrals_referredId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customer_referrals_referredId_key" ON public.customer_referrals USING btree ("referredId");


--
-- Name: customer_referrals_referrerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_referrals_referrerId_idx" ON public.customer_referrals USING btree ("referrerId");


--
-- Name: customer_referrals_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customer_referrals_status_idx ON public.customer_referrals USING btree (status);


--
-- Name: customer_sessions_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_sessions_customerId_idx" ON public.customer_sessions USING btree ("customerId");


--
-- Name: customer_sessions_expiresAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_sessions_expiresAt_idx" ON public.customer_sessions USING btree ("expiresAt");


--
-- Name: customer_sessions_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_sessions_sessionId_idx" ON public.customer_sessions USING btree ("sessionId");


--
-- Name: customer_sessions_sessionId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customer_sessions_sessionId_key" ON public.customer_sessions USING btree ("sessionId");


--
-- Name: customer_sessions_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_sessions_tenantId_idx" ON public.customer_sessions USING btree ("tenantId");


--
-- Name: customers_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customers_email_idx ON public.customers USING btree (email);


--
-- Name: customers_loyaltyTier_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customers_loyaltyTier_idx" ON public.customers USING btree ("loyaltyTier");


--
-- Name: customers_phone_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customers_phone_idx ON public.customers USING btree (phone);


--
-- Name: customers_referralCode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customers_referralCode_idx" ON public.customers USING btree ("referralCode");


--
-- Name: customers_referralCode_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customers_referralCode_key" ON public.customers USING btree ("referralCode");


--
-- Name: customers_tenantId_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customers_tenantId_email_key" ON public.customers USING btree ("tenantId", email);


--
-- Name: customers_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customers_tenantId_idx" ON public.customers USING btree ("tenantId");


--
-- Name: customers_tenantId_phone_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customers_tenantId_phone_key" ON public.customers USING btree ("tenantId", phone);


--
-- Name: desktop_releases_published_pubDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "desktop_releases_published_pubDate_idx" ON public.desktop_releases USING btree (published, "pubDate");


--
-- Name: desktop_releases_releaseTag_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "desktop_releases_releaseTag_key" ON public.desktop_releases USING btree ("releaseTag");


--
-- Name: desktop_releases_version_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX desktop_releases_version_idx ON public.desktop_releases USING btree (version);


--
-- Name: desktop_releases_version_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX desktop_releases_version_key ON public.desktop_releases USING btree (version);


--
-- Name: integration_settings_integrationType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "integration_settings_integrationType_idx" ON public.integration_settings USING btree ("integrationType");


--
-- Name: integration_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "integration_settings_tenantId_idx" ON public.integration_settings USING btree ("tenantId");


--
-- Name: integration_settings_tenantId_integrationType_provider_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "integration_settings_tenantId_integrationType_provider_key" ON public.integration_settings USING btree ("tenantId", "integrationType", provider);


--
-- Name: invoices_dueDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_dueDate_idx" ON public.invoices USING btree ("dueDate");


--
-- Name: invoices_invoiceNumber_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_invoiceNumber_idx" ON public.invoices USING btree ("invoiceNumber");


--
-- Name: invoices_invoiceNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "invoices_invoiceNumber_key" ON public.invoices USING btree ("invoiceNumber");


--
-- Name: invoices_paymentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "invoices_paymentId_key" ON public.invoices USING btree ("paymentId");


--
-- Name: invoices_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX invoices_status_idx ON public.invoices USING btree (status);


--
-- Name: invoices_subscriptionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_subscriptionId_idx" ON public.invoices USING btree ("subscriptionId");


--
-- Name: loyalty_transactions_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "loyalty_transactions_createdAt_idx" ON public.loyalty_transactions USING btree ("createdAt");


--
-- Name: loyalty_transactions_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "loyalty_transactions_customerId_idx" ON public.loyalty_transactions USING btree ("customerId");


--
-- Name: loyalty_transactions_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX loyalty_transactions_type_idx ON public.loyalty_transactions USING btree (type);


--
-- Name: modifier_groups_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifier_groups_isActive_idx" ON public.modifier_groups USING btree ("isActive");


--
-- Name: modifier_groups_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifier_groups_tenantId_idx" ON public.modifier_groups USING btree ("tenantId");


--
-- Name: modifiers_groupId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifiers_groupId_idx" ON public.modifiers USING btree ("groupId");


--
-- Name: modifiers_isAvailable_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifiers_isAvailable_idx" ON public.modifiers USING btree ("isAvailable");


--
-- Name: modifiers_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifiers_tenantId_idx" ON public.modifiers USING btree ("tenantId");


--
-- Name: notifications_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "notifications_createdAt_idx" ON public.notifications USING btree ("createdAt");


--
-- Name: notifications_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "notifications_tenantId_idx" ON public.notifications USING btree ("tenantId");


--
-- Name: notifications_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "notifications_userId_idx" ON public.notifications USING btree ("userId");


--
-- Name: order_item_modifiers_modifierId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_item_modifiers_modifierId_idx" ON public.order_item_modifiers USING btree ("modifierId");


--
-- Name: order_item_modifiers_orderItemId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_item_modifiers_orderItemId_idx" ON public.order_item_modifiers USING btree ("orderItemId");


--
-- Name: order_items_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_items_orderId_idx" ON public.order_items USING btree ("orderId");


--
-- Name: order_items_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_items_productId_idx" ON public.order_items USING btree ("productId");


--
-- Name: orders_approvedById_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_approvedById_idx" ON public.orders USING btree ("approvedById");


--
-- Name: orders_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_customerId_idx" ON public.orders USING btree ("customerId");


--
-- Name: orders_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_sessionId_idx" ON public.orders USING btree ("sessionId");


--
-- Name: orders_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orders_status_idx ON public.orders USING btree (status);


--
-- Name: orders_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_tableId_idx" ON public.orders USING btree ("tableId");


--
-- Name: orders_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_tenantId_idx" ON public.orders USING btree ("tenantId");


--
-- Name: orders_tenantId_orderNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "orders_tenantId_orderNumber_key" ON public.orders USING btree ("tenantId", "orderNumber");


--
-- Name: orders_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_userId_idx" ON public.orders USING btree ("userId");


--
-- Name: payments_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "payments_orderId_idx" ON public.payments USING btree ("orderId");


--
-- Name: payments_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payments_status_idx ON public.payments USING btree (status);


--
-- Name: pending_plan_changes_paymentStatus_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pending_plan_changes_paymentStatus_idx" ON public.pending_plan_changes USING btree ("paymentStatus");


--
-- Name: pending_plan_changes_scheduledFor_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pending_plan_changes_scheduledFor_idx" ON public.pending_plan_changes USING btree ("scheduledFor");


--
-- Name: pending_plan_changes_subscriptionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pending_plan_changes_subscriptionId_idx" ON public.pending_plan_changes USING btree ("subscriptionId");


--
-- Name: phone_verifications_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX phone_verifications_code_idx ON public.phone_verifications USING btree (code);


--
-- Name: phone_verifications_expiresAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "phone_verifications_expiresAt_idx" ON public.phone_verifications USING btree ("expiresAt");


--
-- Name: phone_verifications_phone_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "phone_verifications_phone_tenantId_idx" ON public.phone_verifications USING btree (phone, "tenantId");


--
-- Name: pos_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pos_settings_tenantId_idx" ON public.pos_settings USING btree ("tenantId");


--
-- Name: pos_settings_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "pos_settings_tenantId_key" ON public.pos_settings USING btree ("tenantId");


--
-- Name: product_images_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_images_tenantId_idx" ON public.product_images USING btree ("tenantId");


--
-- Name: product_modifier_groups_groupId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_modifier_groups_groupId_idx" ON public.product_modifier_groups USING btree ("groupId");


--
-- Name: product_modifier_groups_productId_groupId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "product_modifier_groups_productId_groupId_key" ON public.product_modifier_groups USING btree ("productId", "groupId");


--
-- Name: product_modifier_groups_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_modifier_groups_productId_idx" ON public.product_modifier_groups USING btree ("productId");


--
-- Name: product_to_images_imageId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_to_images_imageId_idx" ON public.product_to_images USING btree ("imageId");


--
-- Name: product_to_images_productId_imageId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "product_to_images_productId_imageId_key" ON public.product_to_images USING btree ("productId", "imageId");


--
-- Name: product_to_images_productId_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_to_images_productId_order_idx" ON public.product_to_images USING btree ("productId", "order");


--
-- Name: products_categoryId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "products_categoryId_idx" ON public.products USING btree ("categoryId");


--
-- Name: products_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "products_tenantId_idx" ON public.products USING btree ("tenantId");


--
-- Name: qr_menu_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "qr_menu_settings_tenantId_idx" ON public.qr_menu_settings USING btree ("tenantId");


--
-- Name: qr_menu_settings_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "qr_menu_settings_tenantId_key" ON public.qr_menu_settings USING btree ("tenantId");


--
-- Name: stock_movements_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_movements_productId_idx" ON public.stock_movements USING btree ("productId");


--
-- Name: stock_movements_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_movements_tenantId_idx" ON public.stock_movements USING btree ("tenantId");


--
-- Name: stock_movements_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_movements_userId_idx" ON public.stock_movements USING btree ("userId");


--
-- Name: subscription_payments_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscription_payments_createdAt_idx" ON public.subscription_payments USING btree ("createdAt");


--
-- Name: subscription_payments_iyzicoPaymentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscription_payments_iyzicoPaymentId_key" ON public.subscription_payments USING btree ("iyzicoPaymentId");


--
-- Name: subscription_payments_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX subscription_payments_status_idx ON public.subscription_payments USING btree (status);


--
-- Name: subscription_payments_stripePaymentIntentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscription_payments_stripePaymentIntentId_key" ON public.subscription_payments USING btree ("stripePaymentIntentId");


--
-- Name: subscription_payments_subscriptionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscription_payments_subscriptionId_idx" ON public.subscription_payments USING btree ("subscriptionId");


--
-- Name: subscription_plans_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX subscription_plans_name_key ON public.subscription_plans USING btree (name);


--
-- Name: subscriptions_currentPeriodEnd_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscriptions_currentPeriodEnd_idx" ON public.subscriptions USING btree ("currentPeriodEnd");


--
-- Name: subscriptions_iyzicoSubscriptionId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscriptions_iyzicoSubscriptionId_key" ON public.subscriptions USING btree ("iyzicoSubscriptionId");


--
-- Name: subscriptions_planId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscriptions_planId_idx" ON public.subscriptions USING btree ("planId");


--
-- Name: subscriptions_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX subscriptions_status_idx ON public.subscriptions USING btree (status);


--
-- Name: subscriptions_stripeSubscriptionId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscriptions_stripeSubscriptionId_key" ON public.subscriptions USING btree ("stripeSubscriptionId");


--
-- Name: subscriptions_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscriptions_tenantId_idx" ON public.subscriptions USING btree ("tenantId");


--
-- Name: tables_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "tables_tenantId_idx" ON public.tables USING btree ("tenantId");


--
-- Name: tables_tenantId_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "tables_tenantId_number_key" ON public.tables USING btree ("tenantId", number);


--
-- Name: tenants_currentPlanId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "tenants_currentPlanId_idx" ON public.tenants USING btree ("currentPlanId");


--
-- Name: tenants_subdomain_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX tenants_subdomain_key ON public.tenants USING btree (subdomain);


--
-- Name: user_notification_reads_notificationId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_notification_reads_notificationId_idx" ON public.user_notification_reads USING btree ("notificationId");


--
-- Name: user_notification_reads_notificationId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "user_notification_reads_notificationId_userId_key" ON public.user_notification_reads USING btree ("notificationId", "userId");


--
-- Name: user_notification_reads_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_notification_reads_userId_idx" ON public.user_notification_reads USING btree ("userId");


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_resetToken_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "users_resetToken_key" ON public.users USING btree ("resetToken");


--
-- Name: users_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "users_tenantId_idx" ON public.users USING btree ("tenantId");


--
-- Name: waiter_requests_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "waiter_requests_sessionId_idx" ON public.waiter_requests USING btree ("sessionId");


--
-- Name: waiter_requests_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX waiter_requests_status_idx ON public.waiter_requests USING btree (status);


--
-- Name: waiter_requests_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "waiter_requests_tableId_idx" ON public.waiter_requests USING btree ("tableId");


--
-- Name: api_keys api_keys_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT "api_keys_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bill_requests bill_requests_acknowledgedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_requests
    ADD CONSTRAINT "bill_requests_acknowledgedById_fkey" FOREIGN KEY ("acknowledgedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bill_requests bill_requests_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_requests
    ADD CONSTRAINT "bill_requests_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: categories categories_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "categories_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_referrals customer_referrals_referredId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_referrals
    ADD CONSTRAINT "customer_referrals_referredId_fkey" FOREIGN KEY ("referredId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_referrals customer_referrals_referrerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_referrals
    ADD CONSTRAINT "customer_referrals_referrerId_fkey" FOREIGN KEY ("referrerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_sessions customer_sessions_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_sessions
    ADD CONSTRAINT "customer_sessions_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: customers customers_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT "customers_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: integration_settings integration_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_settings
    ADD CONSTRAINT "integration_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoices invoices_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public.subscription_payments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: loyalty_transactions loyalty_transactions_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT "loyalty_transactions_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: modifier_groups modifier_groups_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifier_groups
    ADD CONSTRAINT "modifier_groups_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: modifiers modifiers_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifiers
    ADD CONSTRAINT "modifiers_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public.modifier_groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: modifiers modifiers_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifiers
    ADD CONSTRAINT "modifiers_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_item_modifiers order_item_modifiers_modifierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item_modifiers
    ADD CONSTRAINT "order_item_modifiers_modifierId_fkey" FOREIGN KEY ("modifierId") REFERENCES public.modifiers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: order_item_modifiers order_item_modifiers_orderItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item_modifiers
    ADD CONSTRAINT "order_item_modifiers_orderItemId_fkey" FOREIGN KEY ("orderItemId") REFERENCES public.order_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_items order_items_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "order_items_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_items order_items_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "order_items_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: orders orders_approvedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_approvedById_fkey" FOREIGN KEY ("approvedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orders orders_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payments payments_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pending_plan_changes pending_plan_changes_currentPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_plan_changes
    ADD CONSTRAINT "pending_plan_changes_currentPlanId_fkey" FOREIGN KEY ("currentPlanId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pending_plan_changes pending_plan_changes_newPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_plan_changes
    ADD CONSTRAINT "pending_plan_changes_newPlanId_fkey" FOREIGN KEY ("newPlanId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pending_plan_changes pending_plan_changes_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_plan_changes
    ADD CONSTRAINT "pending_plan_changes_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pos_settings pos_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pos_settings
    ADD CONSTRAINT "pos_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_images product_images_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT "product_images_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_modifier_groups product_modifier_groups_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_modifier_groups
    ADD CONSTRAINT "product_modifier_groups_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public.modifier_groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_modifier_groups product_modifier_groups_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_modifier_groups
    ADD CONSTRAINT "product_modifier_groups_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_to_images product_to_images_imageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_to_images
    ADD CONSTRAINT "product_to_images_imageId_fkey" FOREIGN KEY ("imageId") REFERENCES public.product_images(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_to_images product_to_images_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_to_images
    ADD CONSTRAINT "product_to_images_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: products products_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "products_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: products products_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "products_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: qr_menu_settings qr_menu_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qr_menu_settings
    ADD CONSTRAINT "qr_menu_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT "stock_movements_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT "stock_movements_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT "stock_movements_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: subscription_payments subscription_payments_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT "subscription_payments_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT "subscriptions_planId_fkey" FOREIGN KEY ("planId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: subscriptions subscriptions_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT "subscriptions_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tables tables_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT "tables_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tenants tenants_currentPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT "tenants_currentPlanId_fkey" FOREIGN KEY ("currentPlanId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_notification_reads user_notification_reads_notificationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_reads
    ADD CONSTRAINT "user_notification_reads_notificationId_fkey" FOREIGN KEY ("notificationId") REFERENCES public.notifications(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_notification_reads user_notification_reads_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_reads
    ADD CONSTRAINT "user_notification_reads_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: waiter_requests waiter_requests_acknowledgedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waiter_requests
    ADD CONSTRAINT "waiter_requests_acknowledgedById_fkey" FOREIGN KEY ("acknowledgedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: waiter_requests waiter_requests_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waiter_requests
    ADD CONSTRAINT "waiter_requests_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict hwLGgq1WSRuvw5zGd2YLhuYHNNDnNBtKjIkO3UraXt0OvlMzad7x5dUxEAaKhsI

