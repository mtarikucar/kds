--
-- PostgreSQL database dump
--

\restrict mgkgTwPbu2HnNA6dZyX9u1CpnFQ1G8XdYLY1YepIv8LMObkbFunmmuw2YHOWxtx

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_keys (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    key text NOT NULL,
    "keyPrefix" text NOT NULL,
    scopes text[],
    "webhookUrl" text,
    "webhookEvents" text[] DEFAULT ARRAY[]::text[],
    "isActive" boolean DEFAULT true NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "lastUsedAt" timestamp(3) without time zone,
    "usageCount" integer DEFAULT 0 NOT NULL,
    "ipWhitelist" text[] DEFAULT ARRAY[]::text[],
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.api_keys OWNER TO postgres;

--
-- Name: bill_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bill_requests (
    id text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "sessionId" text NOT NULL,
    "tableId" text NOT NULL,
    "acknowledgedAt" timestamp(3) without time zone,
    "acknowledgedById" text,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.bill_requests OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: contact_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact_messages (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    message text NOT NULL,
    status text DEFAULT 'NEW'::text NOT NULL,
    "adminNotes" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.contact_messages OWNER TO postgres;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id text NOT NULL,
    name text NOT NULL,
    email text,
    phone text,
    "loyaltyPoints" integer DEFAULT 0 NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[],
    notes text,
    "totalOrders" integer DEFAULT 0 NOT NULL,
    "totalSpent" numeric(10,2) DEFAULT 0 NOT NULL,
    "averageOrder" numeric(10,2) DEFAULT 0 NOT NULL,
    birthday timestamp(3) without time zone,
    preferences jsonb,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "lastVisit" timestamp(3) without time zone
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: integration_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integration_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "integrationType" text NOT NULL,
    provider text NOT NULL,
    name text NOT NULL,
    config jsonb NOT NULL,
    "isEnabled" boolean DEFAULT false NOT NULL,
    "isConfigured" boolean DEFAULT false NOT NULL,
    "lastSyncedAt" timestamp(3) without time zone,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.integration_settings OWNER TO postgres;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    "paymentId" text,
    "invoiceNumber" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    tax numeric(10,2) DEFAULT 0 NOT NULL,
    total numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "periodStart" timestamp(3) without time zone NOT NULL,
    "periodEnd" timestamp(3) without time zone NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "paidAt" timestamp(3) without time zone,
    "voidedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    description text,
    notes text,
    "pdfUrl" text
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: modifier_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.modifier_groups (
    id text NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "selectionType" text DEFAULT 'SINGLE'::text NOT NULL,
    "minSelections" integer DEFAULT 0 NOT NULL,
    "maxSelections" integer,
    "isRequired" boolean DEFAULT false NOT NULL,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.modifier_groups OWNER TO postgres;

--
-- Name: modifiers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.modifiers (
    id text NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "priceAdjustment" numeric(10,2) DEFAULT 0 NOT NULL,
    "isAvailable" boolean DEFAULT true NOT NULL,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "groupId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.modifiers OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    type text NOT NULL,
    data jsonb,
    "userId" text,
    "tenantId" text NOT NULL,
    "isGlobal" boolean DEFAULT false NOT NULL,
    priority text DEFAULT 'NORMAL'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: order_item_modifiers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_item_modifiers (
    id text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    "priceAdjustment" numeric(10,2) NOT NULL,
    "orderItemId" text NOT NULL,
    "modifierId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.order_item_modifiers OWNER TO postgres;

--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id text NOT NULL,
    quantity integer NOT NULL,
    "unitPrice" numeric(10,2) NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    notes text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "orderId" text NOT NULL,
    "productId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "modifierTotal" numeric(10,2) DEFAULT 0 NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id text NOT NULL,
    "orderNumber" text NOT NULL,
    type text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "totalAmount" numeric(10,2) NOT NULL,
    discount numeric(10,2) DEFAULT 0 NOT NULL,
    "finalAmount" numeric(10,2) NOT NULL,
    notes text,
    "customerName" text,
    "tableId" text,
    "userId" text,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "customerId" text,
    "approvedAt" timestamp(3) without time zone,
    "approvedById" text,
    "customerPhone" text,
    "requiresApproval" boolean DEFAULT true NOT NULL,
    "sessionId" text
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id text NOT NULL,
    amount numeric(10,2) NOT NULL,
    method text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "transactionId" text,
    notes text,
    "orderId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "paidAt" timestamp(3) without time zone
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: pending_plan_changes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pending_plan_changes (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    "currentPlanId" text NOT NULL,
    "newPlanId" text NOT NULL,
    "newBillingCycle" text NOT NULL,
    "isUpgrade" boolean NOT NULL,
    "currentAmount" numeric(10,2) NOT NULL,
    "newAmount" numeric(10,2) NOT NULL,
    "prorationAmount" numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "paymentRequired" boolean DEFAULT true NOT NULL,
    "paymentStatus" text DEFAULT 'PENDING'::text NOT NULL,
    "paymentIntentId" text,
    "paymentProvider" text,
    "scheduledFor" timestamp(3) without time zone,
    "appliedAt" timestamp(3) without time zone,
    reason text,
    "failureReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.pending_plan_changes OWNER TO postgres;

--
-- Name: pos_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pos_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "enableTablelessMode" boolean DEFAULT false NOT NULL,
    "enableTwoStepCheckout" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "showProductImages" boolean DEFAULT true NOT NULL,
    "enableCustomerOrdering" boolean DEFAULT true NOT NULL
);


ALTER TABLE public.pos_settings OWNER TO postgres;

--
-- Name: product_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_images (
    id text NOT NULL,
    url text NOT NULL,
    filename text NOT NULL,
    size integer NOT NULL,
    "mimeType" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_images OWNER TO postgres;

--
-- Name: product_modifier_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_modifier_groups (
    id text NOT NULL,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "productId" text NOT NULL,
    "groupId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_modifier_groups OWNER TO postgres;

--
-- Name: product_to_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_to_images (
    id text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "productId" text NOT NULL,
    "imageId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_to_images OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    image text,
    "isAvailable" boolean DEFAULT true NOT NULL,
    "stockTracked" boolean DEFAULT false NOT NULL,
    "currentStock" integer DEFAULT 0 NOT NULL,
    "categoryId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: qr_menu_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qr_menu_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "primaryColor" text DEFAULT '#3B82F6'::text NOT NULL,
    "secondaryColor" text DEFAULT '#1F2937'::text NOT NULL,
    "backgroundColor" text DEFAULT '#F9FAFB'::text NOT NULL,
    "fontFamily" text DEFAULT 'Inter'::text NOT NULL,
    "logoUrl" text,
    "showRestaurantInfo" boolean DEFAULT true NOT NULL,
    "showPrices" boolean DEFAULT true NOT NULL,
    "showDescription" boolean DEFAULT true NOT NULL,
    "showImages" boolean DEFAULT true NOT NULL,
    "layoutStyle" text DEFAULT 'GRID'::text NOT NULL,
    "itemsPerRow" integer DEFAULT 2 NOT NULL,
    "enableTableQR" boolean DEFAULT true NOT NULL,
    "tableQRMessage" text DEFAULT 'Scan to view our menu'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.qr_menu_settings OWNER TO postgres;

--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_movements (
    id text NOT NULL,
    type text NOT NULL,
    quantity integer NOT NULL,
    reason text,
    notes text,
    "productId" text NOT NULL,
    "userId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.stock_movements OWNER TO postgres;

--
-- Name: subscription_payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscription_payments (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "paymentProvider" text NOT NULL,
    "stripePaymentIntentId" text,
    "iyzicoPaymentId" text,
    "paymentMethod" text,
    last4 text,
    "cardBrand" text,
    "failureCode" text,
    "failureMessage" text,
    "retryCount" integer DEFAULT 0 NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "refundedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.subscription_payments OWNER TO postgres;

--
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscription_plans (
    id text NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "monthlyPrice" numeric(10,2) NOT NULL,
    "yearlyPrice" numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "trialDays" integer DEFAULT 0 NOT NULL,
    "maxUsers" integer DEFAULT 1 NOT NULL,
    "maxTables" integer DEFAULT 5 NOT NULL,
    "maxProducts" integer DEFAULT 50 NOT NULL,
    "maxCategories" integer DEFAULT 10 NOT NULL,
    "maxMonthlyOrders" integer DEFAULT 100 NOT NULL,
    "advancedReports" boolean DEFAULT false NOT NULL,
    "multiLocation" boolean DEFAULT false NOT NULL,
    "customBranding" boolean DEFAULT false NOT NULL,
    "apiAccess" boolean DEFAULT false NOT NULL,
    "prioritySupport" boolean DEFAULT false NOT NULL,
    "inventoryTracking" boolean DEFAULT false NOT NULL,
    "kdsIntegration" boolean DEFAULT true NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.subscription_plans OWNER TO postgres;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscriptions (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "planId" text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "billingCycle" text NOT NULL,
    "paymentProvider" text NOT NULL,
    "startDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "currentPeriodStart" timestamp(3) without time zone NOT NULL,
    "currentPeriodEnd" timestamp(3) without time zone NOT NULL,
    "cancelledAt" timestamp(3) without time zone,
    "endedAt" timestamp(3) without time zone,
    "isTrialPeriod" boolean DEFAULT false NOT NULL,
    "trialStart" timestamp(3) without time zone,
    "trialEnd" timestamp(3) without time zone,
    "stripeSubscriptionId" text,
    "iyzicoSubscriptionId" text,
    "stripeCustomerId" text,
    "iyzicoCustomerId" text,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "autoRenew" boolean DEFAULT true NOT NULL,
    "cancelAtPeriodEnd" boolean DEFAULT false NOT NULL,
    "cancellationReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.subscriptions OWNER TO postgres;

--
-- Name: tables; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tables (
    id text NOT NULL,
    number text NOT NULL,
    capacity integer NOT NULL,
    section text,
    status text DEFAULT 'AVAILABLE'::text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.tables OWNER TO postgres;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    id text NOT NULL,
    name text NOT NULL,
    subdomain text,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "currentPlanId" text,
    "paymentRegion" text DEFAULT 'INTERNATIONAL'::text NOT NULL,
    "trialUsed" boolean DEFAULT false NOT NULL,
    "trialStartedAt" timestamp(3) without time zone,
    "trialEndsAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: user_notification_reads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_notification_reads (
    id text NOT NULL,
    "notificationId" text NOT NULL,
    "userId" text NOT NULL,
    "readAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_notification_reads OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    role text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    avatar text,
    "emailVerificationExpires" timestamp(3) without time zone,
    "emailVerificationToken" text,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "lastLogin" timestamp(3) without time zone,
    phone text,
    "resetToken" text,
    "resetTokenExpiry" timestamp(3) without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: waiter_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.waiter_requests (
    id text NOT NULL,
    message text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "sessionId" text NOT NULL,
    "tableId" text NOT NULL,
    "acknowledgedAt" timestamp(3) without time zone,
    "acknowledgedById" text,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.waiter_requests OWNER TO postgres;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_keys (id, "tenantId", name, key, "keyPrefix", scopes, "webhookUrl", "webhookEvents", "isActive", "expiresAt", "lastUsedAt", "usageCount", "ipWhitelist", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: bill_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bill_requests (id, status, "sessionId", "tableId", "acknowledgedAt", "acknowledgedById", "completedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, description, "displayOrder", "isActive", "tenantId", "createdAt", "updatedAt") FROM stdin;
25eb0bba-0451-4680-93d2-a06893cfa067	Appetizers	Start your meal with our delicious starters	1	t	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 19:44:29.554	2025-10-14 19:44:29.554
b10f7c0b-d344-4ec1-ac79-3c79f6d230d3	Main Courses	Our signature main dishes	2	t	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 19:44:29.56	2025-10-14 19:44:29.56
0bccd594-1eca-4d74-8eac-58216b719e51	Desserts	Sweet endings to your meal	3	t	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 19:44:29.571	2025-10-14 19:44:29.571
b3602603-8614-436a-b25c-3d056b534d8a	Beverages	Refreshing drinks	4	t	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 19:44:29.577	2025-10-14 19:44:29.577
264c3674-d5b1-450c-bece-1de21876c2b7	Ana Yemek	Ana yemekler	12	t	321b6b7c-01ac-4dc7-a4b8-5eb8943d1f52	2025-10-14 20:15:05.701	2025-10-14 20:15:05.701
75644dc4-c5ba-4e39-840f-2fee0419d51a	tatlı		1	t	a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb	2025-10-17 15:44:28.506	2025-10-17 15:44:28.506
c6a60c63-104e-46b2-859e-6c310d7ff662	tuzlu		1	t	a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb	2025-10-17 15:44:36.147	2025-10-17 15:44:36.147
8ee98ad3-06ac-482d-bc27-7a6db64a7708	tatli	tat	1	t	60288b5e-965c-43e3-aee8-38b2da36ee39	2025-10-31 19:28:37.068	2025-10-31 19:28:37.068
\.


--
-- Data for Name: contact_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact_messages (id, name, email, phone, message, status, "adminNotes", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (id, name, email, phone, "loyaltyPoints", tags, notes, "totalOrders", "totalSpent", "averageOrder", birthday, preferences, "tenantId", "createdAt", "updatedAt", "lastVisit") FROM stdin;
\.


--
-- Data for Name: integration_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.integration_settings (id, "tenantId", "integrationType", provider, name, config, "isEnabled", "isConfigured", "lastSyncedAt", notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (id, "subscriptionId", "paymentId", "invoiceNumber", status, subtotal, tax, total, currency, "periodStart", "periodEnd", "dueDate", "paidAt", "voidedAt", "createdAt", "updatedAt", description, notes, "pdfUrl") FROM stdin;
\.


--
-- Data for Name: modifier_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.modifier_groups (id, name, "displayName", description, "selectionType", "minSelections", "maxSelections", "isRequired", "displayOrder", "isActive", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: modifiers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.modifiers (id, name, "displayName", description, "priceAdjustment", "isAvailable", "displayOrder", "groupId", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, title, message, type, data, "userId", "tenantId", "isGlobal", priority, "createdAt", "expiresAt") FROM stdin;
\.


--
-- Data for Name: order_item_modifiers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_item_modifiers (id, quantity, "priceAdjustment", "orderItemId", "modifierId", "createdAt") FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, quantity, "unitPrice", subtotal, notes, status, "orderId", "productId", "createdAt", "updatedAt", "modifierTotal") FROM stdin;
7a6c31b0-48bd-4f27-950b-66f80653fbdd	2	122.00	244.00	\N	PENDING	43504528-bf51-4f20-89f8-6e036ca51097	14871bcf-f9d3-49ce-a76f-6058f9b0613a	2025-10-14 20:18:35.17	2025-10-14 20:18:35.17	0.00
76d0ae41-29f3-4b68-bd96-7a1845201dd2	1	132.00	132.00	\N	PENDING	43504528-bf51-4f20-89f8-6e036ca51097	6686afae-a175-44c5-8c81-acb75b1b8dd6	2025-10-14 20:18:35.17	2025-10-14 20:18:35.17	0.00
2a5ea2ad-8016-4d9e-8716-91e2c4ebbff9	2	12.00	24.00	\N	PENDING	6f7826ce-f9e4-459c-96c3-bdbd3c156cb4	7283865d-8fd9-4756-950f-cb9f8a21daca	2025-10-17 15:47:29.437	2025-10-17 15:47:29.437	0.00
279dc733-5638-40ee-a977-d3623ac11372	2	12.00	24.00	\N	PENDING	60bb16c2-7818-4c13-8e14-81ba73c00c7e	7283865d-8fd9-4756-950f-cb9f8a21daca	2025-10-17 15:47:38.199	2025-10-17 15:47:38.199	0.00
e44de8df-aec7-4e6f-8c9c-12306fbc132d	3	12.00	36.00	\N	PENDING	015e2c66-8fbf-46c6-9c61-9f50358e6833	7283865d-8fd9-4756-950f-cb9f8a21daca	2025-10-17 15:48:12.842	2025-10-17 15:48:12.842	0.00
228ddae8-cb2f-47f5-8542-7f41196c348d	2	122.00	244.00	\N	PENDING	35ce5e7d-c9a7-4fd7-adbb-a22f6f4eaebe	14871bcf-f9d3-49ce-a76f-6058f9b0613a	2025-10-17 16:40:05.67	2025-10-17 16:40:05.67	0.00
4e92d04e-81b9-4d71-934d-381cb5ab9edc	1	132.00	132.00	\N	PENDING	35ce5e7d-c9a7-4fd7-adbb-a22f6f4eaebe	6686afae-a175-44c5-8c81-acb75b1b8dd6	2025-10-17 16:40:05.67	2025-10-17 16:40:05.67	0.00
d8f774e9-b547-4cff-8a72-3e5128ffd1a4	3	15.99	47.97	\N	PENDING	296931f0-88d1-45e7-8cd2-3a896f5726e0	8fb3ce42-8b9e-4c40-beed-21e1d2e101ec	2025-10-18 17:12:52.093	2025-10-18 17:12:52.093	0.00
fe1eb4cb-59e7-4ab8-9f46-edd456198dac	1	15.99	15.99	\N	PENDING	ed34d3a6-51a8-403e-ac52-b8a3611dd0c0	8fb3ce42-8b9e-4c40-beed-21e1d2e101ec	2025-10-18 17:12:56.571	2025-10-18 17:12:56.571	0.00
7397980b-fe1b-4a1f-bd73-eedce9d66637	3	15.99	47.97	\N	PENDING	b03701a7-1729-45ce-bd36-29b0973e3571	8fb3ce42-8b9e-4c40-beed-21e1d2e101ec	2025-10-20 18:44:50.315	2025-10-20 18:44:50.315	0.00
0317dfdb-557b-40ac-909c-6cfeea049861	3	7.99	23.97	\N	PENDING	b03701a7-1729-45ce-bd36-29b0973e3571	8e95ef6c-2e88-455a-bc4d-4067e5931fec	2025-10-20 18:44:50.315	2025-10-20 18:44:50.315	0.00
a2da84c4-67da-471f-9985-6a218e4e5322	1	122.00	122.00	\N	PENDING	acb4b9aa-1fb7-4a60-a6e3-c52570aa065b	14871bcf-f9d3-49ce-a76f-6058f9b0613a	2025-10-31 18:10:45.644	2025-10-31 18:10:45.644	0.00
448ae5b3-8e89-49e4-ab4a-a9096e52ecfa	1	132.00	132.00	\N	PENDING	1e2b18e6-fe78-4b45-99f7-19158ccbe375	6686afae-a175-44c5-8c81-acb75b1b8dd6	2025-10-31 18:12:16.208	2025-10-31 18:12:16.208	0.00
4e57ef10-830b-4efa-9c97-31bc34aeb24f	2	5.99	11.98	\N	PENDING	c9be219f-4ed5-4954-93b3-b95c5b7718cb	5a8832a4-5d20-404b-a1ac-37b0509903cc	2025-10-31 18:16:49.654	2025-10-31 18:16:49.654	0.00
f3a831f1-b5cd-4e13-ab4b-a72ae8608ecd	1	13.00	13.00	\N	PENDING	6c222849-319e-434f-be0c-c380335c5bd0	6b23ea46-d552-4925-a62f-d6eeceeb37d9	2025-11-01 09:54:45.144	2025-11-01 09:54:45.144	0.00
245beb4a-c7f1-4b78-8ee2-35fa4f7634ee	1	13.00	13.00	\N	PENDING	c3c68cc3-8752-4d03-a24f-2e9e5d36ff33	6b23ea46-d552-4925-a62f-d6eeceeb37d9	2025-11-01 10:27:47.497	2025-11-01 10:27:47.497	0.00
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, "orderNumber", type, status, "totalAmount", discount, "finalAmount", notes, "customerName", "tableId", "userId", "tenantId", "createdAt", "updatedAt", "paidAt", "customerId", "approvedAt", "approvedById", "customerPhone", "requiresApproval", "sessionId") FROM stdin;
43504528-bf51-4f20-89f8-6e036ca51097	ORD-1760473115168-683	DINE_IN	PAID	376.00	0.00	376.00	\N	\N	fccd83df-d146-4ad2-b478-75ba2b3b464c	610a4b37-fbac-464b-9192-d91c3f68f3f7	321b6b7c-01ac-4dc7-a4b8-5eb8943d1f52	2025-10-14 20:18:35.17	2025-10-14 20:18:48.05	2025-10-14 20:18:48.048	\N	\N	\N	\N	t	\N
6f7826ce-f9e4-459c-96c3-bdbd3c156cb4	ORD-1760716049434-982	TAKEAWAY	PAID	24.00	0.00	24.00	\N	\N	\N	e711744f-21a7-475d-8b7d-1d71da92490c	a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb	2025-10-17 15:47:29.437	2025-10-17 15:47:31.389	2025-10-17 15:47:31.387	\N	\N	\N	\N	t	\N
60bb16c2-7818-4c13-8e14-81ba73c00c7e	ORD-1760716058196-098	TAKEAWAY	SERVED	24.00	0.00	24.00	\N	\N	\N	e711744f-21a7-475d-8b7d-1d71da92490c	a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb	2025-10-17 15:47:38.199	2025-10-17 15:48:00.298	\N	\N	\N	\N	\N	t	\N
015e2c66-8fbf-46c6-9c61-9f50358e6833	ORD-1760716092841-380	TAKEAWAY	SERVED	36.00	0.00	36.00	\N	asd	\N	e711744f-21a7-475d-8b7d-1d71da92490c	a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb	2025-10-17 15:48:12.842	2025-10-17 15:49:42.888	\N	\N	\N	\N	\N	t	\N
35ce5e7d-c9a7-4fd7-adbb-a22f6f4eaebe	ORD-1760719205668-117	TAKEAWAY	SERVED	376.00	1.00	375.00	12	12	\N	610a4b37-fbac-464b-9192-d91c3f68f3f7	321b6b7c-01ac-4dc7-a4b8-5eb8943d1f52	2025-10-17 16:40:05.67	2025-10-17 16:40:37.608	\N	\N	\N	\N	\N	t	\N
ed34d3a6-51a8-403e-ac52-b8a3611dd0c0	ORD-1760807576570-066	TAKEAWAY	SERVED	15.99	0.00	15.99	\N	\N	\N	eb9b7328-7b73-42e2-b9f7-bf9b432ea849	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-18 17:12:56.571	2025-10-18 21:38:40.164	\N	\N	\N	\N	\N	t	\N
296931f0-88d1-45e7-8cd2-3a896f5726e0	ORD-1760807572090-826	TAKEAWAY	SERVED	47.97	0.00	47.97	\N	\N	\N	eb9b7328-7b73-42e2-b9f7-bf9b432ea849	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-18 17:12:52.093	2025-10-18 21:38:40.973	\N	\N	\N	\N	\N	t	\N
b03701a7-1729-45ce-bd36-29b0973e3571	ORD-1760985869072-220	DINE_IN	PAID	71.94	0.00	71.94	\N	\N	21535ad6-5ee4-43e6-884c-281f36464c5c	eb9b7328-7b73-42e2-b9f7-bf9b432ea849	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-20 18:44:29.074	2025-10-20 18:44:52.906	2025-10-20 18:44:52.904	\N	\N	\N	\N	t	\N
acb4b9aa-1fb7-4a60-a6e3-c52570aa065b	ORD-1761934245643-630	TAKEAWAY	SERVED	122.00	0.00	122.00	\N	\N	\N	610a4b37-fbac-464b-9192-d91c3f68f3f7	321b6b7c-01ac-4dc7-a4b8-5eb8943d1f52	2025-10-31 18:10:45.644	2025-10-31 18:11:09.126	\N	\N	\N	\N	\N	t	\N
1e2b18e6-fe78-4b45-99f7-19158ccbe375	ORD-1761934336206-834	TAKEAWAY	PENDING	132.00	0.00	132.00	\N	\N	\N	610a4b37-fbac-464b-9192-d91c3f68f3f7	321b6b7c-01ac-4dc7-a4b8-5eb8943d1f52	2025-10-31 18:12:16.208	2025-10-31 18:12:16.208	\N	\N	\N	\N	\N	t	\N
c9be219f-4ed5-4954-93b3-b95c5b7718cb	ORD-1761934609652-002	DINE_IN	PAID	11.98	0.00	11.98	\N	\N	48509f4f-6b31-4100-947d-4f1c210e34e6	bf2dcc4b-9f7e-4179-bd1d-da1a3186187e	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-31 18:16:49.654	2025-10-31 18:16:51.265	2025-10-31 18:16:51.264	\N	\N	\N	\N	t	\N
6c222849-319e-434f-be0c-c380335c5bd0	ORD-20251101-0001	DINE_IN	PENDING_APPROVAL	13.00	0.00	13.00	\N	\N	a1fcb227-7000-4070-bc2c-f3da8aee6fcc	\N	60288b5e-965c-43e3-aee8-38b2da36ee39	2025-11-01 09:54:45.144	2025-11-01 09:54:45.144	\N	\N	\N	\N	\N	t	50bde705-48b1-4157-94a8-8bb65bbecbe2
c3c68cc3-8752-4d03-a24f-2e9e5d36ff33	ORD-20251101-0002	DINE_IN	PENDING_APPROVAL	13.00	0.00	13.00	\N	\N	a1fcb227-7000-4070-bc2c-f3da8aee6fcc	\N	60288b5e-965c-43e3-aee8-38b2da36ee39	2025-11-01 10:27:47.497	2025-11-01 10:27:47.497	\N	\N	\N	\N	\N	t	50bde705-48b1-4157-94a8-8bb65bbecbe2
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, amount, method, status, "transactionId", notes, "orderId", "createdAt", "paidAt") FROM stdin;
62706e20-9aac-4cff-928c-7797634b8a45	376.00	CASH	COMPLETED	\N	\N	43504528-bf51-4f20-89f8-6e036ca51097	2025-10-14 20:18:48.031	2025-10-14 20:18:48.029
e1cf3bbf-2159-4f7e-add7-eb0a0f6edee8	24.00	CASH	COMPLETED	\N	\N	6f7826ce-f9e4-459c-96c3-bdbd3c156cb4	2025-10-17 15:47:31.363	2025-10-17 15:47:31.361
a56527a5-1c98-4f21-8b9c-e866ec4cace3	71.94	CASH	COMPLETED	\N	\N	b03701a7-1729-45ce-bd36-29b0973e3571	2025-10-20 18:44:52.888	2025-10-20 18:44:52.885
b50aa7a9-ecfd-48fe-9e26-3ac8c1f11760	11.98	CASH	COMPLETED	\N	\N	c9be219f-4ed5-4954-93b3-b95c5b7718cb	2025-10-31 18:16:51.248	2025-10-31 18:16:51.247
\.


--
-- Data for Name: pending_plan_changes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pending_plan_changes (id, "subscriptionId", "currentPlanId", "newPlanId", "newBillingCycle", "isUpgrade", "currentAmount", "newAmount", "prorationAmount", currency, "paymentRequired", "paymentStatus", "paymentIntentId", "paymentProvider", "scheduledFor", "appliedAt", reason, "failureReason", "createdAt", "updatedAt") FROM stdin;
7ea9bfed-56da-4f51-aeb8-20e50c5e0b26	c99a68b6-e7b5-410d-9daf-cac2da0b3147	8f1204b8-2fe6-4b6a-82b1-d20b4fd74d06	3714affb-c4e3-49b3-861d-56d808e1827a	MONTHLY	f	29.99	0.00	0.00	USD	f	COMPLETED	\N	\N	2025-10-28 19:55:19.498	\N	\N	\N	2025-10-14 20:07:36.224	2025-10-14 20:07:36.224
e2037f2d-98a1-40a7-8ec9-71b824dca94b	c99a68b6-e7b5-410d-9daf-cac2da0b3147	8f1204b8-2fe6-4b6a-82b1-d20b4fd74d06	3714affb-c4e3-49b3-861d-56d808e1827a	MONTHLY	f	29.99	0.00	0.00	USD	f	COMPLETED	\N	\N	2025-10-28 19:55:19.498	\N	\N	\N	2025-10-14 20:07:45.878	2025-10-14 20:07:45.878
f000daf5-1fa1-40a8-8dde-77b3c8815660	26eefef9-807d-40e4-93df-bbb09f637725	3714affb-c4e3-49b3-861d-56d808e1827a	8f1204b8-2fe6-4b6a-82b1-d20b4fd74d06	MONTHLY	t	0.00	29.99	29.97	USD	t	PENDING	\N	STRIPE	\N	\N	\N	\N	2025-10-17 16:39:11.16	2025-10-17 16:39:11.16
28377e5b-8936-43a8-849b-e597eb95d344	71d1b5c4-4445-410d-8758-fc96462346cf	3714affb-c4e3-49b3-861d-56d808e1827a	8f1204b8-2fe6-4b6a-82b1-d20b4fd74d06	MONTHLY	t	0.00	29.99	29.99	USD	t	PENDING	\N	STRIPE	\N	\N	\N	\N	2025-10-31 21:11:19.867	2025-10-31 21:11:19.867
\.


--
-- Data for Name: pos_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pos_settings (id, "tenantId", "enableTablelessMode", "enableTwoStepCheckout", "createdAt", "updatedAt", "showProductImages", "enableCustomerOrdering") FROM stdin;
03559f4c-ddb2-418b-a048-4d38f69cdfe8	a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb	t	t	2025-10-17 15:47:12.901	2025-10-17 15:47:50.934	t	t
e60a35f4-5976-4c16-a63e-87936b3ee11b	321b6b7c-01ac-4dc7-a4b8-5eb8943d1f52	t	t	2025-10-17 16:34:47.639	2025-10-17 16:39:47.686	t	t
cb5648cf-da77-4799-987e-75e869f3a442	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	f	f	2025-10-18 14:42:24.771	2025-10-18 18:54:01.581	t	t
20d285c6-16a4-4387-b238-c2b8eb444471	60288b5e-965c-43e3-aee8-38b2da36ee39	f	f	2025-10-31 18:28:24.222	2025-11-01 07:28:23.541	t	t
\.


--
-- Data for Name: product_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_images (id, url, filename, size, "mimeType", "tenantId", "createdAt") FROM stdin;
b488fefd-b511-44b2-89a8-2cf3525fa96f	/uploads/products/a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb/6e79dda3-de0d-4516-805c-bb9099daba83.png	ChatGPT Image Oct 17, 2025, 12_00_56 AM.png	82149	image/png	a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb	2025-10-17 15:46:29.133
00960de1-1239-4d20-8862-10939632ae8c	/uploads/products/a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb/94e668f1-2bf5-46f2-b5f5-1dacb3e0b0dc.png	ChatGPT Image Oct 17, 2025, 12_00_56 AM.png	82149	image/png	a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb	2025-10-17 15:46:36.056
7b425157-7356-4996-a247-0b87fe7dbc5c	/uploads/products/a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb/354c9522-0ecb-44e7-bfd3-bbd57b451526.jpg	URKMEZ RENK PALETI.jpg	28427	image/jpeg	a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb	2025-10-17 15:46:36.151
1357e92d-45b1-4ac1-a109-cb789e539671	/uploads/products/a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb/be9038d3-48c2-499b-aac2-3036adeb4fc8.jpg	URKMEZ RENK PALETI.jpg	28427	image/jpeg	a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb	2025-10-17 15:46:39.089
d01b3b50-cd3c-49ce-b80f-f6a5da5aa7ed	/uploads/products/321b6b7c-01ac-4dc7-a4b8-5eb8943d1f52/64553e1a-d840-47b5-943f-1088b09c10b5.jpg	indir.jpg	7016	image/jpeg	321b6b7c-01ac-4dc7-a4b8-5eb8943d1f52	2025-10-17 16:42:47.542
0e7d2a64-9eaf-4efd-8c40-d557d983eb01	/uploads/products/60288b5e-965c-43e3-aee8-38b2da36ee39/fe1cb704-77da-48cb-95f2-487667dbdf65.png	ChatGPT Image Oct 17, 2025, 12_00_56 AM.png	82149	image/png	60288b5e-965c-43e3-aee8-38b2da36ee39	2025-10-31 19:21:32.923
\.


--
-- Data for Name: product_modifier_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_modifier_groups (id, "displayOrder", "productId", "groupId", "createdAt") FROM stdin;
\.


--
-- Data for Name: product_to_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_to_images (id, "order", "productId", "imageId", "createdAt") FROM stdin;
e9259a0b-5aea-47fe-a48b-df48b48f75ea	0	7283865d-8fd9-4756-950f-cb9f8a21daca	7b425157-7356-4996-a247-0b87fe7dbc5c	2025-10-17 15:47:06.412
f84aec65-fbe2-4082-ac71-3fbe1b71a534	1	7283865d-8fd9-4756-950f-cb9f8a21daca	00960de1-1239-4d20-8862-10939632ae8c	2025-10-17 15:47:06.417
631ca80e-917c-4aec-b1d0-dabd32d0a1b7	0	2052e7e3-8e77-4f8d-b7e0-86419c9904a4	d01b3b50-cd3c-49ce-b80f-f6a5da5aa7ed	2025-10-17 16:43:21.289
1cf09c91-43fc-417e-9e90-729c8bb1eb48	0	6b23ea46-d552-4925-a62f-d6eeceeb37d9	0e7d2a64-9eaf-4efd-8c40-d557d983eb01	2025-10-31 19:34:28.646
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, name, description, price, image, "isAvailable", "stockTracked", "currentStock", "categoryId", "tenantId", "createdAt", "updatedAt") FROM stdin;
af093b44-fd3d-4cab-9de4-76b66bb8fd2f	Caesar Salad	Fresh romaine lettuce with Caesar dressing and croutons	8.99	\N	t	t	50	25eb0bba-0451-4680-93d2-a06893cfa067	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 19:44:29.583	2025-10-14 19:44:29.583
89f765ae-6471-457b-b465-689128b4aca4	Grilled Salmon	Fresh Atlantic salmon with vegetables	24.99	\N	t	t	15	b10f7c0b-d344-4ec1-ac79-3c79f6d230d3	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 19:44:29.583	2025-10-14 19:44:29.583
3372ab3f-80c9-49e1-8b05-ff2afd2f77af	Coca Cola	Refreshing soft drink	2.99	\N	t	t	100	b3602603-8614-436a-b25c-3d056b534d8a	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 19:44:29.583	2025-10-14 19:44:29.583
57b9d809-95d6-4c8a-a026-7989d6726fa9	Coffee	Freshly brewed coffee	3.99	\N	t	f	0	b3602603-8614-436a-b25c-3d056b534d8a	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 19:44:29.583	2025-10-14 19:44:29.583
14871bcf-f9d3-49ce-a76f-6058f9b0613a	Dapenci	Acılı tavuklu yemek	122.00	https://upload.wikimedia.org/wikipedia/commons/1/16/Dapanji_urumqi.jpg	t	f	12	264c3674-d5b1-450c-bece-1de21876c2b7	321b6b7c-01ac-4dc7-a4b8-5eb8943d1f52	2025-10-14 20:16:00.721	2025-10-14 20:16:00.721
6686afae-a175-44c5-8c81-acb75b1b8dd6	Lazici	Açılı tavuk	132.00	https://epicesdecru.com/upload/share/_1200x590_crop_center-center_none/Poulet-Dapanji.jpg	t	f	12	264c3674-d5b1-450c-bece-1de21876c2b7	321b6b7c-01ac-4dc7-a4b8-5eb8943d1f52	2025-10-14 20:17:19.748	2025-10-14 20:18:04.066
7283865d-8fd9-4756-950f-cb9f8a21daca	öylesine	senem	12.00	\N	t	f	123	75644dc4-c5ba-4e39-840f-2fee0419d51a	a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb	2025-10-17 15:47:06.388	2025-10-17 15:47:06.388
2052e7e3-8e77-4f8d-b7e0-86419c9904a4	asfda	aef	23.00	\N	t	f	23	264c3674-d5b1-450c-bece-1de21876c2b7	321b6b7c-01ac-4dc7-a4b8-5eb8943d1f52	2025-10-17 16:43:21.269	2025-10-17 16:43:21.269
8fb3ce42-8b9e-4c40-beed-21e1d2e101ec	Beef Burger	Premium beef patty with cheese and fries	15.99	\N	t	t	37	b10f7c0b-d344-4ec1-ac79-3c79f6d230d3	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 19:44:29.583	2025-10-20 18:44:52.912
8e95ef6c-2e88-455a-bc4d-4067e5931fec	Chocolate Lava Cake	Warm chocolate cake with molten center	7.99	\N	t	t	19	0bccd594-1eca-4d74-8eac-58216b719e51	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 19:44:29.583	2025-10-20 18:44:52.928
5a8832a4-5d20-404b-a1ac-37b0509903cc	Garlic Bread	Toasted bread with garlic butter	5.99	\N	t	t	28	25eb0bba-0451-4680-93d2-a06893cfa067	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 19:44:29.583	2025-10-31 18:16:51.275
6b23ea46-d552-4925-a62f-d6eeceeb37d9	select	denem	13.00	\N	t	f	123	8ee98ad3-06ac-482d-bc27-7a6db64a7708	60288b5e-965c-43e3-aee8-38b2da36ee39	2025-10-31 19:34:28.624	2025-10-31 19:34:28.624
\.


--
-- Data for Name: qr_menu_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qr_menu_settings (id, "tenantId", "primaryColor", "secondaryColor", "backgroundColor", "fontFamily", "logoUrl", "showRestaurantInfo", "showPrices", "showDescription", "showImages", "layoutStyle", "itemsPerRow", "enableTableQR", "tableQRMessage", "createdAt", "updatedAt") FROM stdin;
911b8dc9-221e-4953-97a6-2c524c2727de	a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb	#3B82F6	#1F2937	#F9FAFB	Inter	\N	t	t	t	t	GRID	2	t	Scan to view our menu	2025-10-17 15:49:56.165	2025-10-17 15:49:56.165
401b9e73-f87d-45b3-bd87-10b513dc77bb	321b6b7c-01ac-4dc7-a4b8-5eb8943d1f52	#1F2937	#111827	#F9FAFB	Playfair Display	\N	t	t	t	t	LIST	1	t	Scan to view our menu	2025-10-17 16:35:23.465	2025-10-17 16:38:27.958
7afb8807-050e-42f4-b99c-cb627346dd7e	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	#3B82F6	#1F2937	#F9FAFB	Inter	\N	t	t	t	t	GRID	2	t	Scan to view our menu	2025-10-18 15:13:53.875	2025-10-18 15:13:53.875
2f21b410-24da-439c-95a4-bc0acbc3164b	60288b5e-965c-43e3-aee8-38b2da36ee39	#3B82F6	#1F2937	#F9FAFB	Inter	\N	f	t	t	t	GRID	2	t	Scan to view our menu	2025-10-31 18:23:23.552	2025-10-31 19:30:29.24
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_movements (id, type, quantity, reason, notes, "productId", "userId", "tenantId", "createdAt") FROM stdin;
039e8078-61dc-4f8c-b031-d3fd69a8ccfe	OUT	3	Order ORD-1760985869072-220	\N	8fb3ce42-8b9e-4c40-beed-21e1d2e101ec	eb9b7328-7b73-42e2-b9f7-bf9b432ea849	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-20 18:44:52.915
bc091860-fe61-4f5b-8b0a-3cc2f3afb21e	OUT	3	Order ORD-1760985869072-220	\N	8e95ef6c-2e88-455a-bc4d-4067e5931fec	eb9b7328-7b73-42e2-b9f7-bf9b432ea849	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-20 18:44:52.93
f6dad6d7-79d4-4ae8-9cb2-0757da984ccd	OUT	2	Order ORD-1761934609652-002	\N	5a8832a4-5d20-404b-a1ac-37b0509903cc	bf2dcc4b-9f7e-4179-bd1d-da1a3186187e	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-31 18:16:51.279
\.


--
-- Data for Name: subscription_payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscription_payments (id, "subscriptionId", amount, currency, status, "paymentProvider", "stripePaymentIntentId", "iyzicoPaymentId", "paymentMethod", last4, "cardBrand", "failureCode", "failureMessage", "retryCount", "paidAt", "refundedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscription_plans (id, name, "displayName", description, "monthlyPrice", "yearlyPrice", currency, "trialDays", "maxUsers", "maxTables", "maxProducts", "maxCategories", "maxMonthlyOrders", "advancedReports", "multiLocation", "customBranding", "apiAccess", "prioritySupport", "inventoryTracking", "kdsIntegration", "isActive", "createdAt", "updatedAt") FROM stdin;
3714affb-c4e3-49b3-861d-56d808e1827a	FREE	Free Plan	Perfect for small restaurants getting started	0.00	0.00	USD	0	2	5	25	5	50	f	f	f	f	f	f	t	t	2025-10-14 19:44:29.284	2025-10-14 19:44:29.284
8f1204b8-2fe6-4b6a-82b1-d20b4fd74d06	BASIC	Basic Plan	Great for growing restaurants	29.99	299.99	USD	14	5	20	100	20	500	f	f	f	f	f	t	t	t	2025-10-14 19:44:29.313	2025-10-14 19:44:29.313
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscriptions (id, "tenantId", "planId", status, "billingCycle", "paymentProvider", "startDate", "currentPeriodStart", "currentPeriodEnd", "cancelledAt", "endedAt", "isTrialPeriod", "trialStart", "trialEnd", "stripeSubscriptionId", "iyzicoSubscriptionId", "stripeCustomerId", "iyzicoCustomerId", amount, currency, "autoRenew", "cancelAtPeriodEnd", "cancellationReason", "createdAt", "updatedAt") FROM stdin;
eeb76637-fd3c-43e3-a957-771e507f1cb4	b28b676f-d3e4-434b-9ce6-cae6f732fb14	3714affb-c4e3-49b3-861d-56d808e1827a	ACTIVE	MONTHLY	STRIPE	2025-10-14 19:49:36.573	2025-10-14 19:49:36.573	2035-10-14 19:49:36.573	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	USD	t	f	\N	2025-10-14 19:49:36.579	2025-10-14 19:49:36.579
8a033ed9-4518-4253-b92f-bbc4c4a494bc	d2512b66-5b3f-4839-a3c2-eb3585d2ab4a	3714affb-c4e3-49b3-861d-56d808e1827a	ACTIVE	MONTHLY	STRIPE	2025-10-14 19:49:53.346	2025-10-14 19:49:53.346	2035-10-14 19:49:53.346	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	USD	t	f	\N	2025-10-14 19:49:53.348	2025-10-14 19:49:53.348
26eefef9-807d-40e4-93df-bbb09f637725	321b6b7c-01ac-4dc7-a4b8-5eb8943d1f52	3714affb-c4e3-49b3-861d-56d808e1827a	ACTIVE	MONTHLY	STRIPE	2025-10-14 20:12:57.135	2025-10-14 20:12:57.135	2035-10-14 20:12:57.135	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	USD	t	f	\N	2025-10-14 20:12:57.137	2025-10-14 20:12:57.137
72566592-d8bb-444e-b954-de12deac32b4	a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb	3714affb-c4e3-49b3-861d-56d808e1827a	ACTIVE	MONTHLY	STRIPE	2025-10-17 15:43:45.231	2025-10-17 15:43:45.231	2035-10-17 15:43:45.231	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	USD	t	f	\N	2025-10-17 15:43:45.233	2025-10-17 15:43:45.233
c99a68b6-e7b5-410d-9daf-cac2da0b3147	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	8f1204b8-2fe6-4b6a-82b1-d20b4fd74d06	EXPIRED	MONTHLY	STRIPE	2025-10-14 19:55:19.498	2025-10-14 19:55:19.498	2025-10-28 19:55:19.498	\N	2025-10-29 00:00:00.063	t	2025-10-14 19:55:19.498	2025-10-28 19:55:19.498	\N	\N	\N	\N	29.99	USD	t	f	\N	2025-10-14 19:55:19.503	2025-10-29 00:00:00.231
71d1b5c4-4445-410d-8758-fc96462346cf	60288b5e-965c-43e3-aee8-38b2da36ee39	3714affb-c4e3-49b3-861d-56d808e1827a	ACTIVE	MONTHLY	STRIPE	2025-10-31 18:23:04.763	2025-10-31 18:23:04.763	2035-10-31 18:23:04.763	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	USD	t	f	\N	2025-10-31 18:23:04.765	2025-10-31 18:23:04.765
\.


--
-- Data for Name: tables; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tables (id, number, capacity, section, status, "tenantId", "createdAt", "updatedAt") FROM stdin;
02ec5da6-abc6-4570-b0b5-926ba7abf695	1	2	Main Hall	AVAILABLE	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 19:44:29.596	2025-10-14 19:44:29.596
36b38d08-d334-4740-8be9-872efeae4f79	3	4	Main Hall	AVAILABLE	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 19:44:29.596	2025-10-14 19:44:29.596
f6223243-eb29-4e01-867a-e49bb94da274	4	6	Main Hall	AVAILABLE	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 19:44:29.596	2025-10-14 19:44:29.596
7ff82f15-3e18-4102-97e3-c22466fbf2fb	1	4	\N	AVAILABLE	321b6b7c-01ac-4dc7-a4b8-5eb8943d1f52	2025-10-14 20:14:31.345	2025-10-14 20:14:31.345
fccd83df-d146-4ad2-b478-75ba2b3b464c	2	4	\N	AVAILABLE	321b6b7c-01ac-4dc7-a4b8-5eb8943d1f52	2025-10-14 20:14:38.725	2025-10-14 20:18:48.204
9bf61ddf-2727-4703-b4b3-781088585a89	1	4	\N	AVAILABLE	a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb	2025-10-17 15:44:11.121	2025-10-17 15:44:11.121
3d0e2c9a-3a62-46f9-a1fe-24fdf9de3d5e	2	4	\N	AVAILABLE	a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb	2025-10-17 15:44:15.826	2025-10-17 15:44:15.826
21535ad6-5ee4-43e6-884c-281f36464c5c	2	4	Main Hall	AVAILABLE	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 19:44:29.596	2025-10-20 18:44:53.083
48509f4f-6b31-4100-947d-4f1c210e34e6	5	2	Terrace	AVAILABLE	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 19:44:29.596	2025-10-31 18:16:51.393
a1fcb227-7000-4070-bc2c-f3da8aee6fcc	1	4	\N	AVAILABLE	60288b5e-965c-43e3-aee8-38b2da36ee39	2025-10-31 19:25:49.36	2025-10-31 19:25:49.36
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (id, name, subdomain, status, "currentPlanId", "paymentRegion", "trialUsed", "trialStartedAt", "trialEndsAt", "createdAt", "updatedAt") FROM stdin;
b28b676f-d3e4-434b-9ce6-cae6f732fb14	My New Restaurant	my-new-restaurant	ACTIVE	3714affb-c4e3-49b3-861d-56d808e1827a	INTERNATIONAL	f	\N	\N	2025-10-14 19:49:36.563	2025-10-14 19:49:36.563
d2512b66-5b3f-4839-a3c2-eb3585d2ab4a	Test	test	ACTIVE	3714affb-c4e3-49b3-861d-56d808e1827a	INTERNATIONAL	f	\N	\N	2025-10-14 19:49:53.338	2025-10-14 19:49:53.338
0bf698e2-d729-49cc-82c1-d7bb6f9eb361	Demo Restaurant	demo	ACTIVE	8f1204b8-2fe6-4b6a-82b1-d20b4fd74d06	INTERNATIONAL	t	2025-10-14 19:55:19.498	2025-10-28 19:55:19.498	2025-10-14 19:44:29.323	2025-10-14 19:55:19.533
321b6b7c-01ac-4dc7-a4b8-5eb8943d1f52	Dolan	dolan	ACTIVE	3714affb-c4e3-49b3-861d-56d808e1827a	INTERNATIONAL	f	\N	\N	2025-10-14 20:12:57.127	2025-10-14 20:12:57.127
a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb	deneme	deneme	ACTIVE	3714affb-c4e3-49b3-861d-56d808e1827a	INTERNATIONAL	f	\N	\N	2025-10-17 15:43:45.213	2025-10-17 15:43:45.213
60288b5e-965c-43e3-aee8-38b2da36ee39	admin	admin	ACTIVE	3714affb-c4e3-49b3-861d-56d808e1827a	INTERNATIONAL	f	\N	\N	2025-10-31 18:23:04.759	2025-10-31 18:23:04.759
\.


--
-- Data for Name: user_notification_reads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_notification_reads (id, "notificationId", "userId", "readAt") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password, "firstName", "lastName", role, status, "tenantId", "createdAt", "updatedAt", avatar, "emailVerificationExpires", "emailVerificationToken", "emailVerified", "lastLogin", phone, "resetToken", "resetTokenExpiry") FROM stdin;
eb9b7328-7b73-42e2-b9f7-bf9b432ea849	admin@restaurant.com	$2a$10$SMo5Si6w6vQUS9eOyYsQKOeYBgStBYlAxXAqzZOxVaya5WZCuj6by	John	Admin	ADMIN	ACTIVE	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 19:44:29.534	2025-10-14 19:44:29.534	\N	\N	\N	f	\N	\N	\N	\N
e8dc9c8a-d522-4a6c-9e35-8eab74a4eb3f	kitchen@restaurant.com	$2a$10$SMo5Si6w6vQUS9eOyYsQKOeYBgStBYlAxXAqzZOxVaya5WZCuj6by	Mike	Chef	KITCHEN	ACTIVE	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 19:44:29.548	2025-10-14 19:44:29.548	\N	\N	\N	f	\N	\N	\N	\N
fb77b1c0-d47a-4668-9607-e799a7f61657	newuser@restaurant.com	$2a$10$4OqEXwWYoKDRemqTqyFoR.QacZmq5.eSU0kzQmJkpcMq8K.D04s1y	New	User	ADMIN	ACTIVE	b28b676f-d3e4-434b-9ce6-cae6f732fb14	2025-10-14 19:49:36.82	2025-10-14 19:49:36.82	\N	\N	\N	f	\N	\N	\N	\N
3396af08-1df6-4739-9db9-6654fa00f99c	test2@test.com	$2a$10$53injWIel6OhHQrn/Sw.hOLqi.uZTBR2VqtrHCntVuu/nEJBOHfVq	T	U	ADMIN	ACTIVE	d2512b66-5b3f-4839-a3c2-eb3585d2ab4a	2025-10-14 19:49:53.53	2025-10-14 19:49:53.53	\N	\N	\N	f	\N	\N	\N	\N
bf2dcc4b-9f7e-4179-bd1d-da1a3186187e	tarik@gmail.com	$2a$10$NfT1ZtTRH2Cv8tXriw53Z.IdmMBxoTLWI84J1cyI2eGer8jgjCF72	tarik	ucar	WAITER	ACTIVE	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 20:08:45.024	2025-10-14 20:08:45.024	\N	\N	\N	f	\N	\N	\N	\N
440ef0b2-5ac7-4cbd-a5bb-e7bb5fa09fb6	sel@gmail.com	$2a$10$ibLr9.qOtTt7ugMxXBwUpOJttkoP06yyPk3Pe.goZcdtW/hRHT7lO	admin	admin	WAITER	ACTIVE	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 20:09:10.738	2025-10-14 20:09:10.738	\N	\N	\N	f	\N	\N	\N	\N
aa4975d8-8398-4189-af51-a0f4960d2bbc	selma@gmail.com	$2a$10$FxnoyqdKr4DczKzk9/Yb.eu5yDX0DDIv4e3EeKQftUPVv3OLkydAa	admin	admin	WAITER	ACTIVE	0bf698e2-d729-49cc-82c1-d7bb6f9eb361	2025-10-14 20:09:30.75	2025-10-14 20:09:30.75	\N	\N	\N	f	\N	\N	\N	\N
610a4b37-fbac-464b-9192-d91c3f68f3f7	jarulla.f@gmail.com	$2a$10$xuAaeSFXbrEEQsIMPbMIXOAfPAlX2/Y9KAR5K7eEKw4zXwO6BOVai	carullah	Tursun	ADMIN	ACTIVE	321b6b7c-01ac-4dc7-a4b8-5eb8943d1f52	2025-10-14 20:12:57.343	2025-10-14 20:12:57.343	\N	\N	\N	f	\N	\N	\N	\N
e711744f-21a7-475d-8b7d-1d71da92490c	deneme@gmail.com	$2a$10$gC5qlAFDl8tDlxi9Ed0RK.Zs8vKx7Kw.nLKOqOY7Eh59yGOPzZzwy	deneme	deneme	ADMIN	ACTIVE	a54bdfd5-8ece-4c7d-804c-5c75ea8d31bb	2025-10-17 15:43:45.429	2025-10-17 15:43:45.429	\N	\N	\N	f	\N	\N	\N	\N
d5cf903b-8470-4f64-9e0a-61aecd947a02	jarulla.t@gmail.com	$2a$10$7qeo2d5sToa81Qo0YpRtN.pNYzBse6owRKiUhPmsG//NvrGQMTT62	ca	rt	WAITER	ACTIVE	321b6b7c-01ac-4dc7-a4b8-5eb8943d1f52	2025-10-17 16:45:29.872	2025-10-17 16:45:29.872	\N	\N	\N	f	\N	\N	\N	\N
96e55777-eef0-47ac-a310-5fc96f41cdd3	admin@gmail.com	$2a$10$6op/U4Kwky2RJZ5nhVwPK.8uRu4cUTyKu7go.pudAJ67axZnKb2/i	admin	admin	ADMIN	ACTIVE	60288b5e-965c-43e3-aee8-38b2da36ee39	2025-10-31 18:23:04.922	2025-10-31 18:23:04.922	\N	\N	\N	f	\N	\N	\N	\N
\.


--
-- Data for Name: waiter_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.waiter_requests (id, message, status, "sessionId", "tableId", "acknowledgedAt", "acknowledgedById", "completedAt", "createdAt", "updatedAt") FROM stdin;
2155b229-c7ca-4046-aaa6-4b95d0793951	\N	PENDING	50bde705-48b1-4157-94a8-8bb65bbecbe2	a1fcb227-7000-4070-bc2c-f3da8aee6fcc	\N	\N	\N	2025-11-01 09:59:01.913	2025-11-01 09:59:01.913
b243aacc-142a-45f0-8b36-bfb64ea1a95a	\N	PENDING	50bde705-48b1-4157-94a8-8bb65bbecbe2	a1fcb227-7000-4070-bc2c-f3da8aee6fcc	\N	\N	\N	2025-11-01 10:41:03.196	2025-11-01 10:41:03.196
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: bill_requests bill_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_requests
    ADD CONSTRAINT bill_requests_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: contact_messages contact_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_messages
    ADD CONSTRAINT contact_messages_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: integration_settings integration_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_settings
    ADD CONSTRAINT integration_settings_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: modifier_groups modifier_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifier_groups
    ADD CONSTRAINT modifier_groups_pkey PRIMARY KEY (id);


--
-- Name: modifiers modifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifiers
    ADD CONSTRAINT modifiers_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: order_item_modifiers order_item_modifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item_modifiers
    ADD CONSTRAINT order_item_modifiers_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: pending_plan_changes pending_plan_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_plan_changes
    ADD CONSTRAINT pending_plan_changes_pkey PRIMARY KEY (id);


--
-- Name: pos_settings pos_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pos_settings
    ADD CONSTRAINT pos_settings_pkey PRIMARY KEY (id);


--
-- Name: product_images product_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_pkey PRIMARY KEY (id);


--
-- Name: product_modifier_groups product_modifier_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_modifier_groups
    ADD CONSTRAINT product_modifier_groups_pkey PRIMARY KEY (id);


--
-- Name: product_to_images product_to_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_to_images
    ADD CONSTRAINT product_to_images_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: qr_menu_settings qr_menu_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qr_menu_settings
    ADD CONSTRAINT qr_menu_settings_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: subscription_payments subscription_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT subscription_payments_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: tables tables_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT tables_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: user_notification_reads user_notification_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_reads
    ADD CONSTRAINT user_notification_reads_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: waiter_requests waiter_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waiter_requests
    ADD CONSTRAINT waiter_requests_pkey PRIMARY KEY (id);


--
-- Name: api_keys_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "api_keys_isActive_idx" ON public.api_keys USING btree ("isActive");


--
-- Name: api_keys_key_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_keys_key_idx ON public.api_keys USING btree (key);


--
-- Name: api_keys_key_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX api_keys_key_key ON public.api_keys USING btree (key);


--
-- Name: api_keys_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "api_keys_tenantId_idx" ON public.api_keys USING btree ("tenantId");


--
-- Name: bill_requests_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "bill_requests_sessionId_idx" ON public.bill_requests USING btree ("sessionId");


--
-- Name: bill_requests_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bill_requests_status_idx ON public.bill_requests USING btree (status);


--
-- Name: bill_requests_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "bill_requests_tableId_idx" ON public.bill_requests USING btree ("tableId");


--
-- Name: categories_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "categories_tenantId_idx" ON public.categories USING btree ("tenantId");


--
-- Name: contact_messages_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "contact_messages_createdAt_idx" ON public.contact_messages USING btree ("createdAt");


--
-- Name: contact_messages_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX contact_messages_status_idx ON public.contact_messages USING btree (status);


--
-- Name: customers_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customers_email_idx ON public.customers USING btree (email);


--
-- Name: customers_phone_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customers_phone_idx ON public.customers USING btree (phone);


--
-- Name: customers_tenantId_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customers_tenantId_email_key" ON public.customers USING btree ("tenantId", email);


--
-- Name: customers_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customers_tenantId_idx" ON public.customers USING btree ("tenantId");


--
-- Name: customers_tenantId_phone_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customers_tenantId_phone_key" ON public.customers USING btree ("tenantId", phone);


--
-- Name: integration_settings_integrationType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "integration_settings_integrationType_idx" ON public.integration_settings USING btree ("integrationType");


--
-- Name: integration_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "integration_settings_tenantId_idx" ON public.integration_settings USING btree ("tenantId");


--
-- Name: integration_settings_tenantId_integrationType_provider_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "integration_settings_tenantId_integrationType_provider_key" ON public.integration_settings USING btree ("tenantId", "integrationType", provider);


--
-- Name: invoices_dueDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_dueDate_idx" ON public.invoices USING btree ("dueDate");


--
-- Name: invoices_invoiceNumber_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_invoiceNumber_idx" ON public.invoices USING btree ("invoiceNumber");


--
-- Name: invoices_invoiceNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "invoices_invoiceNumber_key" ON public.invoices USING btree ("invoiceNumber");


--
-- Name: invoices_paymentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "invoices_paymentId_key" ON public.invoices USING btree ("paymentId");


--
-- Name: invoices_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX invoices_status_idx ON public.invoices USING btree (status);


--
-- Name: invoices_subscriptionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_subscriptionId_idx" ON public.invoices USING btree ("subscriptionId");


--
-- Name: modifier_groups_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifier_groups_isActive_idx" ON public.modifier_groups USING btree ("isActive");


--
-- Name: modifier_groups_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifier_groups_tenantId_idx" ON public.modifier_groups USING btree ("tenantId");


--
-- Name: modifiers_groupId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifiers_groupId_idx" ON public.modifiers USING btree ("groupId");


--
-- Name: modifiers_isAvailable_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifiers_isAvailable_idx" ON public.modifiers USING btree ("isAvailable");


--
-- Name: modifiers_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifiers_tenantId_idx" ON public.modifiers USING btree ("tenantId");


--
-- Name: notifications_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "notifications_createdAt_idx" ON public.notifications USING btree ("createdAt");


--
-- Name: notifications_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "notifications_tenantId_idx" ON public.notifications USING btree ("tenantId");


--
-- Name: notifications_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "notifications_userId_idx" ON public.notifications USING btree ("userId");


--
-- Name: order_item_modifiers_modifierId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_item_modifiers_modifierId_idx" ON public.order_item_modifiers USING btree ("modifierId");


--
-- Name: order_item_modifiers_orderItemId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_item_modifiers_orderItemId_idx" ON public.order_item_modifiers USING btree ("orderItemId");


--
-- Name: order_items_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_items_orderId_idx" ON public.order_items USING btree ("orderId");


--
-- Name: order_items_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_items_productId_idx" ON public.order_items USING btree ("productId");


--
-- Name: orders_approvedById_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_approvedById_idx" ON public.orders USING btree ("approvedById");


--
-- Name: orders_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_customerId_idx" ON public.orders USING btree ("customerId");


--
-- Name: orders_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_sessionId_idx" ON public.orders USING btree ("sessionId");


--
-- Name: orders_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orders_status_idx ON public.orders USING btree (status);


--
-- Name: orders_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_tableId_idx" ON public.orders USING btree ("tableId");


--
-- Name: orders_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_tenantId_idx" ON public.orders USING btree ("tenantId");


--
-- Name: orders_tenantId_orderNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "orders_tenantId_orderNumber_key" ON public.orders USING btree ("tenantId", "orderNumber");


--
-- Name: orders_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_userId_idx" ON public.orders USING btree ("userId");


--
-- Name: payments_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "payments_orderId_idx" ON public.payments USING btree ("orderId");


--
-- Name: payments_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payments_status_idx ON public.payments USING btree (status);


--
-- Name: pending_plan_changes_paymentStatus_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pending_plan_changes_paymentStatus_idx" ON public.pending_plan_changes USING btree ("paymentStatus");


--
-- Name: pending_plan_changes_scheduledFor_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pending_plan_changes_scheduledFor_idx" ON public.pending_plan_changes USING btree ("scheduledFor");


--
-- Name: pending_plan_changes_subscriptionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pending_plan_changes_subscriptionId_idx" ON public.pending_plan_changes USING btree ("subscriptionId");


--
-- Name: pos_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pos_settings_tenantId_idx" ON public.pos_settings USING btree ("tenantId");


--
-- Name: pos_settings_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "pos_settings_tenantId_key" ON public.pos_settings USING btree ("tenantId");


--
-- Name: product_images_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_images_tenantId_idx" ON public.product_images USING btree ("tenantId");


--
-- Name: product_modifier_groups_groupId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_modifier_groups_groupId_idx" ON public.product_modifier_groups USING btree ("groupId");


--
-- Name: product_modifier_groups_productId_groupId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "product_modifier_groups_productId_groupId_key" ON public.product_modifier_groups USING btree ("productId", "groupId");


--
-- Name: product_modifier_groups_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_modifier_groups_productId_idx" ON public.product_modifier_groups USING btree ("productId");


--
-- Name: product_to_images_imageId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_to_images_imageId_idx" ON public.product_to_images USING btree ("imageId");


--
-- Name: product_to_images_productId_imageId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "product_to_images_productId_imageId_key" ON public.product_to_images USING btree ("productId", "imageId");


--
-- Name: product_to_images_productId_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_to_images_productId_order_idx" ON public.product_to_images USING btree ("productId", "order");


--
-- Name: products_categoryId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "products_categoryId_idx" ON public.products USING btree ("categoryId");


--
-- Name: products_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "products_tenantId_idx" ON public.products USING btree ("tenantId");


--
-- Name: qr_menu_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "qr_menu_settings_tenantId_idx" ON public.qr_menu_settings USING btree ("tenantId");


--
-- Name: qr_menu_settings_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "qr_menu_settings_tenantId_key" ON public.qr_menu_settings USING btree ("tenantId");


--
-- Name: stock_movements_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_movements_productId_idx" ON public.stock_movements USING btree ("productId");


--
-- Name: stock_movements_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_movements_tenantId_idx" ON public.stock_movements USING btree ("tenantId");


--
-- Name: stock_movements_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_movements_userId_idx" ON public.stock_movements USING btree ("userId");


--
-- Name: subscription_payments_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscription_payments_createdAt_idx" ON public.subscription_payments USING btree ("createdAt");


--
-- Name: subscription_payments_iyzicoPaymentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscription_payments_iyzicoPaymentId_key" ON public.subscription_payments USING btree ("iyzicoPaymentId");


--
-- Name: subscription_payments_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX subscription_payments_status_idx ON public.subscription_payments USING btree (status);


--
-- Name: subscription_payments_stripePaymentIntentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscription_payments_stripePaymentIntentId_key" ON public.subscription_payments USING btree ("stripePaymentIntentId");


--
-- Name: subscription_payments_subscriptionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscription_payments_subscriptionId_idx" ON public.subscription_payments USING btree ("subscriptionId");


--
-- Name: subscription_plans_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX subscription_plans_name_key ON public.subscription_plans USING btree (name);


--
-- Name: subscriptions_currentPeriodEnd_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscriptions_currentPeriodEnd_idx" ON public.subscriptions USING btree ("currentPeriodEnd");


--
-- Name: subscriptions_iyzicoSubscriptionId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscriptions_iyzicoSubscriptionId_key" ON public.subscriptions USING btree ("iyzicoSubscriptionId");


--
-- Name: subscriptions_planId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscriptions_planId_idx" ON public.subscriptions USING btree ("planId");


--
-- Name: subscriptions_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX subscriptions_status_idx ON public.subscriptions USING btree (status);


--
-- Name: subscriptions_stripeSubscriptionId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscriptions_stripeSubscriptionId_key" ON public.subscriptions USING btree ("stripeSubscriptionId");


--
-- Name: subscriptions_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscriptions_tenantId_idx" ON public.subscriptions USING btree ("tenantId");


--
-- Name: tables_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "tables_tenantId_idx" ON public.tables USING btree ("tenantId");


--
-- Name: tables_tenantId_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "tables_tenantId_number_key" ON public.tables USING btree ("tenantId", number);


--
-- Name: tenants_currentPlanId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "tenants_currentPlanId_idx" ON public.tenants USING btree ("currentPlanId");


--
-- Name: tenants_subdomain_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX tenants_subdomain_key ON public.tenants USING btree (subdomain);


--
-- Name: user_notification_reads_notificationId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_notification_reads_notificationId_idx" ON public.user_notification_reads USING btree ("notificationId");


--
-- Name: user_notification_reads_notificationId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "user_notification_reads_notificationId_userId_key" ON public.user_notification_reads USING btree ("notificationId", "userId");


--
-- Name: user_notification_reads_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_notification_reads_userId_idx" ON public.user_notification_reads USING btree ("userId");


--
-- Name: users_emailVerificationToken_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "users_emailVerificationToken_key" ON public.users USING btree ("emailVerificationToken");


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_resetToken_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "users_resetToken_key" ON public.users USING btree ("resetToken");


--
-- Name: users_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "users_tenantId_idx" ON public.users USING btree ("tenantId");


--
-- Name: waiter_requests_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "waiter_requests_sessionId_idx" ON public.waiter_requests USING btree ("sessionId");


--
-- Name: waiter_requests_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX waiter_requests_status_idx ON public.waiter_requests USING btree (status);


--
-- Name: waiter_requests_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "waiter_requests_tableId_idx" ON public.waiter_requests USING btree ("tableId");


--
-- Name: api_keys api_keys_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT "api_keys_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bill_requests bill_requests_acknowledgedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_requests
    ADD CONSTRAINT "bill_requests_acknowledgedById_fkey" FOREIGN KEY ("acknowledgedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bill_requests bill_requests_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_requests
    ADD CONSTRAINT "bill_requests_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: categories categories_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "categories_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customers customers_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT "customers_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: integration_settings integration_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_settings
    ADD CONSTRAINT "integration_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoices invoices_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public.subscription_payments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: modifier_groups modifier_groups_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifier_groups
    ADD CONSTRAINT "modifier_groups_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: modifiers modifiers_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifiers
    ADD CONSTRAINT "modifiers_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public.modifier_groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: modifiers modifiers_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifiers
    ADD CONSTRAINT "modifiers_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_item_modifiers order_item_modifiers_modifierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item_modifiers
    ADD CONSTRAINT "order_item_modifiers_modifierId_fkey" FOREIGN KEY ("modifierId") REFERENCES public.modifiers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: order_item_modifiers order_item_modifiers_orderItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item_modifiers
    ADD CONSTRAINT "order_item_modifiers_orderItemId_fkey" FOREIGN KEY ("orderItemId") REFERENCES public.order_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_items order_items_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "order_items_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_items order_items_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "order_items_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: orders orders_approvedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_approvedById_fkey" FOREIGN KEY ("approvedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orders orders_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payments payments_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pending_plan_changes pending_plan_changes_currentPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_plan_changes
    ADD CONSTRAINT "pending_plan_changes_currentPlanId_fkey" FOREIGN KEY ("currentPlanId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pending_plan_changes pending_plan_changes_newPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_plan_changes
    ADD CONSTRAINT "pending_plan_changes_newPlanId_fkey" FOREIGN KEY ("newPlanId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pending_plan_changes pending_plan_changes_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_plan_changes
    ADD CONSTRAINT "pending_plan_changes_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pos_settings pos_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pos_settings
    ADD CONSTRAINT "pos_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_images product_images_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT "product_images_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_modifier_groups product_modifier_groups_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_modifier_groups
    ADD CONSTRAINT "product_modifier_groups_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public.modifier_groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_modifier_groups product_modifier_groups_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_modifier_groups
    ADD CONSTRAINT "product_modifier_groups_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_to_images product_to_images_imageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_to_images
    ADD CONSTRAINT "product_to_images_imageId_fkey" FOREIGN KEY ("imageId") REFERENCES public.product_images(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_to_images product_to_images_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_to_images
    ADD CONSTRAINT "product_to_images_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: products products_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "products_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: products products_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "products_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: qr_menu_settings qr_menu_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qr_menu_settings
    ADD CONSTRAINT "qr_menu_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT "stock_movements_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT "stock_movements_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT "stock_movements_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: subscription_payments subscription_payments_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT "subscription_payments_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT "subscriptions_planId_fkey" FOREIGN KEY ("planId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: subscriptions subscriptions_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT "subscriptions_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tables tables_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT "tables_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tenants tenants_currentPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT "tenants_currentPlanId_fkey" FOREIGN KEY ("currentPlanId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_notification_reads user_notification_reads_notificationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_reads
    ADD CONSTRAINT "user_notification_reads_notificationId_fkey" FOREIGN KEY ("notificationId") REFERENCES public.notifications(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_notification_reads user_notification_reads_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_reads
    ADD CONSTRAINT "user_notification_reads_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: waiter_requests waiter_requests_acknowledgedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waiter_requests
    ADD CONSTRAINT "waiter_requests_acknowledgedById_fkey" FOREIGN KEY ("acknowledgedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: waiter_requests waiter_requests_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waiter_requests
    ADD CONSTRAINT "waiter_requests_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict mgkgTwPbu2HnNA6dZyX9u1CpnFQ1G8XdYLY1YepIv8LMObkbFunmmuw2YHOWxtx

