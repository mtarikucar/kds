--
-- PostgreSQL database dump
--

\restrict QT6rDBCHTtqRQLPPEU4HUPYgxeVAedQdtBhQaH5vI473WxLvzdeBTjg91NgI7Ci

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_keys (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    key text NOT NULL,
    "keyPrefix" text NOT NULL,
    scopes text[],
    "webhookUrl" text,
    "webhookEvents" text[] DEFAULT ARRAY[]::text[],
    "isActive" boolean DEFAULT true NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "lastUsedAt" timestamp(3) without time zone,
    "usageCount" integer DEFAULT 0 NOT NULL,
    "ipWhitelist" text[] DEFAULT ARRAY[]::text[],
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.api_keys OWNER TO postgres;

--
-- Name: bill_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bill_requests (
    id text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "sessionId" text NOT NULL,
    "tableId" text NOT NULL,
    "acknowledgedAt" timestamp(3) without time zone,
    "acknowledgedById" text,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.bill_requests OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: contact_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact_messages (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    message text NOT NULL,
    status text DEFAULT 'NEW'::text NOT NULL,
    "adminNotes" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.contact_messages OWNER TO postgres;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id text NOT NULL,
    name text NOT NULL,
    email text,
    phone text,
    "loyaltyPoints" integer DEFAULT 0 NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[],
    notes text,
    "totalOrders" integer DEFAULT 0 NOT NULL,
    "totalSpent" numeric(10,2) DEFAULT 0 NOT NULL,
    "averageOrder" numeric(10,2) DEFAULT 0 NOT NULL,
    birthday timestamp(3) without time zone,
    preferences jsonb,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "lastVisit" timestamp(3) without time zone
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: desktop_releases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.desktop_releases (
    id text NOT NULL,
    version text NOT NULL,
    "releaseTag" text NOT NULL,
    published boolean DEFAULT false NOT NULL,
    "pubDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "windowsUrl" text,
    "windowsSignature" text,
    "macArmUrl" text,
    "macArmSignature" text,
    "macIntelUrl" text,
    "macIntelSignature" text,
    "linuxUrl" text,
    "linuxSignature" text,
    "releaseNotes" text NOT NULL,
    changelog text,
    "downloadCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.desktop_releases OWNER TO postgres;

--
-- Name: integration_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integration_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "integrationType" text NOT NULL,
    provider text NOT NULL,
    name text NOT NULL,
    config jsonb NOT NULL,
    "isEnabled" boolean DEFAULT false NOT NULL,
    "isConfigured" boolean DEFAULT false NOT NULL,
    "lastSyncedAt" timestamp(3) without time zone,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.integration_settings OWNER TO postgres;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    "paymentId" text,
    "invoiceNumber" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    tax numeric(10,2) DEFAULT 0 NOT NULL,
    total numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "periodStart" timestamp(3) without time zone NOT NULL,
    "periodEnd" timestamp(3) without time zone NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "paidAt" timestamp(3) without time zone,
    "voidedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    description text,
    notes text,
    "pdfUrl" text
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: modifier_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.modifier_groups (
    id text NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "selectionType" text DEFAULT 'SINGLE'::text NOT NULL,
    "minSelections" integer DEFAULT 0 NOT NULL,
    "maxSelections" integer,
    "isRequired" boolean DEFAULT false NOT NULL,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.modifier_groups OWNER TO postgres;

--
-- Name: modifiers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.modifiers (
    id text NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "priceAdjustment" numeric(10,2) DEFAULT 0 NOT NULL,
    "isAvailable" boolean DEFAULT true NOT NULL,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "groupId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.modifiers OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    type text NOT NULL,
    data jsonb,
    "userId" text,
    "tenantId" text NOT NULL,
    "isGlobal" boolean DEFAULT false NOT NULL,
    priority text DEFAULT 'NORMAL'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: order_item_modifiers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_item_modifiers (
    id text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    "priceAdjustment" numeric(10,2) NOT NULL,
    "orderItemId" text NOT NULL,
    "modifierId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.order_item_modifiers OWNER TO postgres;

--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id text NOT NULL,
    quantity integer NOT NULL,
    "unitPrice" numeric(10,2) NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    "modifierTotal" numeric(10,2) DEFAULT 0 NOT NULL,
    notes text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "orderId" text NOT NULL,
    "productId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id text NOT NULL,
    "orderNumber" text NOT NULL,
    type text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "totalAmount" numeric(10,2) NOT NULL,
    discount numeric(10,2) DEFAULT 0 NOT NULL,
    "finalAmount" numeric(10,2) NOT NULL,
    notes text,
    "customerName" text,
    "sessionId" text,
    "customerPhone" text,
    "requiresApproval" boolean DEFAULT true NOT NULL,
    "approvedAt" timestamp(3) without time zone,
    "tableId" text,
    "customerId" text,
    "userId" text,
    "approvedById" text,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "paidAt" timestamp(3) without time zone
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id text NOT NULL,
    amount numeric(10,2) NOT NULL,
    method text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "transactionId" text,
    notes text,
    "orderId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "paidAt" timestamp(3) without time zone
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: pending_plan_changes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pending_plan_changes (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    "currentPlanId" text NOT NULL,
    "newPlanId" text NOT NULL,
    "newBillingCycle" text NOT NULL,
    "isUpgrade" boolean NOT NULL,
    "currentAmount" numeric(10,2) NOT NULL,
    "newAmount" numeric(10,2) NOT NULL,
    "prorationAmount" numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "paymentRequired" boolean DEFAULT true NOT NULL,
    "paymentStatus" text DEFAULT 'PENDING'::text NOT NULL,
    "paymentIntentId" text,
    "paymentProvider" text,
    "scheduledFor" timestamp(3) without time zone,
    "appliedAt" timestamp(3) without time zone,
    reason text,
    "failureReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.pending_plan_changes OWNER TO postgres;

--
-- Name: pos_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pos_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "enableTablelessMode" boolean DEFAULT false NOT NULL,
    "enableTwoStepCheckout" boolean DEFAULT false NOT NULL,
    "showProductImages" boolean DEFAULT true NOT NULL,
    "enableCustomerOrdering" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.pos_settings OWNER TO postgres;

--
-- Name: product_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_images (
    id text NOT NULL,
    url text NOT NULL,
    filename text NOT NULL,
    size integer NOT NULL,
    "mimeType" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_images OWNER TO postgres;

--
-- Name: product_modifier_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_modifier_groups (
    id text NOT NULL,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "productId" text NOT NULL,
    "groupId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_modifier_groups OWNER TO postgres;

--
-- Name: product_to_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_to_images (
    id text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "productId" text NOT NULL,
    "imageId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_to_images OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    image text,
    "isAvailable" boolean DEFAULT true NOT NULL,
    "stockTracked" boolean DEFAULT false NOT NULL,
    "currentStock" integer DEFAULT 0 NOT NULL,
    "categoryId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: qr_menu_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qr_menu_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "primaryColor" text DEFAULT '#3B82F6'::text NOT NULL,
    "secondaryColor" text DEFAULT '#1F2937'::text NOT NULL,
    "backgroundColor" text DEFAULT '#F9FAFB'::text NOT NULL,
    "fontFamily" text DEFAULT 'Inter'::text NOT NULL,
    "logoUrl" text,
    "showRestaurantInfo" boolean DEFAULT true NOT NULL,
    "showPrices" boolean DEFAULT true NOT NULL,
    "showDescription" boolean DEFAULT true NOT NULL,
    "showImages" boolean DEFAULT true NOT NULL,
    "layoutStyle" text DEFAULT 'GRID'::text NOT NULL,
    "itemsPerRow" integer DEFAULT 2 NOT NULL,
    "enableTableQR" boolean DEFAULT true NOT NULL,
    "tableQRMessage" text DEFAULT 'Scan to view our menu'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.qr_menu_settings OWNER TO postgres;

--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_movements (
    id text NOT NULL,
    type text NOT NULL,
    quantity integer NOT NULL,
    reason text,
    notes text,
    "productId" text NOT NULL,
    "userId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.stock_movements OWNER TO postgres;

--
-- Name: subscription_payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscription_payments (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "paymentProvider" text NOT NULL,
    "stripePaymentIntentId" text,
    "iyzicoPaymentId" text,
    "paymentMethod" text,
    last4 text,
    "cardBrand" text,
    "failureCode" text,
    "failureMessage" text,
    "retryCount" integer DEFAULT 0 NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "refundedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.subscription_payments OWNER TO postgres;

--
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscription_plans (
    id text NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "monthlyPrice" numeric(10,2) NOT NULL,
    "yearlyPrice" numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "trialDays" integer DEFAULT 0 NOT NULL,
    "maxUsers" integer DEFAULT 1 NOT NULL,
    "maxTables" integer DEFAULT 5 NOT NULL,
    "maxProducts" integer DEFAULT 50 NOT NULL,
    "maxCategories" integer DEFAULT 10 NOT NULL,
    "maxMonthlyOrders" integer DEFAULT 100 NOT NULL,
    "advancedReports" boolean DEFAULT false NOT NULL,
    "multiLocation" boolean DEFAULT false NOT NULL,
    "customBranding" boolean DEFAULT false NOT NULL,
    "apiAccess" boolean DEFAULT false NOT NULL,
    "prioritySupport" boolean DEFAULT false NOT NULL,
    "inventoryTracking" boolean DEFAULT false NOT NULL,
    "kdsIntegration" boolean DEFAULT true NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.subscription_plans OWNER TO postgres;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscriptions (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "planId" text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "billingCycle" text NOT NULL,
    "paymentProvider" text NOT NULL,
    "startDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "currentPeriodStart" timestamp(3) without time zone NOT NULL,
    "currentPeriodEnd" timestamp(3) without time zone NOT NULL,
    "cancelledAt" timestamp(3) without time zone,
    "endedAt" timestamp(3) without time zone,
    "isTrialPeriod" boolean DEFAULT false NOT NULL,
    "trialStart" timestamp(3) without time zone,
    "trialEnd" timestamp(3) without time zone,
    "stripeSubscriptionId" text,
    "iyzicoSubscriptionId" text,
    "stripeCustomerId" text,
    "iyzicoCustomerId" text,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "autoRenew" boolean DEFAULT true NOT NULL,
    "cancelAtPeriodEnd" boolean DEFAULT false NOT NULL,
    "cancellationReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.subscriptions OWNER TO postgres;

--
-- Name: tables; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tables (
    id text NOT NULL,
    number text NOT NULL,
    capacity integer NOT NULL,
    section text,
    status text DEFAULT 'AVAILABLE'::text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.tables OWNER TO postgres;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    id text NOT NULL,
    name text NOT NULL,
    subdomain text,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "currentPlanId" text,
    "paymentRegion" text DEFAULT 'INTERNATIONAL'::text NOT NULL,
    "trialUsed" boolean DEFAULT false NOT NULL,
    "trialStartedAt" timestamp(3) without time zone,
    "trialEndsAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: user_notification_reads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_notification_reads (
    id text NOT NULL,
    "notificationId" text NOT NULL,
    "userId" text NOT NULL,
    "readAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_notification_reads OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    role text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "emailVerificationToken" text,
    "emailVerificationExpires" timestamp(3) without time zone,
    "resetToken" text,
    "resetTokenExpiry" timestamp(3) without time zone,
    avatar text,
    phone text,
    "lastLogin" timestamp(3) without time zone,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: waiter_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.waiter_requests (
    id text NOT NULL,
    message text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "sessionId" text NOT NULL,
    "tableId" text NOT NULL,
    "acknowledgedAt" timestamp(3) without time zone,
    "acknowledgedById" text,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.waiter_requests OWNER TO postgres;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_keys (id, "tenantId", name, key, "keyPrefix", scopes, "webhookUrl", "webhookEvents", "isActive", "expiresAt", "lastUsedAt", "usageCount", "ipWhitelist", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: bill_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bill_requests (id, status, "sessionId", "tableId", "acknowledgedAt", "acknowledgedById", "completedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, description, "displayOrder", "isActive", "tenantId", "createdAt", "updatedAt") FROM stdin;
8518a0bf-b2e3-4fec-9474-7aa065f1f622	deneme		1	t	d602b6af-9353-44d4-a21f-9bff7cce265b	2025-11-05 21:29:32.982	2025-11-05 21:29:32.982
\.


--
-- Data for Name: contact_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact_messages (id, name, email, phone, message, status, "adminNotes", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (id, name, email, phone, "loyaltyPoints", tags, notes, "totalOrders", "totalSpent", "averageOrder", birthday, preferences, "tenantId", "createdAt", "updatedAt", "lastVisit") FROM stdin;
\.


--
-- Data for Name: desktop_releases; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.desktop_releases (id, version, "releaseTag", published, "pubDate", "windowsUrl", "windowsSignature", "macArmUrl", "macArmSignature", "macIntelUrl", "macIntelSignature", "linuxUrl", "linuxSignature", "releaseNotes", changelog, "downloadCount", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: integration_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.integration_settings (id, "tenantId", "integrationType", provider, name, config, "isEnabled", "isConfigured", "lastSyncedAt", notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (id, "subscriptionId", "paymentId", "invoiceNumber", status, subtotal, tax, total, currency, "periodStart", "periodEnd", "dueDate", "paidAt", "voidedAt", "createdAt", "updatedAt", description, notes, "pdfUrl") FROM stdin;
\.


--
-- Data for Name: modifier_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.modifier_groups (id, name, "displayName", description, "selectionType", "minSelections", "maxSelections", "isRequired", "displayOrder", "isActive", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: modifiers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.modifiers (id, name, "displayName", description, "priceAdjustment", "isAvailable", "displayOrder", "groupId", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, title, message, type, data, "userId", "tenantId", "isGlobal", priority, "createdAt", "expiresAt") FROM stdin;
\.


--
-- Data for Name: order_item_modifiers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_item_modifiers (id, quantity, "priceAdjustment", "orderItemId", "modifierId", "createdAt") FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, quantity, "unitPrice", subtotal, "modifierTotal", notes, status, "orderId", "productId", "createdAt", "updatedAt") FROM stdin;
a7ff74b2-d6a5-4d16-94c6-1b36e5978868	2	123.00	246.00	0.00	\N	PENDING	7e4baee6-a7ee-464b-883d-a29fa5fd2bf6	780ef206-c369-42e6-b3ef-c086f1041578	2025-11-05 21:31:09.928	2025-11-05 21:31:09.928
58c079a7-6c05-4901-b859-c53aa27377b8	2	123.00	246.00	0.00	\N	PENDING	933c772d-1061-470d-b10c-e457a78c0f9d	780ef206-c369-42e6-b3ef-c086f1041578	2025-11-05 21:31:30.044	2025-11-05 21:31:30.044
e932d771-f3dc-4a27-b63b-2ce6e8b707ac	3	123.00	369.00	0.00	\N	PENDING	10d0baff-33e5-493e-9766-8797967c0120	780ef206-c369-42e6-b3ef-c086f1041578	2025-11-05 21:31:55.147	2025-11-05 21:31:55.147
1b13c252-4c0d-4bc4-9ddf-5430619b2128	1	123.00	123.00	0.00	\N	PENDING	7cf54838-807e-4551-83cc-18a649f86da1	780ef206-c369-42e6-b3ef-c086f1041578	2025-11-05 22:58:57.256	2025-11-05 22:58:57.256
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, "orderNumber", type, status, "totalAmount", discount, "finalAmount", notes, "customerName", "sessionId", "customerPhone", "requiresApproval", "approvedAt", "tableId", "customerId", "userId", "approvedById", "tenantId", "createdAt", "updatedAt", "paidAt") FROM stdin;
7e4baee6-a7ee-464b-883d-a29fa5fd2bf6	ORD-1762378269924-371	DINE_IN	PAID	246.00	0.00	246.00	\N	\N	\N	\N	t	\N	a8cb840f-e0cd-4e50-9fb4-604878790b76	\N	35916b8f-e36b-43c6-8d2a-c1915e8627a4	\N	d602b6af-9353-44d4-a21f-9bff7cce265b	2025-11-05 21:31:09.928	2025-11-05 21:31:12.761	2025-11-05 21:31:12.759
933c772d-1061-470d-b10c-e457a78c0f9d	ORD-1762378290042-121	DINE_IN	PAID	246.00	0.00	246.00	\N	\N	\N	\N	t	\N	a8cb840f-e0cd-4e50-9fb4-604878790b76	\N	35916b8f-e36b-43c6-8d2a-c1915e8627a4	\N	d602b6af-9353-44d4-a21f-9bff7cce265b	2025-11-05 21:31:30.044	2025-11-05 21:31:31.126	2025-11-05 21:31:31.124
10d0baff-33e5-493e-9766-8797967c0120	ORD-20251105-0122	DINE_IN	PENDING	369.00	0.00	369.00	\N	\N	03140ade-9c17-47cd-8fbc-c41529b33c2c	\N	f	2025-11-05 21:32:06.387	a8cb840f-e0cd-4e50-9fb4-604878790b76	\N	\N	35916b8f-e36b-43c6-8d2a-c1915e8627a4	d602b6af-9353-44d4-a21f-9bff7cce265b	2025-11-05 21:31:55.147	2025-11-05 21:32:06.39	\N
7cf54838-807e-4551-83cc-18a649f86da1	ORD-20251105-0123	DINE_IN	PENDING	123.00	0.00	123.00	\N	\N	03140ade-9c17-47cd-8fbc-c41529b33c2c	\N	f	2025-11-05 22:59:44.157	a8cb840f-e0cd-4e50-9fb4-604878790b76	\N	\N	35916b8f-e36b-43c6-8d2a-c1915e8627a4	d602b6af-9353-44d4-a21f-9bff7cce265b	2025-11-05 22:58:57.256	2025-11-05 22:59:44.159	\N
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, amount, method, status, "transactionId", notes, "orderId", "createdAt", "paidAt") FROM stdin;
109631da-8b00-402e-96f3-2049a40494fc	246.00	CASH	COMPLETED	\N	\N	7e4baee6-a7ee-464b-883d-a29fa5fd2bf6	2025-11-05 21:31:12.73	2025-11-05 21:31:12.727
b5044e35-a625-4148-bb2b-0e396e3d55c1	246.00	CASH	COMPLETED	\N	\N	933c772d-1061-470d-b10c-e457a78c0f9d	2025-11-05 21:31:31.111	2025-11-05 21:31:31.109
\.


--
-- Data for Name: pending_plan_changes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pending_plan_changes (id, "subscriptionId", "currentPlanId", "newPlanId", "newBillingCycle", "isUpgrade", "currentAmount", "newAmount", "prorationAmount", currency, "paymentRequired", "paymentStatus", "paymentIntentId", "paymentProvider", "scheduledFor", "appliedAt", reason, "failureReason", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: pos_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pos_settings (id, "tenantId", "enableTablelessMode", "enableTwoStepCheckout", "showProductImages", "enableCustomerOrdering", "createdAt", "updatedAt") FROM stdin;
276e8318-9861-4a4e-bb7a-e565b86ab47a	d602b6af-9353-44d4-a21f-9bff7cce265b	f	f	t	t	2025-11-05 21:29:05.581	2025-11-05 21:31:23.035
\.


--
-- Data for Name: product_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_images (id, url, filename, size, "mimeType", "tenantId", "createdAt") FROM stdin;
19a72c37-3cd3-4537-b2c2-1acf4048282e	http://localhost:3000/uploads/products/d602b6af-9353-44d4-a21f-9bff7cce265b/caedb4a1-cc34-4e8c-9dbf-7772cf06b69f.png	ChatGPT Image Oct 17, 2025, 12_00_56 AM.png	82149	image/png	d602b6af-9353-44d4-a21f-9bff7cce265b	2025-11-05 21:30:16.813
\.


--
-- Data for Name: product_modifier_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_modifier_groups (id, "displayOrder", "productId", "groupId", "createdAt") FROM stdin;
\.


--
-- Data for Name: product_to_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_to_images (id, "order", "productId", "imageId", "createdAt") FROM stdin;
ef6cf4c4-e50d-4765-bcfd-5433cf801828	0	780ef206-c369-42e6-b3ef-c086f1041578	19a72c37-3cd3-4537-b2c2-1acf4048282e	2025-11-05 21:30:51.396
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, name, description, price, image, "isAvailable", "stockTracked", "currentStock", "categoryId", "tenantId", "createdAt", "updatedAt") FROM stdin;
780ef206-c369-42e6-b3ef-c086f1041578	denem	den	123.00	\N	t	f	2	8518a0bf-b2e3-4fec-9474-7aa065f1f622	d602b6af-9353-44d4-a21f-9bff7cce265b	2025-11-05 21:30:51.369	2025-11-05 21:30:51.369
\.


--
-- Data for Name: qr_menu_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qr_menu_settings (id, "tenantId", "primaryColor", "secondaryColor", "backgroundColor", "fontFamily", "logoUrl", "showRestaurantInfo", "showPrices", "showDescription", "showImages", "layoutStyle", "itemsPerRow", "enableTableQR", "tableQRMessage", "createdAt", "updatedAt") FROM stdin;
484d68d0-c93c-4cba-92ea-6f689a8268d4	d602b6af-9353-44d4-a21f-9bff7cce265b	#3B82F6	#1F2937	#F9FAFB	Inter	\N	t	t	t	t	GRID	2	t	Scan to view our menu	2025-11-05 21:31:36.323	2025-11-05 21:31:36.323
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_movements (id, type, quantity, reason, notes, "productId", "userId", "tenantId", "createdAt") FROM stdin;
\.


--
-- Data for Name: subscription_payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscription_payments (id, "subscriptionId", amount, currency, status, "paymentProvider", "stripePaymentIntentId", "iyzicoPaymentId", "paymentMethod", last4, "cardBrand", "failureCode", "failureMessage", "retryCount", "paidAt", "refundedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscription_plans (id, name, "displayName", description, "monthlyPrice", "yearlyPrice", currency, "trialDays", "maxUsers", "maxTables", "maxProducts", "maxCategories", "maxMonthlyOrders", "advancedReports", "multiLocation", "customBranding", "apiAccess", "prioritySupport", "inventoryTracking", "kdsIntegration", "isActive", "createdAt", "updatedAt") FROM stdin;
33e57687-c2c3-4f3a-99ba-38bc28e0b05f	FREE	Free Plan	Perfect for small restaurants getting started	0.00	0.00	USD	0	2	5	25	5	50	f	f	f	f	f	f	t	t	2025-11-05 21:28:35.891	2025-11-05 21:28:35.891
9a5fdbcc-14a4-4b9b-93f2-be5c900ea0e4	BASIC	Basic Plan	Great for growing restaurants	29.99	299.99	USD	14	5	20	100	20	500	f	f	f	f	f	t	t	t	2025-11-05 21:29:14.037	2025-11-05 21:29:14.037
1c3a9da2-abbe-4d87-bcf3-f56d5a0e8e23	PRO	Pro Plan	For established restaurants	79.99	799.99	USD	14	15	50	500	50	2000	t	t	t	f	t	t	t	t	2025-11-05 21:29:14.17	2025-11-05 21:29:14.17
c1760e6e-ec59-4250-994e-55641fdd227c	BUSINESS	Business Plan	Enterprise solution	199.99	1999.99	USD	14	-1	-1	-1	-1	-1	t	t	t	t	t	t	t	t	2025-11-05 21:29:14.295	2025-11-05 21:29:14.295
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscriptions (id, "tenantId", "planId", status, "billingCycle", "paymentProvider", "startDate", "currentPeriodStart", "currentPeriodEnd", "cancelledAt", "endedAt", "isTrialPeriod", "trialStart", "trialEnd", "stripeSubscriptionId", "iyzicoSubscriptionId", "stripeCustomerId", "iyzicoCustomerId", amount, currency, "autoRenew", "cancelAtPeriodEnd", "cancellationReason", "createdAt", "updatedAt") FROM stdin;
b1406261-018e-4e93-9680-a058dd77518e	d602b6af-9353-44d4-a21f-9bff7cce265b	33e57687-c2c3-4f3a-99ba-38bc28e0b05f	ACTIVE	MONTHLY	STRIPE	2025-11-05 21:28:59.993	2025-11-05 21:28:59.993	2035-11-05 21:28:59.993	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	USD	t	f	\N	2025-11-05 21:28:59.996	2025-11-05 21:28:59.996
\.


--
-- Data for Name: tables; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tables (id, number, capacity, section, status, "tenantId", "createdAt", "updatedAt") FROM stdin;
a8cb840f-e0cd-4e50-9fb4-604878790b76	1	4	\N	AVAILABLE	d602b6af-9353-44d4-a21f-9bff7cce265b	2025-11-05 21:31:03.393	2025-11-05 21:31:31.236
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (id, name, subdomain, status, "currentPlanId", "paymentRegion", "trialUsed", "trialStartedAt", "trialEndsAt", "createdAt", "updatedAt") FROM stdin;
d602b6af-9353-44d4-a21f-9bff7cce265b	admin	admin	ACTIVE	33e57687-c2c3-4f3a-99ba-38bc28e0b05f	INTERNATIONAL	f	\N	\N	2025-11-05 21:28:59.986	2025-11-05 21:28:59.986
\.


--
-- Data for Name: user_notification_reads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_notification_reads (id, "notificationId", "userId", "readAt") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password, "firstName", "lastName", role, status, "emailVerified", "emailVerificationToken", "emailVerificationExpires", "resetToken", "resetTokenExpiry", avatar, phone, "lastLogin", "tenantId", "createdAt", "updatedAt") FROM stdin;
35916b8f-e36b-43c6-8d2a-c1915e8627a4	admin@gmail.com	$2a$10$n61qbp0jLOWCh1sB0x8preR8lBdBpTP4YMCRkD65HozwRN6/LUcuG	admin	admin	ADMIN	ACTIVE	f	\N	\N	\N	\N	\N	\N	\N	d602b6af-9353-44d4-a21f-9bff7cce265b	2025-11-05 21:29:00.19	2025-11-05 21:29:00.19
\.


--
-- Data for Name: waiter_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.waiter_requests (id, message, status, "sessionId", "tableId", "acknowledgedAt", "acknowledgedById", "completedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: bill_requests bill_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_requests
    ADD CONSTRAINT bill_requests_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: contact_messages contact_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_messages
    ADD CONSTRAINT contact_messages_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: desktop_releases desktop_releases_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.desktop_releases
    ADD CONSTRAINT desktop_releases_pkey PRIMARY KEY (id);


--
-- Name: integration_settings integration_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_settings
    ADD CONSTRAINT integration_settings_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: modifier_groups modifier_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifier_groups
    ADD CONSTRAINT modifier_groups_pkey PRIMARY KEY (id);


--
-- Name: modifiers modifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifiers
    ADD CONSTRAINT modifiers_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: order_item_modifiers order_item_modifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item_modifiers
    ADD CONSTRAINT order_item_modifiers_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: pending_plan_changes pending_plan_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_plan_changes
    ADD CONSTRAINT pending_plan_changes_pkey PRIMARY KEY (id);


--
-- Name: pos_settings pos_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pos_settings
    ADD CONSTRAINT pos_settings_pkey PRIMARY KEY (id);


--
-- Name: product_images product_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_pkey PRIMARY KEY (id);


--
-- Name: product_modifier_groups product_modifier_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_modifier_groups
    ADD CONSTRAINT product_modifier_groups_pkey PRIMARY KEY (id);


--
-- Name: product_to_images product_to_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_to_images
    ADD CONSTRAINT product_to_images_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: qr_menu_settings qr_menu_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qr_menu_settings
    ADD CONSTRAINT qr_menu_settings_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: subscription_payments subscription_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT subscription_payments_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: tables tables_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT tables_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: user_notification_reads user_notification_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_reads
    ADD CONSTRAINT user_notification_reads_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: waiter_requests waiter_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waiter_requests
    ADD CONSTRAINT waiter_requests_pkey PRIMARY KEY (id);


--
-- Name: api_keys_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "api_keys_isActive_idx" ON public.api_keys USING btree ("isActive");


--
-- Name: api_keys_key_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_keys_key_idx ON public.api_keys USING btree (key);


--
-- Name: api_keys_key_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX api_keys_key_key ON public.api_keys USING btree (key);


--
-- Name: api_keys_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "api_keys_tenantId_idx" ON public.api_keys USING btree ("tenantId");


--
-- Name: bill_requests_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "bill_requests_sessionId_idx" ON public.bill_requests USING btree ("sessionId");


--
-- Name: bill_requests_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bill_requests_status_idx ON public.bill_requests USING btree (status);


--
-- Name: bill_requests_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "bill_requests_tableId_idx" ON public.bill_requests USING btree ("tableId");


--
-- Name: categories_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "categories_tenantId_idx" ON public.categories USING btree ("tenantId");


--
-- Name: contact_messages_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "contact_messages_createdAt_idx" ON public.contact_messages USING btree ("createdAt");


--
-- Name: contact_messages_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX contact_messages_status_idx ON public.contact_messages USING btree (status);


--
-- Name: customers_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customers_email_idx ON public.customers USING btree (email);


--
-- Name: customers_phone_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customers_phone_idx ON public.customers USING btree (phone);


--
-- Name: customers_tenantId_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customers_tenantId_email_key" ON public.customers USING btree ("tenantId", email);


--
-- Name: customers_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customers_tenantId_idx" ON public.customers USING btree ("tenantId");


--
-- Name: customers_tenantId_phone_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customers_tenantId_phone_key" ON public.customers USING btree ("tenantId", phone);


--
-- Name: desktop_releases_published_pubDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "desktop_releases_published_pubDate_idx" ON public.desktop_releases USING btree (published, "pubDate");


--
-- Name: desktop_releases_releaseTag_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "desktop_releases_releaseTag_key" ON public.desktop_releases USING btree ("releaseTag");


--
-- Name: desktop_releases_version_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX desktop_releases_version_idx ON public.desktop_releases USING btree (version);


--
-- Name: desktop_releases_version_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX desktop_releases_version_key ON public.desktop_releases USING btree (version);


--
-- Name: integration_settings_integrationType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "integration_settings_integrationType_idx" ON public.integration_settings USING btree ("integrationType");


--
-- Name: integration_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "integration_settings_tenantId_idx" ON public.integration_settings USING btree ("tenantId");


--
-- Name: integration_settings_tenantId_integrationType_provider_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "integration_settings_tenantId_integrationType_provider_key" ON public.integration_settings USING btree ("tenantId", "integrationType", provider);


--
-- Name: invoices_dueDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_dueDate_idx" ON public.invoices USING btree ("dueDate");


--
-- Name: invoices_invoiceNumber_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_invoiceNumber_idx" ON public.invoices USING btree ("invoiceNumber");


--
-- Name: invoices_invoiceNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "invoices_invoiceNumber_key" ON public.invoices USING btree ("invoiceNumber");


--
-- Name: invoices_paymentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "invoices_paymentId_key" ON public.invoices USING btree ("paymentId");


--
-- Name: invoices_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX invoices_status_idx ON public.invoices USING btree (status);


--
-- Name: invoices_subscriptionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_subscriptionId_idx" ON public.invoices USING btree ("subscriptionId");


--
-- Name: modifier_groups_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifier_groups_isActive_idx" ON public.modifier_groups USING btree ("isActive");


--
-- Name: modifier_groups_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifier_groups_tenantId_idx" ON public.modifier_groups USING btree ("tenantId");


--
-- Name: modifiers_groupId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifiers_groupId_idx" ON public.modifiers USING btree ("groupId");


--
-- Name: modifiers_isAvailable_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifiers_isAvailable_idx" ON public.modifiers USING btree ("isAvailable");


--
-- Name: modifiers_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifiers_tenantId_idx" ON public.modifiers USING btree ("tenantId");


--
-- Name: notifications_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "notifications_createdAt_idx" ON public.notifications USING btree ("createdAt");


--
-- Name: notifications_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "notifications_tenantId_idx" ON public.notifications USING btree ("tenantId");


--
-- Name: notifications_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "notifications_userId_idx" ON public.notifications USING btree ("userId");


--
-- Name: order_item_modifiers_modifierId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_item_modifiers_modifierId_idx" ON public.order_item_modifiers USING btree ("modifierId");


--
-- Name: order_item_modifiers_orderItemId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_item_modifiers_orderItemId_idx" ON public.order_item_modifiers USING btree ("orderItemId");


--
-- Name: order_items_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_items_orderId_idx" ON public.order_items USING btree ("orderId");


--
-- Name: order_items_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_items_productId_idx" ON public.order_items USING btree ("productId");


--
-- Name: orders_approvedById_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_approvedById_idx" ON public.orders USING btree ("approvedById");


--
-- Name: orders_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_customerId_idx" ON public.orders USING btree ("customerId");


--
-- Name: orders_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_sessionId_idx" ON public.orders USING btree ("sessionId");


--
-- Name: orders_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orders_status_idx ON public.orders USING btree (status);


--
-- Name: orders_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_tableId_idx" ON public.orders USING btree ("tableId");


--
-- Name: orders_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_tenantId_idx" ON public.orders USING btree ("tenantId");


--
-- Name: orders_tenantId_orderNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "orders_tenantId_orderNumber_key" ON public.orders USING btree ("tenantId", "orderNumber");


--
-- Name: orders_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_userId_idx" ON public.orders USING btree ("userId");


--
-- Name: payments_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "payments_orderId_idx" ON public.payments USING btree ("orderId");


--
-- Name: payments_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payments_status_idx ON public.payments USING btree (status);


--
-- Name: pending_plan_changes_paymentStatus_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pending_plan_changes_paymentStatus_idx" ON public.pending_plan_changes USING btree ("paymentStatus");


--
-- Name: pending_plan_changes_scheduledFor_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pending_plan_changes_scheduledFor_idx" ON public.pending_plan_changes USING btree ("scheduledFor");


--
-- Name: pending_plan_changes_subscriptionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pending_plan_changes_subscriptionId_idx" ON public.pending_plan_changes USING btree ("subscriptionId");


--
-- Name: pos_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pos_settings_tenantId_idx" ON public.pos_settings USING btree ("tenantId");


--
-- Name: pos_settings_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "pos_settings_tenantId_key" ON public.pos_settings USING btree ("tenantId");


--
-- Name: product_images_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_images_tenantId_idx" ON public.product_images USING btree ("tenantId");


--
-- Name: product_modifier_groups_groupId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_modifier_groups_groupId_idx" ON public.product_modifier_groups USING btree ("groupId");


--
-- Name: product_modifier_groups_productId_groupId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "product_modifier_groups_productId_groupId_key" ON public.product_modifier_groups USING btree ("productId", "groupId");


--
-- Name: product_modifier_groups_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_modifier_groups_productId_idx" ON public.product_modifier_groups USING btree ("productId");


--
-- Name: product_to_images_imageId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_to_images_imageId_idx" ON public.product_to_images USING btree ("imageId");


--
-- Name: product_to_images_productId_imageId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "product_to_images_productId_imageId_key" ON public.product_to_images USING btree ("productId", "imageId");


--
-- Name: product_to_images_productId_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_to_images_productId_order_idx" ON public.product_to_images USING btree ("productId", "order");


--
-- Name: products_categoryId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "products_categoryId_idx" ON public.products USING btree ("categoryId");


--
-- Name: products_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "products_tenantId_idx" ON public.products USING btree ("tenantId");


--
-- Name: qr_menu_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "qr_menu_settings_tenantId_idx" ON public.qr_menu_settings USING btree ("tenantId");


--
-- Name: qr_menu_settings_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "qr_menu_settings_tenantId_key" ON public.qr_menu_settings USING btree ("tenantId");


--
-- Name: stock_movements_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_movements_productId_idx" ON public.stock_movements USING btree ("productId");


--
-- Name: stock_movements_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_movements_tenantId_idx" ON public.stock_movements USING btree ("tenantId");


--
-- Name: stock_movements_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_movements_userId_idx" ON public.stock_movements USING btree ("userId");


--
-- Name: subscription_payments_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscription_payments_createdAt_idx" ON public.subscription_payments USING btree ("createdAt");


--
-- Name: subscription_payments_iyzicoPaymentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscription_payments_iyzicoPaymentId_key" ON public.subscription_payments USING btree ("iyzicoPaymentId");


--
-- Name: subscription_payments_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX subscription_payments_status_idx ON public.subscription_payments USING btree (status);


--
-- Name: subscription_payments_stripePaymentIntentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscription_payments_stripePaymentIntentId_key" ON public.subscription_payments USING btree ("stripePaymentIntentId");


--
-- Name: subscription_payments_subscriptionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscription_payments_subscriptionId_idx" ON public.subscription_payments USING btree ("subscriptionId");


--
-- Name: subscription_plans_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX subscription_plans_name_key ON public.subscription_plans USING btree (name);


--
-- Name: subscriptions_currentPeriodEnd_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscriptions_currentPeriodEnd_idx" ON public.subscriptions USING btree ("currentPeriodEnd");


--
-- Name: subscriptions_iyzicoSubscriptionId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscriptions_iyzicoSubscriptionId_key" ON public.subscriptions USING btree ("iyzicoSubscriptionId");


--
-- Name: subscriptions_planId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscriptions_planId_idx" ON public.subscriptions USING btree ("planId");


--
-- Name: subscriptions_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX subscriptions_status_idx ON public.subscriptions USING btree (status);


--
-- Name: subscriptions_stripeSubscriptionId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscriptions_stripeSubscriptionId_key" ON public.subscriptions USING btree ("stripeSubscriptionId");


--
-- Name: subscriptions_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscriptions_tenantId_idx" ON public.subscriptions USING btree ("tenantId");


--
-- Name: tables_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "tables_tenantId_idx" ON public.tables USING btree ("tenantId");


--
-- Name: tables_tenantId_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "tables_tenantId_number_key" ON public.tables USING btree ("tenantId", number);


--
-- Name: tenants_currentPlanId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "tenants_currentPlanId_idx" ON public.tenants USING btree ("currentPlanId");


--
-- Name: tenants_subdomain_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX tenants_subdomain_key ON public.tenants USING btree (subdomain);


--
-- Name: user_notification_reads_notificationId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_notification_reads_notificationId_idx" ON public.user_notification_reads USING btree ("notificationId");


--
-- Name: user_notification_reads_notificationId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "user_notification_reads_notificationId_userId_key" ON public.user_notification_reads USING btree ("notificationId", "userId");


--
-- Name: user_notification_reads_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_notification_reads_userId_idx" ON public.user_notification_reads USING btree ("userId");


--
-- Name: users_emailVerificationToken_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "users_emailVerificationToken_key" ON public.users USING btree ("emailVerificationToken");


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_resetToken_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "users_resetToken_key" ON public.users USING btree ("resetToken");


--
-- Name: users_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "users_tenantId_idx" ON public.users USING btree ("tenantId");


--
-- Name: waiter_requests_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "waiter_requests_sessionId_idx" ON public.waiter_requests USING btree ("sessionId");


--
-- Name: waiter_requests_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX waiter_requests_status_idx ON public.waiter_requests USING btree (status);


--
-- Name: waiter_requests_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "waiter_requests_tableId_idx" ON public.waiter_requests USING btree ("tableId");


--
-- Name: api_keys api_keys_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT "api_keys_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bill_requests bill_requests_acknowledgedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_requests
    ADD CONSTRAINT "bill_requests_acknowledgedById_fkey" FOREIGN KEY ("acknowledgedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bill_requests bill_requests_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_requests
    ADD CONSTRAINT "bill_requests_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: categories categories_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "categories_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customers customers_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT "customers_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: integration_settings integration_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_settings
    ADD CONSTRAINT "integration_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoices invoices_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public.subscription_payments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: modifier_groups modifier_groups_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifier_groups
    ADD CONSTRAINT "modifier_groups_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: modifiers modifiers_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifiers
    ADD CONSTRAINT "modifiers_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public.modifier_groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: modifiers modifiers_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifiers
    ADD CONSTRAINT "modifiers_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_item_modifiers order_item_modifiers_modifierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item_modifiers
    ADD CONSTRAINT "order_item_modifiers_modifierId_fkey" FOREIGN KEY ("modifierId") REFERENCES public.modifiers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: order_item_modifiers order_item_modifiers_orderItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item_modifiers
    ADD CONSTRAINT "order_item_modifiers_orderItemId_fkey" FOREIGN KEY ("orderItemId") REFERENCES public.order_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_items order_items_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "order_items_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_items order_items_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "order_items_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: orders orders_approvedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_approvedById_fkey" FOREIGN KEY ("approvedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orders orders_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payments payments_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pending_plan_changes pending_plan_changes_currentPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_plan_changes
    ADD CONSTRAINT "pending_plan_changes_currentPlanId_fkey" FOREIGN KEY ("currentPlanId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pending_plan_changes pending_plan_changes_newPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_plan_changes
    ADD CONSTRAINT "pending_plan_changes_newPlanId_fkey" FOREIGN KEY ("newPlanId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pending_plan_changes pending_plan_changes_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_plan_changes
    ADD CONSTRAINT "pending_plan_changes_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pos_settings pos_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pos_settings
    ADD CONSTRAINT "pos_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_images product_images_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT "product_images_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_modifier_groups product_modifier_groups_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_modifier_groups
    ADD CONSTRAINT "product_modifier_groups_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public.modifier_groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_modifier_groups product_modifier_groups_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_modifier_groups
    ADD CONSTRAINT "product_modifier_groups_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_to_images product_to_images_imageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_to_images
    ADD CONSTRAINT "product_to_images_imageId_fkey" FOREIGN KEY ("imageId") REFERENCES public.product_images(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_to_images product_to_images_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_to_images
    ADD CONSTRAINT "product_to_images_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: products products_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "products_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: products products_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "products_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: qr_menu_settings qr_menu_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qr_menu_settings
    ADD CONSTRAINT "qr_menu_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT "stock_movements_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT "stock_movements_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT "stock_movements_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: subscription_payments subscription_payments_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT "subscription_payments_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT "subscriptions_planId_fkey" FOREIGN KEY ("planId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: subscriptions subscriptions_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT "subscriptions_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tables tables_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT "tables_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tenants tenants_currentPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT "tenants_currentPlanId_fkey" FOREIGN KEY ("currentPlanId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_notification_reads user_notification_reads_notificationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_reads
    ADD CONSTRAINT "user_notification_reads_notificationId_fkey" FOREIGN KEY ("notificationId") REFERENCES public.notifications(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_notification_reads user_notification_reads_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_reads
    ADD CONSTRAINT "user_notification_reads_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: waiter_requests waiter_requests_acknowledgedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waiter_requests
    ADD CONSTRAINT "waiter_requests_acknowledgedById_fkey" FOREIGN KEY ("acknowledgedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: waiter_requests waiter_requests_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waiter_requests
    ADD CONSTRAINT "waiter_requests_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict QT6rDBCHTtqRQLPPEU4HUPYgxeVAedQdtBhQaH5vI473WxLvzdeBTjg91NgI7Ci

