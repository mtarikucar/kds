--
-- PostgreSQL database dump
--

\restrict tWeeains9JSTOIRyvPlEOqMf3pn5Njq4vZjC5IocZ3u7WJgDjJad95Jui5ofPPA

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_keys (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    key text NOT NULL,
    "keyPrefix" text NOT NULL,
    scopes text[],
    "webhookUrl" text,
    "webhookEvents" text[] DEFAULT ARRAY[]::text[],
    "isActive" boolean DEFAULT true NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "lastUsedAt" timestamp(3) without time zone,
    "usageCount" integer DEFAULT 0 NOT NULL,
    "ipWhitelist" text[] DEFAULT ARRAY[]::text[],
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.api_keys OWNER TO postgres;

--
-- Name: bill_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bill_requests (
    id text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "sessionId" text NOT NULL,
    "tableId" text NOT NULL,
    "acknowledgedAt" timestamp(3) without time zone,
    "acknowledgedById" text,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.bill_requests OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: contact_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact_messages (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    message text NOT NULL,
    status text DEFAULT 'NEW'::text NOT NULL,
    "adminNotes" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.contact_messages OWNER TO postgres;

--
-- Name: customer_referrals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_referrals (
    id text NOT NULL,
    "referrerId" text NOT NULL,
    "referredId" text NOT NULL,
    "referralCode" text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "referrerReward" integer DEFAULT 0 NOT NULL,
    "referredReward" integer DEFAULT 0 NOT NULL,
    "rewardedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone
);


ALTER TABLE public.customer_referrals OWNER TO postgres;

--
-- Name: customer_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_sessions (
    id text NOT NULL,
    "sessionId" text NOT NULL,
    "customerId" text,
    "tableId" text,
    phone text,
    "isActive" boolean DEFAULT true NOT NULL,
    "userAgent" text,
    "ipAddress" text,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "lastActivity" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.customer_sessions OWNER TO postgres;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id text NOT NULL,
    name text NOT NULL,
    email text,
    phone text,
    "phoneVerified" boolean DEFAULT false NOT NULL,
    "loyaltyPoints" integer DEFAULT 0 NOT NULL,
    "loyaltyTier" text DEFAULT 'BRONZE'::text NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[],
    notes text,
    "referralCode" text,
    "referredBy" text,
    "totalOrders" integer DEFAULT 0 NOT NULL,
    "totalSpent" numeric(10,2) DEFAULT 0 NOT NULL,
    "averageOrder" numeric(10,2) DEFAULT 0 NOT NULL,
    birthday timestamp(3) without time zone,
    preferences jsonb,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "lastVisit" timestamp(3) without time zone
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: desktop_releases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.desktop_releases (
    id text NOT NULL,
    version text NOT NULL,
    "releaseTag" text NOT NULL,
    published boolean DEFAULT false NOT NULL,
    "pubDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "windowsUrl" text,
    "windowsSignature" text,
    "macArmUrl" text,
    "macArmSignature" text,
    "macIntelUrl" text,
    "macIntelSignature" text,
    "linuxUrl" text,
    "linuxSignature" text,
    "releaseNotes" text NOT NULL,
    changelog text,
    "downloadCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.desktop_releases OWNER TO postgres;

--
-- Name: integration_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integration_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "integrationType" text NOT NULL,
    provider text NOT NULL,
    name text NOT NULL,
    config jsonb NOT NULL,
    "isEnabled" boolean DEFAULT false NOT NULL,
    "isConfigured" boolean DEFAULT false NOT NULL,
    "lastSyncedAt" timestamp(3) without time zone,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.integration_settings OWNER TO postgres;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    "paymentId" text,
    "invoiceNumber" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    tax numeric(10,2) DEFAULT 0 NOT NULL,
    total numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "periodStart" timestamp(3) without time zone NOT NULL,
    "periodEnd" timestamp(3) without time zone NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "paidAt" timestamp(3) without time zone,
    "voidedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    description text,
    notes text,
    "pdfUrl" text
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: loyalty_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.loyalty_transactions (
    id text NOT NULL,
    "customerId" text NOT NULL,
    type text NOT NULL,
    points integer NOT NULL,
    description text NOT NULL,
    "orderId" text,
    "orderNumber" text,
    "orderAmount" numeric(10,2),
    "referredCustomerId" text,
    "balanceBefore" integer NOT NULL,
    "balanceAfter" integer NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.loyalty_transactions OWNER TO postgres;

--
-- Name: modifier_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.modifier_groups (
    id text NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "selectionType" text DEFAULT 'SINGLE'::text NOT NULL,
    "minSelections" integer DEFAULT 0 NOT NULL,
    "maxSelections" integer,
    "isRequired" boolean DEFAULT false NOT NULL,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.modifier_groups OWNER TO postgres;

--
-- Name: modifiers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.modifiers (
    id text NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "priceAdjustment" numeric(10,2) DEFAULT 0 NOT NULL,
    "isAvailable" boolean DEFAULT true NOT NULL,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "groupId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.modifiers OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    type text NOT NULL,
    data jsonb,
    "userId" text,
    "tenantId" text NOT NULL,
    "isGlobal" boolean DEFAULT false NOT NULL,
    priority text DEFAULT 'NORMAL'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: order_item_modifiers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_item_modifiers (
    id text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    "priceAdjustment" numeric(10,2) NOT NULL,
    "orderItemId" text NOT NULL,
    "modifierId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.order_item_modifiers OWNER TO postgres;

--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id text NOT NULL,
    quantity integer NOT NULL,
    "unitPrice" numeric(10,2) NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    "modifierTotal" numeric(10,2) DEFAULT 0 NOT NULL,
    notes text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "orderId" text NOT NULL,
    "productId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id text NOT NULL,
    "orderNumber" text NOT NULL,
    type text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "totalAmount" numeric(10,2) NOT NULL,
    discount numeric(10,2) DEFAULT 0 NOT NULL,
    "finalAmount" numeric(10,2) NOT NULL,
    notes text,
    "customerName" text,
    "sessionId" text,
    "customerPhone" text,
    "requiresApproval" boolean DEFAULT false NOT NULL,
    "approvedAt" timestamp(3) without time zone,
    "tableId" text,
    "customerId" text,
    "userId" text,
    "approvedById" text,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "paidAt" timestamp(3) without time zone
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id text NOT NULL,
    amount numeric(10,2) NOT NULL,
    method text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "transactionId" text,
    notes text,
    "orderId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "paidAt" timestamp(3) without time zone
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: pending_plan_changes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pending_plan_changes (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    "currentPlanId" text NOT NULL,
    "newPlanId" text NOT NULL,
    "newBillingCycle" text NOT NULL,
    "isUpgrade" boolean NOT NULL,
    "currentAmount" numeric(10,2) NOT NULL,
    "newAmount" numeric(10,2) NOT NULL,
    "prorationAmount" numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "paymentRequired" boolean DEFAULT true NOT NULL,
    "paymentStatus" text DEFAULT 'PENDING'::text NOT NULL,
    "paymentIntentId" text,
    "paymentProvider" text,
    "scheduledFor" timestamp(3) without time zone,
    "appliedAt" timestamp(3) without time zone,
    reason text,
    "failureReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.pending_plan_changes OWNER TO postgres;

--
-- Name: phone_verifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.phone_verifications (
    id text NOT NULL,
    phone text NOT NULL,
    code text NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "sessionId" text,
    "tenantId" text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    "maxAttempts" integer DEFAULT 3 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "verifiedAt" timestamp(3) without time zone
);


ALTER TABLE public.phone_verifications OWNER TO postgres;

--
-- Name: pos_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pos_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "enableTablelessMode" boolean DEFAULT false NOT NULL,
    "enableTwoStepCheckout" boolean DEFAULT false NOT NULL,
    "showProductImages" boolean DEFAULT true NOT NULL,
    "enableCustomerOrdering" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.pos_settings OWNER TO postgres;

--
-- Name: product_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_images (
    id text NOT NULL,
    url text NOT NULL,
    filename text NOT NULL,
    size integer NOT NULL,
    "mimeType" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_images OWNER TO postgres;

--
-- Name: product_modifier_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_modifier_groups (
    id text NOT NULL,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "productId" text NOT NULL,
    "groupId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_modifier_groups OWNER TO postgres;

--
-- Name: product_to_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_to_images (
    id text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "productId" text NOT NULL,
    "imageId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_to_images OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    image text,
    "isAvailable" boolean DEFAULT true NOT NULL,
    "stockTracked" boolean DEFAULT false NOT NULL,
    "currentStock" integer DEFAULT 0 NOT NULL,
    "categoryId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: qr_menu_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qr_menu_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "primaryColor" text DEFAULT '#3B82F6'::text NOT NULL,
    "secondaryColor" text DEFAULT '#1F2937'::text NOT NULL,
    "backgroundColor" text DEFAULT '#F9FAFB'::text NOT NULL,
    "fontFamily" text DEFAULT 'Inter'::text NOT NULL,
    "logoUrl" text,
    "showRestaurantInfo" boolean DEFAULT true NOT NULL,
    "showPrices" boolean DEFAULT true NOT NULL,
    "showDescription" boolean DEFAULT true NOT NULL,
    "showImages" boolean DEFAULT true NOT NULL,
    "layoutStyle" text DEFAULT 'GRID'::text NOT NULL,
    "itemsPerRow" integer DEFAULT 2 NOT NULL,
    "enableTableQR" boolean DEFAULT true NOT NULL,
    "tableQRMessage" text DEFAULT 'Scan to view our menu'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.qr_menu_settings OWNER TO postgres;

--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_movements (
    id text NOT NULL,
    type text NOT NULL,
    quantity integer NOT NULL,
    reason text,
    notes text,
    "productId" text NOT NULL,
    "userId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.stock_movements OWNER TO postgres;

--
-- Name: subscription_payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscription_payments (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "paymentProvider" text NOT NULL,
    "stripePaymentIntentId" text,
    "iyzicoPaymentId" text,
    "paymentMethod" text,
    last4 text,
    "cardBrand" text,
    "failureCode" text,
    "failureMessage" text,
    "retryCount" integer DEFAULT 0 NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "refundedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.subscription_payments OWNER TO postgres;

--
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscription_plans (
    id text NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "monthlyPrice" numeric(10,2) NOT NULL,
    "yearlyPrice" numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "trialDays" integer DEFAULT 0 NOT NULL,
    "maxUsers" integer DEFAULT 1 NOT NULL,
    "maxTables" integer DEFAULT 5 NOT NULL,
    "maxProducts" integer DEFAULT 50 NOT NULL,
    "maxCategories" integer DEFAULT 10 NOT NULL,
    "maxMonthlyOrders" integer DEFAULT 100 NOT NULL,
    "advancedReports" boolean DEFAULT false NOT NULL,
    "multiLocation" boolean DEFAULT false NOT NULL,
    "customBranding" boolean DEFAULT false NOT NULL,
    "apiAccess" boolean DEFAULT false NOT NULL,
    "prioritySupport" boolean DEFAULT false NOT NULL,
    "inventoryTracking" boolean DEFAULT false NOT NULL,
    "kdsIntegration" boolean DEFAULT true NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.subscription_plans OWNER TO postgres;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscriptions (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "planId" text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "billingCycle" text NOT NULL,
    "paymentProvider" text NOT NULL,
    "startDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "currentPeriodStart" timestamp(3) without time zone NOT NULL,
    "currentPeriodEnd" timestamp(3) without time zone NOT NULL,
    "cancelledAt" timestamp(3) without time zone,
    "endedAt" timestamp(3) without time zone,
    "isTrialPeriod" boolean DEFAULT false NOT NULL,
    "trialStart" timestamp(3) without time zone,
    "trialEnd" timestamp(3) without time zone,
    "stripeSubscriptionId" text,
    "iyzicoSubscriptionId" text,
    "stripeCustomerId" text,
    "iyzicoCustomerId" text,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "autoRenew" boolean DEFAULT true NOT NULL,
    "cancelAtPeriodEnd" boolean DEFAULT false NOT NULL,
    "cancellationReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.subscriptions OWNER TO postgres;

--
-- Name: tables; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tables (
    id text NOT NULL,
    number text NOT NULL,
    capacity integer NOT NULL,
    section text,
    status text DEFAULT 'AVAILABLE'::text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.tables OWNER TO postgres;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    id text NOT NULL,
    name text NOT NULL,
    subdomain text,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "currentPlanId" text,
    "paymentRegion" text DEFAULT 'INTERNATIONAL'::text NOT NULL,
    "trialUsed" boolean DEFAULT false NOT NULL,
    "trialStartedAt" timestamp(3) without time zone,
    "trialEndsAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: user_notification_reads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_notification_reads (
    id text NOT NULL,
    "notificationId" text NOT NULL,
    "userId" text NOT NULL,
    "readAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_notification_reads OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    role text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "emailVerificationCode" character varying(6),
    "emailVerificationCodeExpires" timestamp(3) without time zone,
    "resetToken" text,
    "resetTokenExpiry" timestamp(3) without time zone,
    avatar text,
    phone text,
    "lastLogin" timestamp(3) without time zone,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: waiter_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.waiter_requests (
    id text NOT NULL,
    message text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "sessionId" text NOT NULL,
    "tableId" text NOT NULL,
    "acknowledgedAt" timestamp(3) without time zone,
    "acknowledgedById" text,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.waiter_requests OWNER TO postgres;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_keys (id, "tenantId", name, key, "keyPrefix", scopes, "webhookUrl", "webhookEvents", "isActive", "expiresAt", "lastUsedAt", "usageCount", "ipWhitelist", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: bill_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bill_requests (id, status, "sessionId", "tableId", "acknowledgedAt", "acknowledgedById", "completedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, description, "displayOrder", "isActive", "tenantId", "createdAt", "updatedAt") FROM stdin;
e3df8ded-014f-4ac5-95a0-d24e09273b94	Appetizers	Start your meal with our delicious starters	1	t	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.704	2025-11-19 14:49:16.704
cd3ffb54-8b40-4131-a9f4-cb864994de3a	Main Courses	Our signature main dishes	2	t	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.711	2025-11-19 14:49:16.711
661a5206-8c20-451e-af6e-8188ac0d2d3b	Desserts	Sweet endings to your meal	3	t	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.714	2025-11-19 14:49:16.714
d938e036-84d9-4cb8-8886-39c8234dca20	Beverages	Refreshing drinks	4	t	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.717	2025-11-19 14:49:16.717
\.


--
-- Data for Name: contact_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact_messages (id, name, email, phone, message, status, "adminNotes", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: customer_referrals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_referrals (id, "referrerId", "referredId", "referralCode", status, "referrerReward", "referredReward", "rewardedAt", "createdAt", "completedAt") FROM stdin;
\.


--
-- Data for Name: customer_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_sessions (id, "sessionId", "customerId", "tableId", phone, "isActive", "userAgent", "ipAddress", "expiresAt", "lastActivity", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (id, name, email, phone, "phoneVerified", "loyaltyPoints", "loyaltyTier", tags, notes, "referralCode", "referredBy", "totalOrders", "totalSpent", "averageOrder", birthday, preferences, "tenantId", "createdAt", "updatedAt", "lastVisit") FROM stdin;
\.


--
-- Data for Name: desktop_releases; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.desktop_releases (id, version, "releaseTag", published, "pubDate", "windowsUrl", "windowsSignature", "macArmUrl", "macArmSignature", "macIntelUrl", "macIntelSignature", "linuxUrl", "linuxSignature", "releaseNotes", changelog, "downloadCount", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: integration_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.integration_settings (id, "tenantId", "integrationType", provider, name, config, "isEnabled", "isConfigured", "lastSyncedAt", notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (id, "subscriptionId", "paymentId", "invoiceNumber", status, subtotal, tax, total, currency, "periodStart", "periodEnd", "dueDate", "paidAt", "voidedAt", "createdAt", "updatedAt", description, notes, "pdfUrl") FROM stdin;
\.


--
-- Data for Name: loyalty_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.loyalty_transactions (id, "customerId", type, points, description, "orderId", "orderNumber", "orderAmount", "referredCustomerId", "balanceBefore", "balanceAfter", metadata, "createdAt") FROM stdin;
\.


--
-- Data for Name: modifier_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.modifier_groups (id, name, "displayName", description, "selectionType", "minSelections", "maxSelections", "isRequired", "displayOrder", "isActive", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: modifiers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.modifiers (id, name, "displayName", description, "priceAdjustment", "isAvailable", "displayOrder", "groupId", "tenantId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, title, message, type, data, "userId", "tenantId", "isGlobal", priority, "createdAt", "expiresAt") FROM stdin;
8d366a12-fbc0-49a3-b42b-587ba3cf7d14	E-posta Doğrulaması Gereklidir	E-posta adresinize gönderilen 6 haneli doğrulama kodunu kullanarak hesabınızı doğrulamanız gerekmektedir. Lütfen e-posta kutunuzu kontrol ediniz.	WARNING	{"action": "EMAIL_VERIFICATION_REQUIRED", "expiresAt": "2025-11-19T15:50:57.495Z"}	4619eba6-8fbb-4866-9ea0-5de2de7e14d5	14c09b82-d5d9-46f5-9140-e276a0a12e39	f	NORMAL	2025-11-19 14:51:03.23	2025-11-19 15:50:57.495
ffb45fa9-529e-48dd-baad-12607c914392	Email Başarıyla Doğrulandı	Email adresiniz başarıyla doğrulandı. Artık tüm özelliklere erişebilirsiniz.	SUCCESS	\N	4619eba6-8fbb-4866-9ea0-5de2de7e14d5	14c09b82-d5d9-46f5-9140-e276a0a12e39	f	NORMAL	2025-11-19 14:51:46.715	\N
5fac766b-d784-441e-9c71-14739ddf98cb	E-posta Doğrulaması Gereklidir	E-posta adresinize gönderilen 6 haneli doğrulama kodunu kullanarak hesabınızı doğrulamanız gerekmektedir. Lütfen e-posta kutunuzu kontrol ediniz.	WARNING	{"action": "EMAIL_VERIFICATION_REQUIRED", "expiresAt": "2025-11-20T14:05:41.240Z"}	fbdc490d-c9db-4889-b21c-32095b1788b7	514a2063-64de-4cb7-ab99-a0706db125c3	f	NORMAL	2025-11-20 13:05:46.058	2025-11-20 14:05:41.24
\.


--
-- Data for Name: order_item_modifiers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_item_modifiers (id, quantity, "priceAdjustment", "orderItemId", "modifierId", "createdAt") FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, quantity, "unitPrice", subtotal, "modifierTotal", notes, status, "orderId", "productId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, "orderNumber", type, status, "totalAmount", discount, "finalAmount", notes, "customerName", "sessionId", "customerPhone", "requiresApproval", "approvedAt", "tableId", "customerId", "userId", "approvedById", "tenantId", "createdAt", "updatedAt", "paidAt") FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, amount, method, status, "transactionId", notes, "orderId", "createdAt", "paidAt") FROM stdin;
\.


--
-- Data for Name: pending_plan_changes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pending_plan_changes (id, "subscriptionId", "currentPlanId", "newPlanId", "newBillingCycle", "isUpgrade", "currentAmount", "newAmount", "prorationAmount", currency, "paymentRequired", "paymentStatus", "paymentIntentId", "paymentProvider", "scheduledFor", "appliedAt", reason, "failureReason", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: phone_verifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.phone_verifications (id, phone, code, verified, "expiresAt", "sessionId", "tenantId", attempts, "maxAttempts", "createdAt", "verifiedAt") FROM stdin;
\.


--
-- Data for Name: pos_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pos_settings (id, "tenantId", "enableTablelessMode", "enableTwoStepCheckout", "showProductImages", "enableCustomerOrdering", "createdAt", "updatedAt") FROM stdin;
e785ebf3-e49c-435b-832c-404da8e56fbb	14c09b82-d5d9-46f5-9140-e276a0a12e39	f	t	t	t	2025-11-19 15:09:22.129	2025-11-19 15:09:22.129
044a9a0d-b2c1-4d1e-858e-9a78068590fa	514a2063-64de-4cb7-ab99-a0706db125c3	f	t	t	t	2025-11-20 13:06:09.963	2025-11-20 13:06:09.963
\.


--
-- Data for Name: product_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_images (id, url, filename, size, "mimeType", "tenantId", "createdAt") FROM stdin;
cbf22a31-a18d-4d32-bec3-0f4ad8bfcc07	https://staging.hummytummy.com/uploads/products/14c09b82-d5d9-46f5-9140-e276a0a12e39/81d6609f-226b-4788-aa15-9758fbc9ad88.png	ChatGPT Image Oct 17, 2025, 12_00_56 AM.png	82149	image/png	14c09b82-d5d9-46f5-9140-e276a0a12e39	2025-11-20 17:45:36.382
3114a9d6-0ac4-449b-b0b8-9b6ea60a7de1	https://staging.hummytummy.com/uploads/products/14c09b82-d5d9-46f5-9140-e276a0a12e39/75638974-e713-40de-8d80-7ac06cf58766.png	ChatGPT Image Oct 17, 2025, 12_00_56 AM_nobg.png	69039	image/png	14c09b82-d5d9-46f5-9140-e276a0a12e39	2025-11-20 17:50:11.176
de9c8edd-3e5c-4db3-adb9-f945884f28c7	https://staging.hummytummy.com/uploads/products/14c09b82-d5d9-46f5-9140-e276a0a12e39/0811209b-a6df-4d38-92c0-8e8f490e1162.png	ChatGPT Image Oct 17, 2025, 12_00_56 AM.png	82149	image/png	14c09b82-d5d9-46f5-9140-e276a0a12e39	2025-11-20 18:11:01.99
a86eb36a-edd4-4913-86f0-29b6a9fa67fd	https://staging.hummytummy.com/uploads/products/14c09b82-d5d9-46f5-9140-e276a0a12e39/f3dfe623-0278-490c-8ed8-62dbea476300.png	ChatGPT Image Oct 17, 2025, 12_00_56 AM_nobg.png	69039	image/png	14c09b82-d5d9-46f5-9140-e276a0a12e39	2025-11-20 18:11:02.082
ad19b7ed-18aa-46e7-9f75-609cefc43521	https://staging.hummytummy.com/uploads/products/14c09b82-d5d9-46f5-9140-e276a0a12e39/9d1cb78e-5183-4baa-b0db-4dd5d5acf895.png	URKMEZ RENK PALETI TONLAMA_nobg.png	53899	image/png	14c09b82-d5d9-46f5-9140-e276a0a12e39	2025-11-20 18:22:33.83
\.


--
-- Data for Name: product_modifier_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_modifier_groups (id, "displayOrder", "productId", "groupId", "createdAt") FROM stdin;
\.


--
-- Data for Name: product_to_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_to_images (id, "order", "productId", "imageId", "createdAt") FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, name, description, price, image, "isAvailable", "stockTracked", "currentStock", "categoryId", "tenantId", "createdAt", "updatedAt") FROM stdin;
06305855-571b-4797-b7c5-f6fa50bed584	Caesar Salad	Fresh romaine lettuce with Caesar dressing and croutons	8.99	\N	t	t	50	e3df8ded-014f-4ac5-95a0-d24e09273b94	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.722	2025-11-19 14:49:16.722
2ba8f578-a808-427c-9cc9-6ae5670aaac3	Garlic Bread	Toasted bread with garlic butter	5.99	\N	t	t	30	e3df8ded-014f-4ac5-95a0-d24e09273b94	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.722	2025-11-19 14:49:16.722
b52daadb-a828-401b-bcef-d3a33287b3b8	Buffalo Wings	Spicy chicken wings with ranch dressing	12.99	\N	t	t	25	e3df8ded-014f-4ac5-95a0-d24e09273b94	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.722	2025-11-19 14:49:16.722
c7292141-2999-46d6-8dec-01a0b31163ce	Grilled Salmon	Fresh Atlantic salmon with vegetables	24.99	\N	t	t	15	cd3ffb54-8b40-4131-a9f4-cb864994de3a	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.722	2025-11-19 14:49:16.722
7cb724c6-f915-4c31-89d7-54444e6fdf0b	Beef Burger	Premium beef patty with cheese and fries	15.99	\N	t	t	40	cd3ffb54-8b40-4131-a9f4-cb864994de3a	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.722	2025-11-19 14:49:16.722
d44b62b3-0f14-4ef9-809b-9c884ae0c93d	Pasta Carbonara	Classic Italian pasta with creamy sauce	16.99	\N	t	t	35	cd3ffb54-8b40-4131-a9f4-cb864994de3a	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.722	2025-11-19 14:49:16.722
468b3d0f-2668-4891-8989-13d4d38e6fd0	Chicken Tikka Masala	Marinated chicken in spicy tomato sauce	18.99	\N	t	t	20	cd3ffb54-8b40-4131-a9f4-cb864994de3a	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.722	2025-11-19 14:49:16.722
d4eda6fc-9e75-424d-b98f-fe6ba78a6077	Chocolate Lava Cake	Warm chocolate cake with molten center	7.99	\N	t	t	22	661a5206-8c20-451e-af6e-8188ac0d2d3b	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.722	2025-11-19 14:49:16.722
3e718336-05f1-4472-be96-884583a7bbe2	Tiramisu	Classic Italian coffee-flavored dessert	8.99	\N	t	t	18	661a5206-8c20-451e-af6e-8188ac0d2d3b	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.722	2025-11-19 14:49:16.722
45f18690-cdf0-41ab-8717-1888ee4a3224	Ice Cream Sundae	Three scoops with toppings	6.99	\N	t	t	50	661a5206-8c20-451e-af6e-8188ac0d2d3b	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.722	2025-11-19 14:49:16.722
e59e83c7-e9b6-4e6f-a2b9-9c579bf0408b	Coca Cola	Refreshing soft drink	2.99	\N	t	t	100	d938e036-84d9-4cb8-8886-39c8234dca20	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.722	2025-11-19 14:49:16.722
d62aaae0-4b85-4057-b568-688403a43a70	Fresh Orange Juice	Freshly squeezed orange juice	4.99	\N	t	t	30	d938e036-84d9-4cb8-8886-39c8234dca20	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.722	2025-11-19 14:49:16.722
0085c28e-c23d-4576-9f25-55c9b3e26ea6	Coffee	Freshly brewed coffee	3.99	\N	t	f	0	d938e036-84d9-4cb8-8886-39c8234dca20	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.722	2025-11-19 14:49:16.722
\.


--
-- Data for Name: qr_menu_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qr_menu_settings (id, "tenantId", "primaryColor", "secondaryColor", "backgroundColor", "fontFamily", "logoUrl", "showRestaurantInfo", "showPrices", "showDescription", "showImages", "layoutStyle", "itemsPerRow", "enableTableQR", "tableQRMessage", "createdAt", "updatedAt") FROM stdin;
29fc49bf-c7ee-4812-8ffe-1bcf18150c10	514a2063-64de-4cb7-ab99-a0706db125c3	#3B82F6	#1F2937	#F9FAFB	Inter	\N	t	t	t	t	GRID	2	t	Scan to view our menu	2025-11-20 20:07:48.262	2025-11-20 20:07:48.262
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_movements (id, type, quantity, reason, notes, "productId", "userId", "tenantId", "createdAt") FROM stdin;
\.


--
-- Data for Name: subscription_payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscription_payments (id, "subscriptionId", amount, currency, status, "paymentProvider", "stripePaymentIntentId", "iyzicoPaymentId", "paymentMethod", last4, "cardBrand", "failureCode", "failureMessage", "retryCount", "paidAt", "refundedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscription_plans (id, name, "displayName", description, "monthlyPrice", "yearlyPrice", currency, "trialDays", "maxUsers", "maxTables", "maxProducts", "maxCategories", "maxMonthlyOrders", "advancedReports", "multiLocation", "customBranding", "apiAccess", "prioritySupport", "inventoryTracking", "kdsIntegration", "isActive", "createdAt", "updatedAt") FROM stdin;
fe57c9a4-0fc6-4977-87c9-fe1e2e5e4520	FREE	Free Plan	Perfect for small restaurants getting started	0.00	0.00	USD	0	2	5	25	5	50	f	f	f	f	f	f	t	t	2025-11-19 14:49:16.429	2025-11-19 14:49:16.429
14181e2e-058b-47d0-bda6-f3d46ac8ef5c	BASIC	Basic Plan	Great for growing restaurants	29.99	299.99	USD	14	5	20	100	20	500	f	f	f	f	f	t	t	t	2025-11-19 14:49:16.471	2025-11-19 14:49:16.471
94d0e509-dcb7-4e96-b01d-e5c1ea7b054e	PRO	Pro Plan	For established restaurants with multiple locations	79.99	799.99	USD	14	15	50	500	50	2000	t	t	t	f	t	t	t	t	2025-11-19 14:49:16.479	2025-11-19 14:49:16.479
29a6c465-154e-4d59-b0b2-63371364828c	BUSINESS	Business Plan	Enterprise solution for large restaurant chains	199.99	1999.99	USD	14	-1	-1	-1	-1	-1	t	t	t	t	t	t	t	t	2025-11-19 14:49:16.488	2025-11-19 14:49:16.488
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscriptions (id, "tenantId", "planId", status, "billingCycle", "paymentProvider", "startDate", "currentPeriodStart", "currentPeriodEnd", "cancelledAt", "endedAt", "isTrialPeriod", "trialStart", "trialEnd", "stripeSubscriptionId", "iyzicoSubscriptionId", "stripeCustomerId", "iyzicoCustomerId", amount, currency, "autoRenew", "cancelAtPeriodEnd", "cancellationReason", "createdAt", "updatedAt") FROM stdin;
e55dca4e-c8b2-4640-8f6b-581cdb56252b	14c09b82-d5d9-46f5-9140-e276a0a12e39	fe57c9a4-0fc6-4977-87c9-fe1e2e5e4520	ACTIVE	MONTHLY	STRIPE	2025-11-19 14:50:57.282	2025-11-19 14:50:57.282	2035-11-19 14:50:57.282	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	USD	t	f	\N	2025-11-19 14:50:57.284	2025-11-19 14:50:57.284
c55f3d1e-5728-4392-a6a3-7e088be81c3b	514a2063-64de-4cb7-ab99-a0706db125c3	fe57c9a4-0fc6-4977-87c9-fe1e2e5e4520	ACTIVE	MONTHLY	STRIPE	2025-11-20 13:05:41.032	2025-11-20 13:05:41.032	2035-11-20 13:05:41.032	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	USD	t	f	\N	2025-11-20 13:05:41.034	2025-11-20 13:05:41.034
\.


--
-- Data for Name: tables; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tables (id, number, capacity, section, status, "tenantId", "createdAt", "updatedAt") FROM stdin;
634ec14d-ce40-4182-bd88-77b6f471ff58	1	2	Main Hall	AVAILABLE	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.742	2025-11-19 14:49:16.742
38a0ffb7-c3e1-49bc-9a69-ebabad189088	2	4	Main Hall	AVAILABLE	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.742	2025-11-19 14:49:16.742
9096b307-bfcb-45aa-a535-b0a4f59fc478	3	4	Main Hall	AVAILABLE	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.742	2025-11-19 14:49:16.742
60b9b830-6c33-4278-b0dc-91afb40d527b	4	6	Main Hall	AVAILABLE	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.742	2025-11-19 14:49:16.742
72bd7bc6-7c92-40ae-82b3-37ca17037313	5	2	Terrace	AVAILABLE	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.742	2025-11-19 14:49:16.742
76d60dd4-2ef9-44cd-9543-57e3bbc2ace1	6	4	Terrace	AVAILABLE	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.742	2025-11-19 14:49:16.742
85a3ce92-e38e-4d39-a8fd-1e37bdd6db2d	7	8	Private Room	AVAILABLE	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.742	2025-11-19 14:49:16.742
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (id, name, subdomain, status, "currentPlanId", "paymentRegion", "trialUsed", "trialStartedAt", "trialEndsAt", "createdAt", "updatedAt") FROM stdin;
0069a473-bf88-47a4-ada6-13c4412b6351	Demo Restaurant	demo	ACTIVE	fe57c9a4-0fc6-4977-87c9-fe1e2e5e4520	INTERNATIONAL	f	\N	\N	2025-11-19 14:49:16.496	2025-11-19 14:49:16.496
14c09b82-d5d9-46f5-9140-e276a0a12e39	deneme	deneme	ACTIVE	fe57c9a4-0fc6-4977-87c9-fe1e2e5e4520	INTERNATIONAL	f	\N	\N	2025-11-19 14:50:57.276	2025-11-19 14:50:57.276
514a2063-64de-4cb7-ab99-a0706db125c3	Dolan	dolan	ACTIVE	fe57c9a4-0fc6-4977-87c9-fe1e2e5e4520	INTERNATIONAL	f	\N	\N	2025-11-20 13:05:41.02	2025-11-20 13:05:41.02
\.


--
-- Data for Name: user_notification_reads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_notification_reads (id, "notificationId", "userId", "readAt") FROM stdin;
1115cd20-ecf7-49ab-a921-8914f92d1e78	8d366a12-fbc0-49a3-b42b-587ba3cf7d14	4619eba6-8fbb-4866-9ea0-5de2de7e14d5	2025-11-19 14:51:10.131
0c3fd47f-7604-45d9-92e9-b56c47ea9759	5fac766b-d784-441e-9c71-14739ddf98cb	fbdc490d-c9db-4889-b21c-32095b1788b7	2025-11-20 13:06:05.231
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password, "firstName", "lastName", role, status, "emailVerified", "emailVerificationCode", "emailVerificationCodeExpires", "resetToken", "resetTokenExpiry", avatar, phone, "lastLogin", "tenantId", "createdAt", "updatedAt") FROM stdin;
9127fdac-70c7-4e37-ba70-de4e08ae88fc	admin@restaurant.com	$2a$10$Ki5q0LLtDqhux0YzGtfileHul.tce5RjCEl/WVvsk5GFHZTBSOOq6	John	Admin	ADMIN	ACTIVE	f	\N	\N	\N	\N	\N	\N	\N	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.684	2025-11-19 14:49:16.684
23a7e26c-8b30-49ad-9870-87ea5c17472d	waiter@restaurant.com	$2a$10$Ki5q0LLtDqhux0YzGtfileHul.tce5RjCEl/WVvsk5GFHZTBSOOq6	Jane	Waiter	WAITER	ACTIVE	f	\N	\N	\N	\N	\N	\N	\N	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.695	2025-11-19 14:49:16.695
d09b1ea5-c1d5-43c2-9f28-3aebfff54b22	kitchen@restaurant.com	$2a$10$Ki5q0LLtDqhux0YzGtfileHul.tce5RjCEl/WVvsk5GFHZTBSOOq6	Mike	Chef	KITCHEN	ACTIVE	f	\N	\N	\N	\N	\N	\N	\N	0069a473-bf88-47a4-ada6-13c4412b6351	2025-11-19 14:49:16.699	2025-11-19 14:49:16.699
4619eba6-8fbb-4866-9ea0-5de2de7e14d5	muhammedtarikucar@gmail.com	$2a$10$9cUeppp2KrUTAoISZc9REO7/sHzwTGI79VsnFW3nwGTczZ.whsfmy	deneme	deneme	ADMIN	ACTIVE	t	\N	\N	\N	\N	\N	\N	\N	14c09b82-d5d9-46f5-9140-e276a0a12e39	2025-11-19 14:50:57.478	2025-11-19 14:51:46.706
fbdc490d-c9db-4889-b21c-32095b1788b7	jarulla.t@gmail.com	$2a$10$lMWb2NeoLEPQQjZmI8X3XuS.PKhDVr3rvlB1.q6P6CahGlAVsB4Qe	carullah	Tursun	ADMIN	ACTIVE	f	952045	2025-11-20 14:05:41.24	\N	\N	\N	\N	\N	514a2063-64de-4cb7-ab99-a0706db125c3	2025-11-20 13:05:41.217	2025-11-20 13:05:41.242
\.


--
-- Data for Name: waiter_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.waiter_requests (id, message, status, "sessionId", "tableId", "acknowledgedAt", "acknowledgedById", "completedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: bill_requests bill_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_requests
    ADD CONSTRAINT bill_requests_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: contact_messages contact_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_messages
    ADD CONSTRAINT contact_messages_pkey PRIMARY KEY (id);


--
-- Name: customer_referrals customer_referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_referrals
    ADD CONSTRAINT customer_referrals_pkey PRIMARY KEY (id);


--
-- Name: customer_sessions customer_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_sessions
    ADD CONSTRAINT customer_sessions_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: desktop_releases desktop_releases_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.desktop_releases
    ADD CONSTRAINT desktop_releases_pkey PRIMARY KEY (id);


--
-- Name: integration_settings integration_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_settings
    ADD CONSTRAINT integration_settings_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: loyalty_transactions loyalty_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT loyalty_transactions_pkey PRIMARY KEY (id);


--
-- Name: modifier_groups modifier_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifier_groups
    ADD CONSTRAINT modifier_groups_pkey PRIMARY KEY (id);


--
-- Name: modifiers modifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifiers
    ADD CONSTRAINT modifiers_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: order_item_modifiers order_item_modifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item_modifiers
    ADD CONSTRAINT order_item_modifiers_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: pending_plan_changes pending_plan_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_plan_changes
    ADD CONSTRAINT pending_plan_changes_pkey PRIMARY KEY (id);


--
-- Name: phone_verifications phone_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.phone_verifications
    ADD CONSTRAINT phone_verifications_pkey PRIMARY KEY (id);


--
-- Name: pos_settings pos_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pos_settings
    ADD CONSTRAINT pos_settings_pkey PRIMARY KEY (id);


--
-- Name: product_images product_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_pkey PRIMARY KEY (id);


--
-- Name: product_modifier_groups product_modifier_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_modifier_groups
    ADD CONSTRAINT product_modifier_groups_pkey PRIMARY KEY (id);


--
-- Name: product_to_images product_to_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_to_images
    ADD CONSTRAINT product_to_images_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: qr_menu_settings qr_menu_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qr_menu_settings
    ADD CONSTRAINT qr_menu_settings_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: subscription_payments subscription_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT subscription_payments_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: tables tables_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT tables_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: user_notification_reads user_notification_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_reads
    ADD CONSTRAINT user_notification_reads_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: waiter_requests waiter_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waiter_requests
    ADD CONSTRAINT waiter_requests_pkey PRIMARY KEY (id);


--
-- Name: api_keys_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "api_keys_isActive_idx" ON public.api_keys USING btree ("isActive");


--
-- Name: api_keys_key_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_keys_key_idx ON public.api_keys USING btree (key);


--
-- Name: api_keys_key_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX api_keys_key_key ON public.api_keys USING btree (key);


--
-- Name: api_keys_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "api_keys_tenantId_idx" ON public.api_keys USING btree ("tenantId");


--
-- Name: bill_requests_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "bill_requests_sessionId_idx" ON public.bill_requests USING btree ("sessionId");


--
-- Name: bill_requests_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bill_requests_status_idx ON public.bill_requests USING btree (status);


--
-- Name: bill_requests_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "bill_requests_tableId_idx" ON public.bill_requests USING btree ("tableId");


--
-- Name: categories_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "categories_tenantId_idx" ON public.categories USING btree ("tenantId");


--
-- Name: contact_messages_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "contact_messages_createdAt_idx" ON public.contact_messages USING btree ("createdAt");


--
-- Name: contact_messages_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX contact_messages_status_idx ON public.contact_messages USING btree (status);


--
-- Name: customer_referrals_referralCode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_referrals_referralCode_idx" ON public.customer_referrals USING btree ("referralCode");


--
-- Name: customer_referrals_referredId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_referrals_referredId_idx" ON public.customer_referrals USING btree ("referredId");


--
-- Name: customer_referrals_referredId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customer_referrals_referredId_key" ON public.customer_referrals USING btree ("referredId");


--
-- Name: customer_referrals_referrerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_referrals_referrerId_idx" ON public.customer_referrals USING btree ("referrerId");


--
-- Name: customer_referrals_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customer_referrals_status_idx ON public.customer_referrals USING btree (status);


--
-- Name: customer_sessions_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_sessions_customerId_idx" ON public.customer_sessions USING btree ("customerId");


--
-- Name: customer_sessions_expiresAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_sessions_expiresAt_idx" ON public.customer_sessions USING btree ("expiresAt");


--
-- Name: customer_sessions_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_sessions_sessionId_idx" ON public.customer_sessions USING btree ("sessionId");


--
-- Name: customer_sessions_sessionId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customer_sessions_sessionId_key" ON public.customer_sessions USING btree ("sessionId");


--
-- Name: customer_sessions_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_sessions_tenantId_idx" ON public.customer_sessions USING btree ("tenantId");


--
-- Name: customers_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customers_email_idx ON public.customers USING btree (email);


--
-- Name: customers_loyaltyTier_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customers_loyaltyTier_idx" ON public.customers USING btree ("loyaltyTier");


--
-- Name: customers_phone_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customers_phone_idx ON public.customers USING btree (phone);


--
-- Name: customers_referralCode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customers_referralCode_idx" ON public.customers USING btree ("referralCode");


--
-- Name: customers_referralCode_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customers_referralCode_key" ON public.customers USING btree ("referralCode");


--
-- Name: customers_tenantId_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customers_tenantId_email_key" ON public.customers USING btree ("tenantId", email);


--
-- Name: customers_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customers_tenantId_idx" ON public.customers USING btree ("tenantId");


--
-- Name: customers_tenantId_phone_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customers_tenantId_phone_key" ON public.customers USING btree ("tenantId", phone);


--
-- Name: desktop_releases_published_pubDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "desktop_releases_published_pubDate_idx" ON public.desktop_releases USING btree (published, "pubDate");


--
-- Name: desktop_releases_releaseTag_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "desktop_releases_releaseTag_key" ON public.desktop_releases USING btree ("releaseTag");


--
-- Name: desktop_releases_version_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX desktop_releases_version_idx ON public.desktop_releases USING btree (version);


--
-- Name: desktop_releases_version_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX desktop_releases_version_key ON public.desktop_releases USING btree (version);


--
-- Name: integration_settings_integrationType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "integration_settings_integrationType_idx" ON public.integration_settings USING btree ("integrationType");


--
-- Name: integration_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "integration_settings_tenantId_idx" ON public.integration_settings USING btree ("tenantId");


--
-- Name: integration_settings_tenantId_integrationType_provider_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "integration_settings_tenantId_integrationType_provider_key" ON public.integration_settings USING btree ("tenantId", "integrationType", provider);


--
-- Name: invoices_dueDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_dueDate_idx" ON public.invoices USING btree ("dueDate");


--
-- Name: invoices_invoiceNumber_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_invoiceNumber_idx" ON public.invoices USING btree ("invoiceNumber");


--
-- Name: invoices_invoiceNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "invoices_invoiceNumber_key" ON public.invoices USING btree ("invoiceNumber");


--
-- Name: invoices_paymentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "invoices_paymentId_key" ON public.invoices USING btree ("paymentId");


--
-- Name: invoices_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX invoices_status_idx ON public.invoices USING btree (status);


--
-- Name: invoices_subscriptionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_subscriptionId_idx" ON public.invoices USING btree ("subscriptionId");


--
-- Name: loyalty_transactions_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "loyalty_transactions_createdAt_idx" ON public.loyalty_transactions USING btree ("createdAt");


--
-- Name: loyalty_transactions_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "loyalty_transactions_customerId_idx" ON public.loyalty_transactions USING btree ("customerId");


--
-- Name: loyalty_transactions_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX loyalty_transactions_type_idx ON public.loyalty_transactions USING btree (type);


--
-- Name: modifier_groups_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifier_groups_isActive_idx" ON public.modifier_groups USING btree ("isActive");


--
-- Name: modifier_groups_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifier_groups_tenantId_idx" ON public.modifier_groups USING btree ("tenantId");


--
-- Name: modifiers_groupId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifiers_groupId_idx" ON public.modifiers USING btree ("groupId");


--
-- Name: modifiers_isAvailable_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifiers_isAvailable_idx" ON public.modifiers USING btree ("isAvailable");


--
-- Name: modifiers_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifiers_tenantId_idx" ON public.modifiers USING btree ("tenantId");


--
-- Name: notifications_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "notifications_createdAt_idx" ON public.notifications USING btree ("createdAt");


--
-- Name: notifications_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "notifications_tenantId_idx" ON public.notifications USING btree ("tenantId");


--
-- Name: notifications_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "notifications_userId_idx" ON public.notifications USING btree ("userId");


--
-- Name: order_item_modifiers_modifierId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_item_modifiers_modifierId_idx" ON public.order_item_modifiers USING btree ("modifierId");


--
-- Name: order_item_modifiers_orderItemId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_item_modifiers_orderItemId_idx" ON public.order_item_modifiers USING btree ("orderItemId");


--
-- Name: order_items_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_items_orderId_idx" ON public.order_items USING btree ("orderId");


--
-- Name: order_items_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_items_productId_idx" ON public.order_items USING btree ("productId");


--
-- Name: orders_approvedById_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_approvedById_idx" ON public.orders USING btree ("approvedById");


--
-- Name: orders_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_customerId_idx" ON public.orders USING btree ("customerId");


--
-- Name: orders_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_sessionId_idx" ON public.orders USING btree ("sessionId");


--
-- Name: orders_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orders_status_idx ON public.orders USING btree (status);


--
-- Name: orders_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_tableId_idx" ON public.orders USING btree ("tableId");


--
-- Name: orders_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_tenantId_idx" ON public.orders USING btree ("tenantId");


--
-- Name: orders_tenantId_orderNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "orders_tenantId_orderNumber_key" ON public.orders USING btree ("tenantId", "orderNumber");


--
-- Name: orders_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_userId_idx" ON public.orders USING btree ("userId");


--
-- Name: payments_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "payments_orderId_idx" ON public.payments USING btree ("orderId");


--
-- Name: payments_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payments_status_idx ON public.payments USING btree (status);


--
-- Name: pending_plan_changes_paymentStatus_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pending_plan_changes_paymentStatus_idx" ON public.pending_plan_changes USING btree ("paymentStatus");


--
-- Name: pending_plan_changes_scheduledFor_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pending_plan_changes_scheduledFor_idx" ON public.pending_plan_changes USING btree ("scheduledFor");


--
-- Name: pending_plan_changes_subscriptionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pending_plan_changes_subscriptionId_idx" ON public.pending_plan_changes USING btree ("subscriptionId");


--
-- Name: phone_verifications_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX phone_verifications_code_idx ON public.phone_verifications USING btree (code);


--
-- Name: phone_verifications_expiresAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "phone_verifications_expiresAt_idx" ON public.phone_verifications USING btree ("expiresAt");


--
-- Name: phone_verifications_phone_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "phone_verifications_phone_tenantId_idx" ON public.phone_verifications USING btree (phone, "tenantId");


--
-- Name: pos_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pos_settings_tenantId_idx" ON public.pos_settings USING btree ("tenantId");


--
-- Name: pos_settings_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "pos_settings_tenantId_key" ON public.pos_settings USING btree ("tenantId");


--
-- Name: product_images_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_images_tenantId_idx" ON public.product_images USING btree ("tenantId");


--
-- Name: product_modifier_groups_groupId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_modifier_groups_groupId_idx" ON public.product_modifier_groups USING btree ("groupId");


--
-- Name: product_modifier_groups_productId_groupId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "product_modifier_groups_productId_groupId_key" ON public.product_modifier_groups USING btree ("productId", "groupId");


--
-- Name: product_modifier_groups_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_modifier_groups_productId_idx" ON public.product_modifier_groups USING btree ("productId");


--
-- Name: product_to_images_imageId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_to_images_imageId_idx" ON public.product_to_images USING btree ("imageId");


--
-- Name: product_to_images_productId_imageId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "product_to_images_productId_imageId_key" ON public.product_to_images USING btree ("productId", "imageId");


--
-- Name: product_to_images_productId_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_to_images_productId_order_idx" ON public.product_to_images USING btree ("productId", "order");


--
-- Name: products_categoryId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "products_categoryId_idx" ON public.products USING btree ("categoryId");


--
-- Name: products_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "products_tenantId_idx" ON public.products USING btree ("tenantId");


--
-- Name: qr_menu_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "qr_menu_settings_tenantId_idx" ON public.qr_menu_settings USING btree ("tenantId");


--
-- Name: qr_menu_settings_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "qr_menu_settings_tenantId_key" ON public.qr_menu_settings USING btree ("tenantId");


--
-- Name: stock_movements_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_movements_productId_idx" ON public.stock_movements USING btree ("productId");


--
-- Name: stock_movements_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_movements_tenantId_idx" ON public.stock_movements USING btree ("tenantId");


--
-- Name: stock_movements_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_movements_userId_idx" ON public.stock_movements USING btree ("userId");


--
-- Name: subscription_payments_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscription_payments_createdAt_idx" ON public.subscription_payments USING btree ("createdAt");


--
-- Name: subscription_payments_iyzicoPaymentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscription_payments_iyzicoPaymentId_key" ON public.subscription_payments USING btree ("iyzicoPaymentId");


--
-- Name: subscription_payments_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX subscription_payments_status_idx ON public.subscription_payments USING btree (status);


--
-- Name: subscription_payments_stripePaymentIntentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscription_payments_stripePaymentIntentId_key" ON public.subscription_payments USING btree ("stripePaymentIntentId");


--
-- Name: subscription_payments_subscriptionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscription_payments_subscriptionId_idx" ON public.subscription_payments USING btree ("subscriptionId");


--
-- Name: subscription_plans_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX subscription_plans_name_key ON public.subscription_plans USING btree (name);


--
-- Name: subscriptions_currentPeriodEnd_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscriptions_currentPeriodEnd_idx" ON public.subscriptions USING btree ("currentPeriodEnd");


--
-- Name: subscriptions_iyzicoSubscriptionId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscriptions_iyzicoSubscriptionId_key" ON public.subscriptions USING btree ("iyzicoSubscriptionId");


--
-- Name: subscriptions_planId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscriptions_planId_idx" ON public.subscriptions USING btree ("planId");


--
-- Name: subscriptions_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX subscriptions_status_idx ON public.subscriptions USING btree (status);


--
-- Name: subscriptions_stripeSubscriptionId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscriptions_stripeSubscriptionId_key" ON public.subscriptions USING btree ("stripeSubscriptionId");


--
-- Name: subscriptions_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscriptions_tenantId_idx" ON public.subscriptions USING btree ("tenantId");


--
-- Name: tables_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "tables_tenantId_idx" ON public.tables USING btree ("tenantId");


--
-- Name: tables_tenantId_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "tables_tenantId_number_key" ON public.tables USING btree ("tenantId", number);


--
-- Name: tenants_currentPlanId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "tenants_currentPlanId_idx" ON public.tenants USING btree ("currentPlanId");


--
-- Name: tenants_subdomain_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX tenants_subdomain_key ON public.tenants USING btree (subdomain);


--
-- Name: user_notification_reads_notificationId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_notification_reads_notificationId_idx" ON public.user_notification_reads USING btree ("notificationId");


--
-- Name: user_notification_reads_notificationId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "user_notification_reads_notificationId_userId_key" ON public.user_notification_reads USING btree ("notificationId", "userId");


--
-- Name: user_notification_reads_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_notification_reads_userId_idx" ON public.user_notification_reads USING btree ("userId");


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_resetToken_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "users_resetToken_key" ON public.users USING btree ("resetToken");


--
-- Name: users_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "users_tenantId_idx" ON public.users USING btree ("tenantId");


--
-- Name: waiter_requests_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "waiter_requests_sessionId_idx" ON public.waiter_requests USING btree ("sessionId");


--
-- Name: waiter_requests_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX waiter_requests_status_idx ON public.waiter_requests USING btree (status);


--
-- Name: waiter_requests_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "waiter_requests_tableId_idx" ON public.waiter_requests USING btree ("tableId");


--
-- Name: api_keys api_keys_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT "api_keys_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bill_requests bill_requests_acknowledgedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_requests
    ADD CONSTRAINT "bill_requests_acknowledgedById_fkey" FOREIGN KEY ("acknowledgedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bill_requests bill_requests_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_requests
    ADD CONSTRAINT "bill_requests_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: categories categories_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "categories_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_referrals customer_referrals_referredId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_referrals
    ADD CONSTRAINT "customer_referrals_referredId_fkey" FOREIGN KEY ("referredId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_referrals customer_referrals_referrerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_referrals
    ADD CONSTRAINT "customer_referrals_referrerId_fkey" FOREIGN KEY ("referrerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_sessions customer_sessions_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_sessions
    ADD CONSTRAINT "customer_sessions_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: customers customers_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT "customers_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: integration_settings integration_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_settings
    ADD CONSTRAINT "integration_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoices invoices_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public.subscription_payments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: loyalty_transactions loyalty_transactions_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT "loyalty_transactions_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: modifier_groups modifier_groups_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifier_groups
    ADD CONSTRAINT "modifier_groups_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: modifiers modifiers_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifiers
    ADD CONSTRAINT "modifiers_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public.modifier_groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: modifiers modifiers_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifiers
    ADD CONSTRAINT "modifiers_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_item_modifiers order_item_modifiers_modifierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item_modifiers
    ADD CONSTRAINT "order_item_modifiers_modifierId_fkey" FOREIGN KEY ("modifierId") REFERENCES public.modifiers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: order_item_modifiers order_item_modifiers_orderItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item_modifiers
    ADD CONSTRAINT "order_item_modifiers_orderItemId_fkey" FOREIGN KEY ("orderItemId") REFERENCES public.order_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_items order_items_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "order_items_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_items order_items_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "order_items_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: orders orders_approvedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_approvedById_fkey" FOREIGN KEY ("approvedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orders orders_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payments payments_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pending_plan_changes pending_plan_changes_currentPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_plan_changes
    ADD CONSTRAINT "pending_plan_changes_currentPlanId_fkey" FOREIGN KEY ("currentPlanId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pending_plan_changes pending_plan_changes_newPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_plan_changes
    ADD CONSTRAINT "pending_plan_changes_newPlanId_fkey" FOREIGN KEY ("newPlanId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pending_plan_changes pending_plan_changes_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_plan_changes
    ADD CONSTRAINT "pending_plan_changes_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pos_settings pos_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pos_settings
    ADD CONSTRAINT "pos_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_images product_images_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT "product_images_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_modifier_groups product_modifier_groups_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_modifier_groups
    ADD CONSTRAINT "product_modifier_groups_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public.modifier_groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_modifier_groups product_modifier_groups_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_modifier_groups
    ADD CONSTRAINT "product_modifier_groups_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_to_images product_to_images_imageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_to_images
    ADD CONSTRAINT "product_to_images_imageId_fkey" FOREIGN KEY ("imageId") REFERENCES public.product_images(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_to_images product_to_images_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_to_images
    ADD CONSTRAINT "product_to_images_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: products products_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "products_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: products products_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "products_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: qr_menu_settings qr_menu_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qr_menu_settings
    ADD CONSTRAINT "qr_menu_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT "stock_movements_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT "stock_movements_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT "stock_movements_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: subscription_payments subscription_payments_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT "subscription_payments_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT "subscriptions_planId_fkey" FOREIGN KEY ("planId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: subscriptions subscriptions_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT "subscriptions_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tables tables_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT "tables_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tenants tenants_currentPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT "tenants_currentPlanId_fkey" FOREIGN KEY ("currentPlanId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_notification_reads user_notification_reads_notificationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_reads
    ADD CONSTRAINT "user_notification_reads_notificationId_fkey" FOREIGN KEY ("notificationId") REFERENCES public.notifications(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_notification_reads user_notification_reads_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_reads
    ADD CONSTRAINT "user_notification_reads_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: waiter_requests waiter_requests_acknowledgedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waiter_requests
    ADD CONSTRAINT "waiter_requests_acknowledgedById_fkey" FOREIGN KEY ("acknowledgedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: waiter_requests waiter_requests_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waiter_requests
    ADD CONSTRAINT "waiter_requests_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict tWeeains9JSTOIRyvPlEOqMf3pn5Njq4vZjC5IocZ3u7WJgDjJad95Jui5ofPPA

