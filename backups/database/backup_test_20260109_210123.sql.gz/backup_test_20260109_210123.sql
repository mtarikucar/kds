--
-- PostgreSQL database dump
--

\restrict a7IGwLf5jerC4bDbtqfnA9TQPwZaG9GVPzrHSGFYgc0SBlXQg5TlPridBhzQMFm

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_keys (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    key text NOT NULL,
    "keyPrefix" text NOT NULL,
    scopes text[],
    "webhookUrl" text,
    "webhookEvents" text[] DEFAULT ARRAY[]::text[],
    "isActive" boolean DEFAULT true NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "lastUsedAt" timestamp(3) without time zone,
    "usageCount" integer DEFAULT 0 NOT NULL,
    "ipWhitelist" text[] DEFAULT ARRAY[]::text[],
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.api_keys OWNER TO postgres;

--
-- Name: bill_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bill_requests (
    id text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "sessionId" text NOT NULL,
    "tableId" text NOT NULL,
    "acknowledgedAt" timestamp(3) without time zone,
    "acknowledgedById" text,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.bill_requests OWNER TO postgres;

--
-- Name: cash_drawer_movements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cash_drawer_movements (
    id text NOT NULL,
    type text NOT NULL,
    amount numeric(10,2) NOT NULL,
    reason text,
    notes text,
    "denominationBreakdown" jsonb,
    "zReportId" text,
    "userId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.cash_drawer_movements OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: contact_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact_messages (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    message text NOT NULL,
    status text DEFAULT 'NEW'::text NOT NULL,
    "adminNotes" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.contact_messages OWNER TO postgres;

--
-- Name: customer_referrals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_referrals (
    id text NOT NULL,
    "referrerId" text NOT NULL,
    "referredId" text NOT NULL,
    "referralCode" text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "referrerReward" integer DEFAULT 0 NOT NULL,
    "referredReward" integer DEFAULT 0 NOT NULL,
    "rewardedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone
);


ALTER TABLE public.customer_referrals OWNER TO postgres;

--
-- Name: customer_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_sessions (
    id text NOT NULL,
    "sessionId" text NOT NULL,
    "customerId" text,
    "tableId" text,
    phone text,
    "isActive" boolean DEFAULT true NOT NULL,
    "userAgent" text,
    "ipAddress" text,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "lastActivity" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    latitude double precision,
    longitude double precision
);


ALTER TABLE public.customer_sessions OWNER TO postgres;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id text NOT NULL,
    name text NOT NULL,
    email text,
    phone text,
    "phoneVerified" boolean DEFAULT false NOT NULL,
    "loyaltyPoints" integer DEFAULT 0 NOT NULL,
    "loyaltyTier" text DEFAULT 'BRONZE'::text NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[],
    notes text,
    "referralCode" text,
    "referredBy" text,
    "totalOrders" integer DEFAULT 0 NOT NULL,
    "totalSpent" numeric(10,2) DEFAULT 0 NOT NULL,
    "averageOrder" numeric(10,2) DEFAULT 0 NOT NULL,
    birthday timestamp(3) without time zone,
    preferences jsonb,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "lastVisit" timestamp(3) without time zone
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: desktop_releases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.desktop_releases (
    id text NOT NULL,
    version text NOT NULL,
    "releaseTag" text NOT NULL,
    published boolean DEFAULT false NOT NULL,
    "pubDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "windowsUrl" text,
    "windowsSignature" text,
    "macArmUrl" text,
    "macArmSignature" text,
    "macIntelUrl" text,
    "macIntelSignature" text,
    "linuxUrl" text,
    "linuxSignature" text,
    "releaseNotes" text NOT NULL,
    changelog text,
    "downloadCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.desktop_releases OWNER TO postgres;

--
-- Name: integration_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integration_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "integrationType" text NOT NULL,
    provider text NOT NULL,
    name text NOT NULL,
    config jsonb NOT NULL,
    "isEnabled" boolean DEFAULT false NOT NULL,
    "isConfigured" boolean DEFAULT false NOT NULL,
    "lastSyncedAt" timestamp(3) without time zone,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.integration_settings OWNER TO postgres;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    "paymentId" text,
    "invoiceNumber" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    tax numeric(10,2) DEFAULT 0 NOT NULL,
    total numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "periodStart" timestamp(3) without time zone NOT NULL,
    "periodEnd" timestamp(3) without time zone NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "paidAt" timestamp(3) without time zone,
    "voidedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    description text,
    notes text,
    "pdfUrl" text
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: loyalty_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.loyalty_transactions (
    id text NOT NULL,
    "customerId" text NOT NULL,
    type text NOT NULL,
    points integer NOT NULL,
    description text NOT NULL,
    "orderId" text,
    "orderNumber" text,
    "orderAmount" numeric(10,2),
    "referredCustomerId" text,
    "balanceBefore" integer NOT NULL,
    "balanceAfter" integer NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.loyalty_transactions OWNER TO postgres;

--
-- Name: modifier_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.modifier_groups (
    id text NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "selectionType" text DEFAULT 'SINGLE'::text NOT NULL,
    "minSelections" integer DEFAULT 0 NOT NULL,
    "maxSelections" integer,
    "isRequired" boolean DEFAULT false NOT NULL,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.modifier_groups OWNER TO postgres;

--
-- Name: modifiers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.modifiers (
    id text NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "priceAdjustment" numeric(10,2) DEFAULT 0 NOT NULL,
    "isAvailable" boolean DEFAULT true NOT NULL,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "groupId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.modifiers OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    type text NOT NULL,
    data jsonb,
    "userId" text,
    "tenantId" text NOT NULL,
    "isGlobal" boolean DEFAULT false NOT NULL,
    priority text DEFAULT 'NORMAL'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: order_item_modifiers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_item_modifiers (
    id text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    "priceAdjustment" numeric(10,2) NOT NULL,
    "orderItemId" text NOT NULL,
    "modifierId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.order_item_modifiers OWNER TO postgres;

--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id text NOT NULL,
    quantity integer NOT NULL,
    "unitPrice" numeric(10,2) NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    "modifierTotal" numeric(10,2) DEFAULT 0 NOT NULL,
    notes text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "orderId" text NOT NULL,
    "productId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id text NOT NULL,
    "orderNumber" text NOT NULL,
    type text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "totalAmount" numeric(10,2) NOT NULL,
    discount numeric(10,2) DEFAULT 0 NOT NULL,
    "finalAmount" numeric(10,2) NOT NULL,
    notes text,
    "customerName" text,
    "sessionId" text,
    "customerPhone" text,
    "requiresApproval" boolean DEFAULT false NOT NULL,
    "approvedAt" timestamp(3) without time zone,
    "tableId" text,
    "customerId" text,
    "userId" text,
    "approvedById" text,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "paidAt" timestamp(3) without time zone
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: page_views; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.page_views (
    id text NOT NULL,
    page text NOT NULL,
    path text NOT NULL,
    referrer text,
    country text,
    "countryCode" text,
    city text,
    region text,
    "sessionId" text,
    "userAgent" text,
    "ipHash" text,
    "deviceType" text,
    browser text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.page_views OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id text NOT NULL,
    amount numeric(10,2) NOT NULL,
    method text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "transactionId" text,
    notes text,
    "orderId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "idempotencyKey" text
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: pending_plan_changes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pending_plan_changes (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    "currentPlanId" text NOT NULL,
    "newPlanId" text NOT NULL,
    "newBillingCycle" text NOT NULL,
    "isUpgrade" boolean NOT NULL,
    "currentAmount" numeric(10,2) NOT NULL,
    "newAmount" numeric(10,2) NOT NULL,
    "prorationAmount" numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "paymentRequired" boolean DEFAULT true NOT NULL,
    "paymentStatus" text DEFAULT 'PENDING'::text NOT NULL,
    "paymentIntentId" text,
    "paymentProvider" text,
    "scheduledFor" timestamp(3) without time zone,
    "appliedAt" timestamp(3) without time zone,
    reason text,
    "failureReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.pending_plan_changes OWNER TO postgres;

--
-- Name: phone_verifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.phone_verifications (
    id text NOT NULL,
    phone text NOT NULL,
    code text NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "sessionId" text,
    "tenantId" text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    "maxAttempts" integer DEFAULT 3 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "verifiedAt" timestamp(3) without time zone
);


ALTER TABLE public.phone_verifications OWNER TO postgres;

--
-- Name: pos_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pos_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "enableTablelessMode" boolean DEFAULT false NOT NULL,
    "enableTwoStepCheckout" boolean DEFAULT false NOT NULL,
    "showProductImages" boolean DEFAULT true NOT NULL,
    "enableCustomerOrdering" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.pos_settings OWNER TO postgres;

--
-- Name: product_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_images (
    id text NOT NULL,
    url text NOT NULL,
    filename text NOT NULL,
    size integer NOT NULL,
    "mimeType" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_images OWNER TO postgres;

--
-- Name: product_modifier_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_modifier_groups (
    id text NOT NULL,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "productId" text NOT NULL,
    "groupId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_modifier_groups OWNER TO postgres;

--
-- Name: product_to_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_to_images (
    id text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "productId" text NOT NULL,
    "imageId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_to_images OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    image text,
    "isAvailable" boolean DEFAULT true NOT NULL,
    "stockTracked" boolean DEFAULT false NOT NULL,
    "currentStock" integer DEFAULT 0 NOT NULL,
    "categoryId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: public_reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.public_reviews (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    restaurant text,
    avatar text,
    rating integer NOT NULL,
    comment text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "approvedAt" timestamp(3) without time zone,
    country text,
    city text,
    "isVerified" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.public_reviews OWNER TO postgres;

--
-- Name: public_stats_cache; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.public_stats_cache (
    id text DEFAULT 'main'::text NOT NULL,
    "totalViews" integer DEFAULT 0 NOT NULL,
    "uniqueVisitors" integer DEFAULT 0 NOT NULL,
    "totalReviews" integer DEFAULT 0 NOT NULL,
    "averageRating" double precision DEFAULT 0 NOT NULL,
    "totalTenants" integer DEFAULT 0 NOT NULL,
    "countryDistribution" jsonb,
    "cityDistribution" jsonb,
    "viewsToday" integer DEFAULT 0 NOT NULL,
    "viewsThisWeek" integer DEFAULT 0 NOT NULL,
    "viewsThisMonth" integer DEFAULT 0 NOT NULL,
    "lastUpdated" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.public_stats_cache OWNER TO postgres;

--
-- Name: qr_menu_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qr_menu_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "primaryColor" text DEFAULT '#3B82F6'::text NOT NULL,
    "secondaryColor" text DEFAULT '#1F2937'::text NOT NULL,
    "backgroundColor" text DEFAULT '#F9FAFB'::text NOT NULL,
    "fontFamily" text DEFAULT 'Inter'::text NOT NULL,
    "logoUrl" text,
    "showRestaurantInfo" boolean DEFAULT true NOT NULL,
    "showPrices" boolean DEFAULT true NOT NULL,
    "showDescription" boolean DEFAULT true NOT NULL,
    "showImages" boolean DEFAULT true NOT NULL,
    "layoutStyle" text DEFAULT 'GRID'::text NOT NULL,
    "itemsPerRow" integer DEFAULT 2 NOT NULL,
    "enableTableQR" boolean DEFAULT true NOT NULL,
    "tableQRMessage" text DEFAULT 'Scan to view our menu'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.qr_menu_settings OWNER TO postgres;

--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_movements (
    id text NOT NULL,
    type text NOT NULL,
    quantity integer NOT NULL,
    reason text,
    notes text,
    "productId" text NOT NULL,
    "userId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.stock_movements OWNER TO postgres;

--
-- Name: subscription_payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscription_payments (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "paymentProvider" text NOT NULL,
    "stripePaymentIntentId" text,
    "paytrMerchantOid" text,
    "paytrPaymentToken" text,
    "paymentMethod" text,
    last4 text,
    "cardBrand" text,
    "failureCode" text,
    "failureMessage" text,
    "retryCount" integer DEFAULT 0 NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "refundedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.subscription_payments OWNER TO postgres;

--
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscription_plans (
    id text NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "monthlyPrice" numeric(10,2) NOT NULL,
    "yearlyPrice" numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "trialDays" integer DEFAULT 0 NOT NULL,
    "maxUsers" integer DEFAULT 1 NOT NULL,
    "maxTables" integer DEFAULT 5 NOT NULL,
    "maxProducts" integer DEFAULT 50 NOT NULL,
    "maxCategories" integer DEFAULT 10 NOT NULL,
    "maxMonthlyOrders" integer DEFAULT 100 NOT NULL,
    "advancedReports" boolean DEFAULT false NOT NULL,
    "multiLocation" boolean DEFAULT false NOT NULL,
    "customBranding" boolean DEFAULT false NOT NULL,
    "apiAccess" boolean DEFAULT false NOT NULL,
    "prioritySupport" boolean DEFAULT false NOT NULL,
    "inventoryTracking" boolean DEFAULT false NOT NULL,
    "kdsIntegration" boolean DEFAULT true NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "discountEndDate" timestamp(3) without time zone,
    "discountLabel" text,
    "discountPercentage" integer,
    "discountStartDate" timestamp(3) without time zone,
    "isDiscountActive" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.subscription_plans OWNER TO postgres;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscriptions (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "planId" text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "billingCycle" text NOT NULL,
    "paymentProvider" text NOT NULL,
    "startDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "currentPeriodStart" timestamp(3) without time zone NOT NULL,
    "currentPeriodEnd" timestamp(3) without time zone NOT NULL,
    "cancelledAt" timestamp(3) without time zone,
    "endedAt" timestamp(3) without time zone,
    "isTrialPeriod" boolean DEFAULT false NOT NULL,
    "trialStart" timestamp(3) without time zone,
    "trialEnd" timestamp(3) without time zone,
    "stripeSubscriptionId" text,
    "stripeCustomerId" text,
    "paytrMerchantOid" text,
    "paytrPaymentToken" text,
    "renewalLinkSentAt" timestamp(3) without time zone,
    "renewalLinkToken" text,
    "graceEndDate" timestamp(3) without time zone,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "autoRenew" boolean DEFAULT true NOT NULL,
    "cancelAtPeriodEnd" boolean DEFAULT false NOT NULL,
    "cancellationReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.subscriptions OWNER TO postgres;

--
-- Name: tables; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tables (
    id text NOT NULL,
    number text NOT NULL,
    capacity integer NOT NULL,
    section text,
    status text DEFAULT 'AVAILABLE'::text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.tables OWNER TO postgres;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    id text NOT NULL,
    name text NOT NULL,
    subdomain text,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "currentPlanId" text,
    "paymentRegion" text DEFAULT 'INTERNATIONAL'::text NOT NULL,
    "trialUsed" boolean DEFAULT false NOT NULL,
    "trialStartedAt" timestamp(3) without time zone,
    "trialEndsAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "closingTime" text DEFAULT '23:00'::text,
    currency text DEFAULT 'TRY'::text NOT NULL,
    "reportEmailEnabled" boolean DEFAULT false NOT NULL,
    "reportEmails" text[] DEFAULT ARRAY[]::text[],
    timezone text DEFAULT 'UTC'::text NOT NULL,
    latitude double precision,
    "locationRadius" integer DEFAULT 100 NOT NULL,
    longitude double precision
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: user_notification_reads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_notification_reads (
    id text NOT NULL,
    "notificationId" text NOT NULL,
    "userId" text NOT NULL,
    "readAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_notification_reads OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    role text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "emailVerificationCode" character varying(6),
    "emailVerificationCodeExpires" timestamp(3) without time zone,
    "resetToken" text,
    "resetTokenExpiry" timestamp(3) without time zone,
    avatar text,
    phone text,
    "lastLogin" timestamp(3) without time zone,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "appleId" text,
    "authProvider" text DEFAULT 'local'::text NOT NULL,
    "googleId" text
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: waiter_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.waiter_requests (
    id text NOT NULL,
    message text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "sessionId" text NOT NULL,
    "tableId" text NOT NULL,
    "acknowledgedAt" timestamp(3) without time zone,
    "acknowledgedById" text,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.waiter_requests OWNER TO postgres;

--
-- Name: z_reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.z_reports (
    id text NOT NULL,
    "reportNumber" text NOT NULL,
    "reportDate" timestamp(3) without time zone NOT NULL,
    "closingTime" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "closingType" text DEFAULT 'MANUAL'::text NOT NULL,
    "closedById" text NOT NULL,
    "branchName" text,
    "terminalId" text,
    "totalSales" numeric(10,2) NOT NULL,
    "totalOrders" integer NOT NULL,
    "totalDiscount" numeric(10,2) DEFAULT 0 NOT NULL,
    "totalRefunds" numeric(10,2) DEFAULT 0 NOT NULL,
    "netSales" numeric(10,2) NOT NULL,
    "dineInSales" numeric(10,2) DEFAULT 0 NOT NULL,
    "dineInOrders" integer DEFAULT 0 NOT NULL,
    "takeawaySales" numeric(10,2) DEFAULT 0 NOT NULL,
    "takeawayOrders" integer DEFAULT 0 NOT NULL,
    "deliverySales" numeric(10,2) DEFAULT 0 NOT NULL,
    "deliveryOrders" integer DEFAULT 0 NOT NULL,
    "cashPayments" numeric(10,2) DEFAULT 0 NOT NULL,
    "cashPaymentCount" integer DEFAULT 0 NOT NULL,
    "cardPayments" numeric(10,2) DEFAULT 0 NOT NULL,
    "cardPaymentCount" integer DEFAULT 0 NOT NULL,
    "digitalPayments" numeric(10,2) DEFAULT 0 NOT NULL,
    "digitalPaymentCount" integer DEFAULT 0 NOT NULL,
    "openingCash" numeric(10,2) NOT NULL,
    "expectedCash" numeric(10,2) NOT NULL,
    "countedCash" numeric(10,2) NOT NULL,
    "cashDifference" numeric(10,2) NOT NULL,
    "cashInOut" numeric(10,2) DEFAULT 0 NOT NULL,
    "cancelledOrders" integer DEFAULT 0 NOT NULL,
    "cancelledOrdersAmount" numeric(10,2) DEFAULT 0 NOT NULL,
    "refundedPayments" integer DEFAULT 0 NOT NULL,
    "refundedAmount" numeric(10,2) DEFAULT 0 NOT NULL,
    "staffPerformance" jsonb,
    "categoryBreakdown" jsonb,
    "topProducts" jsonb,
    "openChecks" integer DEFAULT 0 NOT NULL,
    "openChecksAmount" numeric(10,2) DEFAULT 0 NOT NULL,
    notes text,
    "systemGenerated" boolean DEFAULT false NOT NULL,
    "pdfExported" boolean DEFAULT false NOT NULL,
    "pdfUrl" text,
    "excelExported" boolean DEFAULT false NOT NULL,
    "excelUrl" text,
    "emailSent" boolean DEFAULT false NOT NULL,
    "emailSentAt" timestamp(3) without time zone,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "emailError" text,
    "emailRecipients" text[] DEFAULT ARRAY[]::text[]
);


ALTER TABLE public.z_reports OWNER TO postgres;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
19d9db19-defd-4d98-94a0-c5ce1d3f8c92	2159df5d97196f35accd8c41e4153578c6d879c28a2a1cf26c02044cdf140917	2026-01-06 23:47:49.409239+00	20250109_subscription_system		\N	2026-01-06 23:47:49.409239+00	0
d6bad309-d727-4088-8a18-3f603143274f	17e71428a51c85e62356b1e4a372684750cbc6487dbb12818dd785f5d839b55d	2026-01-06 23:47:54.322199+00	20251019101646_init		\N	2026-01-06 23:47:54.322199+00	0
6e1861ae-3fca-47ae-857d-019f89d10832	29df9f7d3a4da6e73be6d05a0a7f8a81a7895475a059b7910d47b7803a96c39f	2026-01-06 23:48:06.834139+00	20251202074317_add_spatial_mapping		\N	2026-01-06 23:48:06.834139+00	0
88f40b03-6e16-41ef-b181-da751c76cf3b	1b07d6403896e5097984c00276e5e3619904c239fff8c84921be906467e70645	2026-01-06 23:48:11.481877+00	20251229143800_add_discount_and_public_stats		\N	2026-01-06 23:48:11.481877+00	0
de53a287-7c1e-4449-affb-bd1e9d38f184	423a096a36518d9c0a4f65b1bde82aff9dff959911163a9fa27ee75b94104102	2026-01-06 23:48:15.7819+00	20260107_add_geolocation_fields		\N	2026-01-06 23:48:15.7819+00	0
9787782c-2ed8-4f09-b3d1-2f650eecdf8b	e98987d33226d6c57781560e30cfc2c4844f454bf29e8f547450fe7af0c88dfb	2026-01-09 07:44:15.761617+00	20260109_add_payment_idempotency_key	\N	\N	2026-01-09 07:44:15.710581+00	1
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_keys (id, "tenantId", name, key, "keyPrefix", scopes, "webhookUrl", "webhookEvents", "isActive", "expiresAt", "lastUsedAt", "usageCount", "ipWhitelist", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: bill_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bill_requests (id, status, "sessionId", "tableId", "acknowledgedAt", "acknowledgedById", "completedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: cash_drawer_movements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cash_drawer_movements (id, type, amount, reason, notes, "denominationBreakdown", "zReportId", "userId", "tenantId", "createdAt") FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, description, "displayOrder", "isActive", "tenantId", "createdAt", "updatedAt") FROM stdin;
c2fdd157-0daa-405c-8961-39bfefd501c3	Appetizers	Start your meal with our delicious starters	1	t	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.215	2025-12-08 20:34:33.215
ea231560-de53-4e33-a585-4439c1f6fbdc	Main Courses	Our signature main dishes	2	t	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.244	2025-12-08 20:34:33.244
462e3ab3-eb9e-4ded-958a-e20d75944198	Desserts	Sweet endings to your meal	3	t	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.255	2025-12-08 20:34:33.255
7e085adb-7c35-4374-9578-d7f1ecfdd612	Beverages	Refreshing drinks	4	t	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.271	2025-12-08 20:34:33.271
c22fca85-5682-4e3f-b9f8-df1123aa2f67	Hırdavat	Denem	1	t	6f066396-a840-4666-b849-33ec50ccc89c	2025-12-23 11:44:00.559	2025-12-23 11:44:00.559
55a6b787-dc61-48d8-83d3-e8bd75eaf18f	deneme		1	t	184f0210-b0ec-46fe-a276-db3c3b60bcc9	2025-12-25 15:15:38.932	2025-12-25 15:15:38.932
79a9a2c1-4981-4449-a218-4c09fd0e1f12	Ana yemek	Yemek	12	t	f919a93f-eb07-418a-b174-4e76d4f17940	2025-12-25 17:38:02.066	2025-12-25 17:38:02.066
365f97e1-f8d1-4425-95b2-4207c25a9e56	tatlı		1	t	1d3a29b6-1bea-4b64-ab42-7a86e246258b	2026-01-08 19:12:56.306	2026-01-08 19:12:56.306
\.


--
-- Data for Name: contact_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact_messages (id, name, email, phone, message, status, "adminNotes", "createdAt", "updatedAt") FROM stdin;
e13e9969-103d-4df3-a03c-6308a5a1aa14	T2mle100leş	kendinibilmeznero@gmail.com		Merhaba,\n\nÖylesine.\n\nTşk.	NEW	\N	2025-12-25 19:38:05.897	2025-12-25 19:38:05.897
\.


--
-- Data for Name: customer_referrals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_referrals (id, "referrerId", "referredId", "referralCode", status, "referrerReward", "referredReward", "rewardedAt", "createdAt", "completedAt") FROM stdin;
\.


--
-- Data for Name: customer_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_sessions (id, "sessionId", "customerId", "tableId", phone, "isActive", "userAgent", "ipAddress", "expiresAt", "lastActivity", "tenantId", "createdAt", "updatedAt", latitude, longitude) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (id, name, email, phone, "phoneVerified", "loyaltyPoints", "loyaltyTier", tags, notes, "referralCode", "referredBy", "totalOrders", "totalSpent", "averageOrder", birthday, preferences, "tenantId", "createdAt", "updatedAt", "lastVisit") FROM stdin;
bafafadc-42ad-44c9-97bf-68632b479b54	Customer 5060687100	\N	5060687100	f	0	BRONZE	{}	\N	\N	\N	1	1.00	1.00	\N	\N	6f066396-a840-4666-b849-33ec50ccc89c	2025-12-23 11:46:26.033	2025-12-23 11:46:26.058	2025-12-23 11:46:26.057
\.


--
-- Data for Name: desktop_releases; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.desktop_releases (id, version, "releaseTag", published, "pubDate", "windowsUrl", "windowsSignature", "macArmUrl", "macArmSignature", "macIntelUrl", "macIntelSignature", "linuxUrl", "linuxSignature", "releaseNotes", changelog, "downloadCount", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: integration_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.integration_settings (id, "tenantId", "integrationType", provider, name, config, "isEnabled", "isConfigured", "lastSyncedAt", notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (id, "subscriptionId", "paymentId", "invoiceNumber", status, subtotal, tax, total, currency, "periodStart", "periodEnd", "dueDate", "paidAt", "voidedAt", "createdAt", "updatedAt", description, notes, "pdfUrl") FROM stdin;
\.


--
-- Data for Name: loyalty_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.loyalty_transactions (id, "customerId", type, points, description, "orderId", "orderNumber", "orderAmount", "referredCustomerId", "balanceBefore", "balanceAfter", metadata, "createdAt") FROM stdin;
\.


--
-- Data for Name: modifier_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.modifier_groups (id, name, "displayName", description, "selectionType", "minSelections", "maxSelections", "isRequired", "displayOrder", "isActive", "tenantId", "createdAt", "updatedAt") FROM stdin;
a2e1045b-3709-4cd9-b08c-2aba30748a82	soslar	sos		MULTIPLE	1	\N	t	0	t	1d3a29b6-1bea-4b64-ab42-7a86e246258b	2026-01-06 23:57:50.836	2026-01-06 23:57:50.836
\.


--
-- Data for Name: modifiers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.modifiers (id, name, "displayName", description, "priceAdjustment", "isAvailable", "displayOrder", "groupId", "tenantId", "createdAt", "updatedAt") FROM stdin;
bbc96d61-19e8-4293-85b4-0c9379b0ab18	ketçap	ketçap		5.00	t	0	a2e1045b-3709-4cd9-b08c-2aba30748a82	1d3a29b6-1bea-4b64-ab42-7a86e246258b	2026-01-06 23:58:18.566	2026-01-06 23:58:18.566
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, title, message, type, data, "userId", "tenantId", "isGlobal", priority, "createdAt", "expiresAt") FROM stdin;
1fb016e7-953a-43da-8145-59aa69910a70	E-posta Doğrulaması Gereklidir	E-posta adresinize gönderilen 6 haneli doğrulama kodunu kullanarak hesabınızı doğrulamanız gerekmektedir. Lütfen e-posta kutunuzu kontrol ediniz.	WARNING	{"action": "EMAIL_VERIFICATION_REQUIRED", "expiresAt": "2026-01-07T00:49:54.332Z"}	8f4f118b-9979-44b5-9e36-463ca0391cc2	1d3a29b6-1bea-4b64-ab42-7a86e246258b	f	NORMAL	2026-01-06 23:49:59.267	2026-01-07 00:49:54.332
\.


--
-- Data for Name: order_item_modifiers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_item_modifiers (id, quantity, "priceAdjustment", "orderItemId", "modifierId", "createdAt") FROM stdin;
e8ef6e29-2126-456f-839a-571fcf2b404f	1	5.00	ebf15077-c926-41ce-9c1a-908297e2aaa9	bbc96d61-19e8-4293-85b4-0c9379b0ab18	2026-01-09 06:47:16.934
6d14f7df-8c36-4410-8db6-cd855aba1663	1	5.00	d28ee24c-d545-4f36-a129-021e01899e2a	bbc96d61-19e8-4293-85b4-0c9379b0ab18	2026-01-09 06:47:57.596
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, quantity, "unitPrice", subtotal, "modifierTotal", notes, status, "orderId", "productId", "createdAt", "updatedAt") FROM stdin;
fe813667-99ef-4b7f-be53-0952ad9270de	1	15.99	15.99	0.00	\N	PENDING	a39fc439-6c89-4ffc-a49b-a0ff349b7f61	ac73be81-5e8d-4f57-9e5c-c3be63e15063	2025-12-08 20:42:29.417	2025-12-08 20:42:29.417
af5f0e2e-018e-4303-8c17-a24e9054f8ff	1	8.99	8.99	0.00	\N	PENDING	a39fc439-6c89-4ffc-a49b-a0ff349b7f61	8b69ecf5-7f14-48ff-9f80-e41ddc947f70	2025-12-08 20:42:29.417	2025-12-08 20:42:29.417
63deb6c1-f53b-49a3-a18f-c2d13da4ceb6	1	8.99	8.99	0.00	\N	PENDING	e0f4e3dc-71b6-410a-a199-5bf8dbff0e8e	8b69ecf5-7f14-48ff-9f80-e41ddc947f70	2025-12-08 20:47:26.792	2025-12-08 20:47:26.792
f0218c53-7177-47b1-848e-debc31f6a742	1	5.99	5.99	0.00	\N	PENDING	f2257d18-c838-458a-9b6e-5c380da88d85	a9e459af-4060-4adf-a567-d73e97503c6c	2025-12-08 20:57:47.098	2025-12-08 20:57:47.098
89cf3220-090d-4131-9b1f-09593a73bfaa	1	15.99	15.99	0.00	\N	PENDING	f2257d18-c838-458a-9b6e-5c380da88d85	ac73be81-5e8d-4f57-9e5c-c3be63e15063	2025-12-08 20:57:47.098	2025-12-08 20:57:47.098
4c181047-0848-42b3-bfc7-f26cd82059a8	1	18.99	18.99	0.00	\N	PENDING	f2257d18-c838-458a-9b6e-5c380da88d85	e4841733-2a2e-46ef-9870-cbc2ea9d93d0	2025-12-08 20:57:47.098	2025-12-08 20:57:47.098
65f6381f-3762-4c1a-98cf-5dad6c4140a8	1	1.00	1.00	0.00	\N	PENDING	288e6c99-e946-4baf-93b5-f35b0083c2be	3b03c283-ae46-4afe-ab49-d529cd7f21c2	2025-12-23 11:46:22.252	2025-12-23 11:46:22.252
d88074a1-2abf-4621-96f9-566a9196ac5c	2	5.00	10.00	0.00	\N	PENDING	e050d48c-272f-43dd-9aaf-15fd94cc51e2	962fc2e5-d259-4fd9-a9a9-6e8c802a086f	2025-12-25 17:42:07.552	2025-12-25 17:42:07.552
debe1f6a-4d5f-4aa3-9c77-85ce00040a2f	3	1.00	3.00	0.00	\N	PENDING	1470d6fa-f465-47ce-8fb8-ba0ded6a512a	3b03c283-ae46-4afe-ab49-d529cd7f21c2	2025-12-26 17:24:28.937	2025-12-26 17:24:28.937
289031e1-d7f8-47fc-95e5-c93d35314cc0	2	1.00	2.00	0.00	\N	PENDING	319629e1-0af3-4a7e-bb22-a1e8e3fb0f81	3b03c283-ae46-4afe-ab49-d529cd7f21c2	2025-12-26 17:27:47.471	2025-12-26 17:27:47.471
c987862e-ad2f-47c3-84cc-178ad0efce21	2	123.00	246.00	0.00	\N	PENDING	9d22f44b-2a6b-4b1b-ab27-fdcee910f250	6daa94c5-0890-47be-9e64-5339183cfe86	2026-01-08 19:22:41.136	2026-01-08 19:22:41.136
e55a5156-9e48-4a31-90dd-a13c6b38a5a2	2	123.00	246.00	0.00	\N	PENDING	ac4efcc6-f6b1-4e3d-835c-4b5d57ed8c3d	6daa94c5-0890-47be-9e64-5339183cfe86	2026-01-08 19:32:32.583	2026-01-08 19:32:32.583
90034f63-97a4-49ef-a576-b8b34565f0ff	1	123.00	123.00	0.00	\N	PENDING	730ca45f-0771-46fa-bee2-3dfe5b781781	6daa94c5-0890-47be-9e64-5339183cfe86	2026-01-09 06:45:13.775	2026-01-09 06:45:13.775
ebf15077-c926-41ce-9c1a-908297e2aaa9	2	123.00	256.00	5.00	\N	PENDING	c3a9ccf0-0493-49f0-a26e-43608ef9971c	6daa94c5-0890-47be-9e64-5339183cfe86	2026-01-09 06:47:16.934	2026-01-09 06:47:16.934
d28ee24c-d545-4f36-a129-021e01899e2a	1	123.00	128.00	5.00	\N	PENDING	c9078de3-986a-48a3-9cf5-6f5e88da072d	6daa94c5-0890-47be-9e64-5339183cfe86	2026-01-09 06:47:57.596	2026-01-09 06:47:57.596
0e12d26b-3b3a-4763-ae6b-481a3f403a38	2	123.00	246.00	0.00	\N	PENDING	206e9833-98fb-4218-92fe-eca4d35f1820	6daa94c5-0890-47be-9e64-5339183cfe86	2026-01-09 12:55:54.493	2026-01-09 12:55:54.493
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, "orderNumber", type, status, "totalAmount", discount, "finalAmount", notes, "customerName", "sessionId", "customerPhone", "requiresApproval", "approvedAt", "tableId", "customerId", "userId", "approvedById", "tenantId", "createdAt", "updatedAt", "paidAt") FROM stdin;
ac4efcc6-f6b1-4e3d-835c-4b5d57ed8c3d	ORD-20260108-0002	DINE_IN	PENDING	246.00	0.00	246.00	\N	\N	164fd7ad-cbd6-47d0-ba0d-ba1677c1efed	\N	f	2026-01-08 22:08:01.435	6127c144-ea19-4546-a4a5-0044bf48f1e3	\N	\N	8f4f118b-9979-44b5-9e36-463ca0391cc2	1d3a29b6-1bea-4b64-ab42-7a86e246258b	2026-01-08 19:32:32.583	2026-01-08 22:08:01.438	\N
730ca45f-0771-46fa-bee2-3dfe5b781781	ORD-1767941113772-734	DINE_IN	PENDING	123.00	0.00	123.00	\N	\N	\N	\N	f	\N	6127c144-ea19-4546-a4a5-0044bf48f1e3	\N	8f4f118b-9979-44b5-9e36-463ca0391cc2	\N	1d3a29b6-1bea-4b64-ab42-7a86e246258b	2026-01-09 06:45:13.775	2026-01-09 06:45:13.775	\N
c9078de3-986a-48a3-9cf5-6f5e88da072d	ORD-20260109-0736	DINE_IN	PENDING	128.00	0.00	128.00	\N	\N	164fd7ad-cbd6-47d0-ba0d-ba1677c1efed	\N	f	2026-01-09 06:48:03.981	6127c144-ea19-4546-a4a5-0044bf48f1e3	\N	\N	8f4f118b-9979-44b5-9e36-463ca0391cc2	1d3a29b6-1bea-4b64-ab42-7a86e246258b	2026-01-09 06:47:57.596	2026-01-09 06:48:03.983	\N
a39fc439-6c89-4ffc-a49b-a0ff349b7f61	ORD-1765226534798-229	DINE_IN	PREPARING	24.98	0.00	24.98	\N	\N	\N	\N	f	\N	f5ac50c5-9a11-4f94-b017-ab5498cc3e41	\N	0630de68-08fc-46e9-bf80-36cbcb447182	\N	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:42:14.803	2025-12-08 20:42:37.091	\N
e0f4e3dc-71b6-410a-a199-5bf8dbff0e8e	ORD-20251208-0230	DINE_IN	PENDING	8.99	0.00	8.99	\N	\N	4164be4c-ca5b-4d91-8a07-b8a4607fdef2	\N	f	2025-12-08 20:56:21.231	f5ac50c5-9a11-4f94-b017-ab5498cc3e41	\N	\N	0630de68-08fc-46e9-bf80-36cbcb447182	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:47:26.792	2025-12-08 20:56:21.233	\N
f2257d18-c838-458a-9b6e-5c380da88d85	ORD-20251208-0231	DINE_IN	PENDING	40.97	0.00	40.97	\N	\N	4164be4c-ca5b-4d91-8a07-b8a4607fdef2	\N	f	2025-12-08 20:57:34.305	edd045bc-3785-4084-8b01-9b8356c85e94	\N	\N	0630de68-08fc-46e9-bf80-36cbcb447182	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:57:01.239	2025-12-08 20:57:47.098	\N
288e6c99-e946-4baf-93b5-f35b0083c2be	ORD-1766490382249-077	DINE_IN	PAID	1.00	0.00	1.00	\N	\N	\N	5060687100	f	\N	fb9460d5-9602-4d77-8406-be74ef67fad3	bafafadc-42ad-44c9-97bf-68632b479b54	814b878e-8f35-44b0-b33d-7c22f1db31ec	\N	6f066396-a840-4666-b849-33ec50ccc89c	2025-12-23 11:46:22.252	2025-12-23 11:46:26.044	2025-12-23 11:46:26.043
e050d48c-272f-43dd-9aaf-15fd94cc51e2	ORD-20251225-0001	DINE_IN	PAID	10.00	0.00	10.00	\N	\N	b36be573-2631-4325-ab64-7b1347b27062	\N	f	2025-12-25 17:43:16.615	c39958cf-4130-4686-b1a4-412d45852f41	\N	\N	e2fce0ef-0b70-46f7-8b1d-18275fdc1c0d	f919a93f-eb07-418a-b174-4e76d4f17940	2025-12-25 17:42:07.552	2025-12-25 17:44:29.242	2025-12-25 17:44:29.24
1470d6fa-f465-47ce-8fb8-ba0ded6a512a	ORD-1766769868934-610	DINE_IN	PAID	3.00	0.00	3.00	\N	\N	\N	\N	f	\N	fb9460d5-9602-4d77-8406-be74ef67fad3	\N	814b878e-8f35-44b0-b33d-7c22f1db31ec	\N	6f066396-a840-4666-b849-33ec50ccc89c	2025-12-26 17:24:28.937	2025-12-26 17:25:01.553	2025-12-26 17:25:01.551
319629e1-0af3-4a7e-bb22-a1e8e3fb0f81	ORD-20251226-0611	DINE_IN	PENDING_APPROVAL	2.00	0.00	2.00	\N	\N	b849aa50-3538-4cfb-9f82-4f751f57c107	\N	t	\N	fb9460d5-9602-4d77-8406-be74ef67fad3	\N	\N	\N	6f066396-a840-4666-b849-33ec50ccc89c	2025-12-26 17:27:47.471	2025-12-26 17:27:47.471	\N
9d22f44b-2a6b-4b1b-ab27-fdcee910f250	ORD-20260108-0001	DINE_IN	PENDING	246.00	0.00	246.00	\N	\N	164fd7ad-cbd6-47d0-ba0d-ba1677c1efed	\N	f	2026-01-08 19:22:50.906	6127c144-ea19-4546-a4a5-0044bf48f1e3	\N	\N	8f4f118b-9979-44b5-9e36-463ca0391cc2	1d3a29b6-1bea-4b64-ab42-7a86e246258b	2026-01-08 19:22:41.136	2026-01-08 19:22:50.908	\N
c3a9ccf0-0493-49f0-a26e-43608ef9971c	ORD-20260109-0735	DINE_IN	PENDING	256.00	0.00	256.00	\N	\N	164fd7ad-cbd6-47d0-ba0d-ba1677c1efed	\N	f	2026-01-09 12:55:45.355	6127c144-ea19-4546-a4a5-0044bf48f1e3	\N	\N	8f4f118b-9979-44b5-9e36-463ca0391cc2	1d3a29b6-1bea-4b64-ab42-7a86e246258b	2026-01-09 06:47:16.934	2026-01-09 12:55:45.362	\N
206e9833-98fb-4218-92fe-eca4d35f1820	ORD-1767942158773-570	DINE_IN	PENDING	246.00	0.00	246.00	\N	\N	\N	\N	f	\N	6127c144-ea19-4546-a4a5-0044bf48f1e3	\N	8f4f118b-9979-44b5-9e36-463ca0391cc2	\N	1d3a29b6-1bea-4b64-ab42-7a86e246258b	2026-01-09 07:02:38.776	2026-01-09 12:55:54.493	\N
\.


--
-- Data for Name: page_views; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.page_views (id, page, path, referrer, country, "countryCode", city, region, "sessionId", "userAgent", "ipHash", "deviceType", browser, "createdAt") FROM stdin;
ac11c80d-48ac-41e4-9725-7b0c368fea1d	landing	&#x2F;	\N	\N	\N	\N	\N	b6636448-85b1-4c0d-9d51-81f29a29c1c2	Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Mobile/15E148 Safari/604.1	fb6bcc6b9a90cdeea5d75fe26f53c9e1	mobile	Safari	2026-01-05 02:34:25.677
13799ed5-dc6d-41c9-b7e4-2880f5381ef4	landing	&#x2F;	\N	\N	\N	\N	\N	965a20b0-fb2b-4871-b6e8-16aa80d25467	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.3	fb6bcc6b9a90cdeea5d75fe26f53c9e1	desktop	Chrome	2026-01-05 02:49:23.855
f4b7210f-12ea-4a82-8938-497395987acb	landing	&#x2F;	\N	\N	\N	\N	\N	8ead7214-fb81-4ba0-be5c-248eca5bb33b	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 OPR/125.0.0.0	fb6bcc6b9a90cdeea5d75fe26f53c9e1	desktop	Chrome	2026-01-06 07:26:18.362
3ee77848-e193-4ae0-ac83-8104931a1e5d	landing	&#x2F;	\N	\N	\N	\N	\N	bfa7a7a9-e40c-4bc2-9404-1bca0cdc932f	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 OPR/125.0.0.0	fb6bcc6b9a90cdeea5d75fe26f53c9e1	desktop	Chrome	2026-01-06 08:42:38.425
c9c96f42-17b8-4452-ace6-ea470bf3b48e	landing	&#x2F;	\N	\N	\N	\N	\N	79539853-58b3-4ba3-b776-15eb25dc1d64	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 OPR/125.0.0.0	fb6bcc6b9a90cdeea5d75fe26f53c9e1	desktop	Chrome	2026-01-06 20:20:34.839
28c8f3f4-d302-4a0a-8c0e-9d090df69aea	landing	&#x2F;	\N	\N	\N	\N	\N	11bd5a07-9245-4d00-a56b-62bd37ea6c45	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 OPR/125.0.0.0	fb6bcc6b9a90cdeea5d75fe26f53c9e1	desktop	Chrome	2026-01-06 23:37:43.222
e3d171d1-26ab-4a55-86de-92c03208446f	landing	&#x2F;	\N	\N	\N	\N	\N	3d7e3b92-25dc-4c9c-b056-31068ea7c8fe	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 OPR/125.0.0.0	fb6bcc6b9a90cdeea5d75fe26f53c9e1	desktop	Chrome	2026-01-06 23:49:18.007
67189e4d-2ae6-4a14-9ee5-81da08689434	landing	&#x2F;	\N	\N	\N	\N	\N	76c34f2d-a726-4f8a-bbc8-6f4c18f4e764	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 OPR/125.0.0.0	fb6bcc6b9a90cdeea5d75fe26f53c9e1	desktop	Chrome	2026-01-07 16:16:45.765
0675ee6f-ab87-4091-900a-a79fc6112e29	landing	&#x2F;	\N	\N	\N	\N	\N	2e869f4b-27df-4151-9b6a-d11119b0bf8d	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 OPR/125.0.0.0	fb6bcc6b9a90cdeea5d75fe26f53c9e1	desktop	Chrome	2026-01-07 16:23:29.435
56109954-ee62-4559-95da-152a5dd5e635	landing	&#x2F;	\N	\N	\N	\N	\N	8d31a801-8c42-4e5d-8683-55bb73f94b1a	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 OPR/125.0.0.0	fb6bcc6b9a90cdeea5d75fe26f53c9e1	desktop	Chrome	2026-01-07 16:34:00.324
d779b85d-1854-4de5-a463-300dd095a9e8	landing	&#x2F;	\N	\N	\N	\N	\N	db98ddef-6ef2-4d9b-9a73-3f3351fc33e8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 OPR/125.0.0.0	fb6bcc6b9a90cdeea5d75fe26f53c9e1	desktop	Chrome	2026-01-08 19:03:12.366
e2448fb3-d623-4e3e-a4e6-2bdda90093df	landing	&#x2F;	\N	\N	\N	\N	\N	db98ddef-6ef2-4d9b-9a73-3f3351fc33e8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 OPR/125.0.0.0	fb6bcc6b9a90cdeea5d75fe26f53c9e1	desktop	Chrome	2026-01-08 19:10:14.767
e4ccfb6a-86e8-463b-aa5d-168c097c8d48	landing	&#x2F;	\N	\N	\N	\N	\N	d8c28ca0-e630-4c39-8177-8eb96a6fd306	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 OPR/125.0.0.0	fb6bcc6b9a90cdeea5d75fe26f53c9e1	desktop	Chrome	2026-01-08 20:55:42.362
711c57fe-87d3-441c-a62a-14eeb5b4075a	landing	&#x2F;	\N	\N	\N	\N	\N	bc16d7ed-e238-46a0-9f3d-2ccc4b3af893	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 OPR/125.0.0.0	fb6bcc6b9a90cdeea5d75fe26f53c9e1	desktop	Chrome	2026-01-08 23:07:15.247
54d3bccc-3b3d-4b53-8a68-811119daea2b	landing	&#x2F;	\N	\N	\N	\N	\N	76e4db25-af1e-4769-bf08-622dca2b4a0a	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 OPR/125.0.0.0	fb6bcc6b9a90cdeea5d75fe26f53c9e1	desktop	Chrome	2026-01-08 23:15:30.646
6edef739-13ff-45e3-92f1-1bcea84b4c32	landing	&#x2F;	\N	\N	\N	\N	\N	62a82d05-df52-49c8-9eed-a710d4d33b25	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	fb6bcc6b9a90cdeea5d75fe26f53c9e1	desktop	Chrome	2026-01-09 07:35:51.48
2a1ef73d-4c3d-4cab-8f34-aea7010d4b6c	landing	&#x2F;	\N	\N	\N	\N	\N	57b65a2b-b370-457f-8c66-ec97b063741f	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 OPR/125.0.0.0	fb6bcc6b9a90cdeea5d75fe26f53c9e1	desktop	Chrome	2026-01-09 14:32:46.008
6d109be2-1145-4bf4-bf5f-981a7b878600	landing	&#x2F;	\N	\N	\N	\N	\N	bda9372c-3e62-4bcc-8f8d-a46285c5a8a3	Mozilla/5.0 (Linux; Android 13; SM-G981B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	fb6bcc6b9a90cdeea5d75fe26f53c9e1	mobile	Chrome	2026-01-09 14:33:53.975
6ef916e0-24d5-4bbd-bab2-f101c8dbb742	landing	&#x2F;	\N	\N	\N	\N	\N	bda9372c-3e62-4bcc-8f8d-a46285c5a8a3	Mozilla/5.0 (Linux; Android 13; SM-G981B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	fb6bcc6b9a90cdeea5d75fe26f53c9e1	mobile	Chrome	2026-01-09 15:14:37.82
cfee78a6-843d-4fff-8823-0a5821f17662	landing	&#x2F;	\N	\N	\N	\N	\N	8c838801-6ed4-4ca7-aab7-7db01e1aa2a8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 OPR/125.0.0.0	fb6bcc6b9a90cdeea5d75fe26f53c9e1	desktop	Chrome	2026-01-09 18:28:31.24
01624fb8-a5b9-4b72-a87c-4757f5ff3b1b	landing	&#x2F;	\N	\N	\N	\N	\N	8c838801-6ed4-4ca7-aab7-7db01e1aa2a8	Mozilla/5.0 (Linux; Android 13; SM-G981B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	fb6bcc6b9a90cdeea5d75fe26f53c9e1	mobile	Chrome	2026-01-09 18:29:00.061
aa17aba5-89f9-4086-a727-c4d257c2fc1b	landing	&#x2F;	\N	\N	\N	\N	\N	8c838801-6ed4-4ca7-aab7-7db01e1aa2a8	Mozilla/5.0 (Linux; Android 13; SM-G981B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	fb6bcc6b9a90cdeea5d75fe26f53c9e1	mobile	Chrome	2026-01-09 18:29:06.213
e9a44aca-111d-4b4f-b4ff-63dab97f98af	landing	&#x2F;	\N	\N	\N	\N	\N	8c838801-6ed4-4ca7-aab7-7db01e1aa2a8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 OPR/125.0.0.0	fb6bcc6b9a90cdeea5d75fe26f53c9e1	desktop	Chrome	2026-01-09 18:36:52.03
cacdab70-4f14-4897-9711-649e9eb6b521	landing	&#x2F;	\N	\N	\N	\N	\N	8c838801-6ed4-4ca7-aab7-7db01e1aa2a8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 OPR/125.0.0.0	fb6bcc6b9a90cdeea5d75fe26f53c9e1	desktop	Chrome	2026-01-09 18:43:54.69
8c0013cb-71e4-4c77-b927-62c460603017	landing	&#x2F;	\N	\N	\N	\N	\N	8c838801-6ed4-4ca7-aab7-7db01e1aa2a8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 OPR/125.0.0.0	fb6bcc6b9a90cdeea5d75fe26f53c9e1	desktop	Chrome	2026-01-09 19:12:36.75
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, amount, method, status, "transactionId", notes, "orderId", "createdAt", "paidAt", "idempotencyKey") FROM stdin;
b160e240-99c6-4d12-a872-f09f3438b6e5	1.00	CASH	COMPLETED	\N	\N	288e6c99-e946-4baf-93b5-f35b0083c2be	2025-12-23 11:46:26.008	2025-12-23 11:46:26.006	\N
7aa9a44e-d54e-43b3-9772-d718101cadf4	10.00	CASH	COMPLETED	\N	\N	e050d48c-272f-43dd-9aaf-15fd94cc51e2	2025-12-25 17:44:29.226	2025-12-25 17:44:29.223	\N
13201d4b-d6ca-492f-b06a-3ea84c4e8e2e	3.00	CASH	COMPLETED	\N	\N	1470d6fa-f465-47ce-8fb8-ba0ded6a512a	2025-12-26 17:25:01.528	2025-12-26 17:25:01.525	\N
\.


--
-- Data for Name: pending_plan_changes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pending_plan_changes (id, "subscriptionId", "currentPlanId", "newPlanId", "newBillingCycle", "isUpgrade", "currentAmount", "newAmount", "prorationAmount", currency, "paymentRequired", "paymentStatus", "paymentIntentId", "paymentProvider", "scheduledFor", "appliedAt", reason, "failureReason", "createdAt", "updatedAt") FROM stdin;
2d5250d7-31ab-4ee3-8aca-7fc87a31e8d0	08bf4634-cd42-41e1-a3e4-998a2257d3ff	9f80ae2e-6ec2-4cd3-b053-6560bc939c87	b7b653c0-8402-46f3-91ad-a616cf4e23eb	MONTHLY	t	0.00	79.99	79.99	USD	t	EXPIRED	\N	STRIPE	\N	\N	\N	Manually expired - cleanup for bug fix	2025-12-23 10:31:42.671	2025-12-23 10:31:42.671
e901c90c-6785-4954-8873-98cd5732bd1d	50b97567-d86f-4159-b0e6-cf9ccafc69b0	9f80ae2e-6ec2-4cd3-b053-6560bc939c87	adf03da7-9a61-41ce-a6aa-0d64af892a06	MONTHLY	t	0.00	29.99	29.97	USD	t	EXPIRED	\N	STRIPE	\N	\N	\N	Manually expired - cleanup for bug fix	2025-12-25 20:22:00.223	2025-12-25 20:22:00.223
7f025729-c842-4b3d-b23e-fb90063c43ed	c2f17883-c6b7-4adb-8bfb-e28304f64d4f	9f80ae2e-6ec2-4cd3-b053-6560bc939c87	adf03da7-9a61-41ce-a6aa-0d64af892a06	MONTHLY	t	0.00	29.99	29.99	USD	t	EXPIRED	\N	STRIPE	\N	\N	\N	Manually expired - cleanup for bug fix	2025-12-26 06:03:38.046	2025-12-26 06:03:38.046
a45eb9cf-0ae4-4d57-993e-4e6a0e6ec91d	d7237827-c91c-4fab-a3d5-633b9cb9a42e	9f80ae2e-6ec2-4cd3-b053-6560bc939c87	adf03da7-9a61-41ce-a6aa-0d64af892a06	MONTHLY	t	0.00	29.99	29.97	USD	t	EXPIRED	\N	STRIPE	\N	\N	\N	Manually expired - cleanup for bug fix	2026-01-09 18:44:09.142	2026-01-09 18:44:09.142
365a33d3-fd07-4e02-ae4c-aabb84ff05e8	d7237827-c91c-4fab-a3d5-633b9cb9a42e	9f80ae2e-6ec2-4cd3-b053-6560bc939c87	adf03da7-9a61-41ce-a6aa-0d64af892a06	MONTHLY	t	0.00	29.99	29.97	USD	t	PENDING	\N	STRIPE	\N	\N	\N	\N	2026-01-09 19:38:09.888	2026-01-09 19:38:09.888
\.


--
-- Data for Name: phone_verifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.phone_verifications (id, phone, code, verified, "expiresAt", "sessionId", "tenantId", attempts, "maxAttempts", "createdAt", "verifiedAt") FROM stdin;
\.


--
-- Data for Name: pos_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pos_settings (id, "tenantId", "enableTablelessMode", "enableTwoStepCheckout", "showProductImages", "enableCustomerOrdering", "createdAt", "updatedAt") FROM stdin;
43b55030-238f-4ca1-85a5-aceb2668673f	ef685100-b2a0-450d-a88f-345b64371b3d	f	t	t	f	2025-12-08 20:42:01.286	2025-12-08 20:58:08.76
fc1ce0a0-1ae3-43f0-84ab-5cd842354301	184f0210-b0ec-46fe-a276-db3c3b60bcc9	f	t	t	t	2025-12-23 10:28:12.592	2025-12-23 10:28:12.592
bf500089-80f5-4028-9a8f-c143af78ec8b	6f066396-a840-4666-b849-33ec50ccc89c	f	t	t	t	2025-12-23 11:21:46.586	2025-12-23 11:21:46.586
47733e84-ef40-45b3-ae9c-3a99c5cc1fdf	f919a93f-eb07-418a-b174-4e76d4f17940	f	t	t	t	2025-12-25 17:17:47.077	2025-12-25 17:17:47.077
017e5580-bbf3-40e9-a64a-18bef32c55f2	1d3a29b6-1bea-4b64-ab42-7a86e246258b	f	t	t	t	2026-01-06 23:51:21.913	2026-01-06 23:51:21.913
\.


--
-- Data for Name: product_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_images (id, url, filename, size, "mimeType", "tenantId", "createdAt") FROM stdin;
2ca2c9fa-943c-4e50-82dd-44e5b3dc7bbf	https://staging.hummytummy.com/uploads/products/ef685100-b2a0-450d-a88f-345b64371b3d/e1869a53-67c9-4b6a-ab12-6d9977991d00.png	ChatGPT Image Oct 17, 2025, 12_00_56 AM_nobg.png	69039	image/png	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 21:05:02.493
6b24f921-bd92-4ea6-8403-1db3f9973ef6	https://staging.hummytummy.com/uploads/products/6f066396-a840-4666-b849-33ec50ccc89c/e124a801-73d9-4022-875c-f1c280ced075.jpeg	IMG_1384.jpeg	215561	image/jpeg	6f066396-a840-4666-b849-33ec50ccc89c	2025-12-23 11:43:34.223
c2ef3189-c67f-4a14-bd96-ae98d315ccfa	https://staging.hummytummy.com/uploads/products/f919a93f-eb07-418a-b174-4e76d4f17940/25d643a8-10e6-457b-98eb-a60e034c1b2d.jpeg	4B4D07A4-50BE-4AA3-974A-235F519665A4.jpeg	99985	image/jpeg	f919a93f-eb07-418a-b174-4e76d4f17940	2025-12-25 17:39:05.097
6b9570cb-69d8-4e82-b79e-22b2ac1d7014	https://staging.hummytummy.com/uploads/products/6f066396-a840-4666-b849-33ec50ccc89c/e31b7941-b857-49ff-b231-679adc0b7318.png	IMG_1435_nobg.png	44760	image/png	6f066396-a840-4666-b849-33ec50ccc89c	2025-12-26 17:25:51.697
fbb40d7e-bb37-491b-b487-c19b1795cd9c	https://hummytummy.com/uploads/products/1d3a29b6-1bea-4b64-ab42-7a86e246258b/4b9fa2f4-7620-4d0a-b2ce-18b1847f4f1a.webp	images (1).webp	93173	image/webp	1d3a29b6-1bea-4b64-ab42-7a86e246258b	2026-01-08 19:12:40.314
\.


--
-- Data for Name: product_modifier_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_modifier_groups (id, "displayOrder", "productId", "groupId", "createdAt") FROM stdin;
fb2a9020-8a63-4f01-8db1-9ed8de1f7921	0	6daa94c5-0890-47be-9e64-5339183cfe86	a2e1045b-3709-4cd9-b08c-2aba30748a82	2026-01-08 19:13:13.721
\.


--
-- Data for Name: product_to_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_to_images (id, "order", "productId", "imageId", "createdAt") FROM stdin;
012bb5c8-7c4f-4191-8dd8-618b238328ef	0	ac73be81-5e8d-4f57-9e5c-c3be63e15063	2ca2c9fa-943c-4e50-82dd-44e5b3dc7bbf	2025-12-08 21:05:18.099
29ee1c71-6d05-4045-a323-6b1e2cd2fe4d	0	3b03c283-ae46-4afe-ab49-d529cd7f21c2	6b24f921-bd92-4ea6-8403-1db3f9973ef6	2025-12-23 11:44:21.693
d07c3dbf-1862-421c-adec-8e5693dea716	0	962fc2e5-d259-4fd9-a9a9-6e8c802a086f	c2ef3189-c67f-4a14-bd96-ae98d315ccfa	2025-12-25 17:39:49.5
00b63af2-2c94-433a-836d-1c05b79a3622	0	6daa94c5-0890-47be-9e64-5339183cfe86	fbb40d7e-bb37-491b-b487-c19b1795cd9c	2026-01-08 19:13:13.592
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, name, description, price, image, "isAvailable", "stockTracked", "currentStock", "categoryId", "tenantId", "createdAt", "updatedAt") FROM stdin;
8b69ecf5-7f14-48ff-9f80-e41ddc947f70	Caesar Salad	Fresh romaine lettuce with Caesar dressing and croutons	8.99	\N	t	t	50	c2fdd157-0daa-405c-8961-39bfefd501c3	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.284	2025-12-08 20:34:33.284
a9e459af-4060-4adf-a567-d73e97503c6c	Garlic Bread	Toasted bread with garlic butter	5.99	\N	t	t	30	c2fdd157-0daa-405c-8961-39bfefd501c3	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.284	2025-12-08 20:34:33.284
98864901-10aa-4a9d-a177-54b3dcd5c39b	Buffalo Wings	Spicy chicken wings with ranch dressing	12.99	\N	t	t	25	c2fdd157-0daa-405c-8961-39bfefd501c3	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.284	2025-12-08 20:34:33.284
d3845f65-e411-4186-8045-a47d99538fcc	Grilled Salmon	Fresh Atlantic salmon with vegetables	24.99	\N	t	t	15	ea231560-de53-4e33-a585-4439c1f6fbdc	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.284	2025-12-08 20:34:33.284
c75c077c-3e5b-430f-9118-8ae7264e58d6	Pasta Carbonara	Classic Italian pasta with creamy sauce	16.99	\N	t	t	35	ea231560-de53-4e33-a585-4439c1f6fbdc	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.284	2025-12-08 20:34:33.284
e4841733-2a2e-46ef-9870-cbc2ea9d93d0	Chicken Tikka Masala	Marinated chicken in spicy tomato sauce	18.99	\N	t	t	20	ea231560-de53-4e33-a585-4439c1f6fbdc	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.284	2025-12-08 20:34:33.284
7451e46c-abfe-4b65-b1da-6bf1dcc56c96	Chocolate Lava Cake	Warm chocolate cake with molten center	7.99	\N	t	t	22	462e3ab3-eb9e-4ded-958a-e20d75944198	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.284	2025-12-08 20:34:33.284
814f8af3-1381-4518-a649-51ec1d0afdca	Tiramisu	Classic Italian coffee-flavored dessert	8.99	\N	t	t	18	462e3ab3-eb9e-4ded-958a-e20d75944198	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.284	2025-12-08 20:34:33.284
7da175bc-f114-4ddb-90b3-5c4ef5962dd1	Ice Cream Sundae	Three scoops with toppings	6.99	\N	t	t	50	462e3ab3-eb9e-4ded-958a-e20d75944198	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.284	2025-12-08 20:34:33.284
e24b2b63-1ea3-4a97-9057-c223b87de7ae	Coca Cola	Refreshing soft drink	2.99	\N	t	t	100	7e085adb-7c35-4374-9578-d7f1ecfdd612	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.284	2025-12-08 20:34:33.284
42e7a6fc-09ba-4586-b3c0-3828494d9cb1	Fresh Orange Juice	Freshly squeezed orange juice	4.99	\N	t	t	30	7e085adb-7c35-4374-9578-d7f1ecfdd612	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.284	2025-12-08 20:34:33.284
2f579128-ddd5-4566-8094-6f041f449748	Coffee	Freshly brewed coffee	3.99	\N	t	f	0	7e085adb-7c35-4374-9578-d7f1ecfdd612	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.284	2025-12-08 20:34:33.284
ac73be81-5e8d-4f57-9e5c-c3be63e15063	Beef Burger	Premium beef patty with cheese and fries	15.99		t	t	40	ea231560-de53-4e33-a585-4439c1f6fbdc	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.284	2025-12-08 21:05:18.084
3b03c283-ae46-4afe-ab49-d529cd7f21c2	Deneme	Deneme	1.00	\N	t	f	15	c22fca85-5682-4e3f-b9f8-df1123aa2f67	6f066396-a840-4666-b849-33ec50ccc89c	2025-12-23 11:44:21.622	2025-12-23 11:44:21.622
4780b59c-0c8b-43d0-a7a5-d09e41822b22	asd	asd	12.00	\N	t	f	123	55a6b787-dc61-48d8-83d3-e8bd75eaf18f	184f0210-b0ec-46fe-a276-db3c3b60bcc9	2025-12-25 15:15:47.625	2025-12-25 15:15:47.625
962fc2e5-d259-4fd9-a9a9-6e8c802a086f	Ahsencik	Tatlı bir yanak	5.00	\N	t	f	1	79a9a2c1-4981-4449-a218-4c09fd0e1f12	f919a93f-eb07-418a-b174-4e76d4f17940	2025-12-25 17:39:49.477	2025-12-25 17:39:49.477
6daa94c5-0890-47be-9e64-5339183cfe86	deneme	deneme	123.00	\N	t	f	1	365f97e1-f8d1-4425-95b2-4207c25a9e56	1d3a29b6-1bea-4b64-ab42-7a86e246258b	2026-01-08 19:13:13.549	2026-01-08 19:13:13.549
\.


--
-- Data for Name: public_reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.public_reviews (id, name, email, restaurant, avatar, rating, comment, status, "approvedAt", country, city, "isVerified", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: public_stats_cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.public_stats_cache (id, "totalViews", "uniqueVisitors", "totalReviews", "averageRating", "totalTenants", "countryDistribution", "cityDistribution", "viewsToday", "viewsThisWeek", "viewsThisMonth", "lastUpdated") FROM stdin;
main	25	1	0	0	6	{}	{}	10	25	25	2026-01-09 20:00:00.197
\.


--
-- Data for Name: qr_menu_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qr_menu_settings (id, "tenantId", "primaryColor", "secondaryColor", "backgroundColor", "fontFamily", "logoUrl", "showRestaurantInfo", "showPrices", "showDescription", "showImages", "layoutStyle", "itemsPerRow", "enableTableQR", "tableQRMessage", "createdAt", "updatedAt") FROM stdin;
6927bf94-ab60-46e0-a5ec-0b5c27b09429	ef685100-b2a0-450d-a88f-345b64371b3d	#3B82F6	#1F2937	#F9FAFB	Inter	\N	t	t	t	t	GRID	2	t	Scan to view our menu	2025-12-08 20:42:47.038	2025-12-08 20:42:47.038
5fd72f2b-1166-4904-803f-d5ae03757d91	184f0210-b0ec-46fe-a276-db3c3b60bcc9	#3B82F6	#1F2937	#F9FAFB	Inter	\N	t	t	t	t	GRID	2	t	Scan to view our menu	2025-12-23 10:28:08.408	2025-12-23 10:28:08.408
97dd7074-b7e6-4618-a272-3f8e8aa275b6	6f066396-a840-4666-b849-33ec50ccc89c	#3B82F6	#1F2937	#F9FAFB	Inter	\N	t	t	t	t	GRID	2	t	Scan to view our menu	2025-12-23 11:47:07.099	2025-12-23 11:47:07.099
7929a789-f634-489d-a0f7-c8c67505d65b	f919a93f-eb07-418a-b174-4e76d4f17940	#3B82F6	#1F2937	#F9FAFB	Inter	\N	t	t	t	t	GRID	2	t	Scan to view our menu	2025-12-25 17:17:51.086	2025-12-25 17:17:51.086
3813a737-d841-4dee-af18-d8cb4f143555	1d3a29b6-1bea-4b64-ab42-7a86e246258b	#3B82F6	#1F2937	#F9FAFB	Inter	\N	t	t	t	t	GRID	2	t	Scan to view our menu	2026-01-06 23:59:30.61	2026-01-06 23:59:30.61
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_movements (id, type, quantity, reason, notes, "productId", "userId", "tenantId", "createdAt") FROM stdin;
\.


--
-- Data for Name: subscription_payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscription_payments (id, "subscriptionId", amount, currency, status, "paymentProvider", "stripePaymentIntentId", "paytrMerchantOid", "paytrPaymentToken", "paymentMethod", last4, "cardBrand", "failureCode", "failureMessage", "retryCount", "paidAt", "refundedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscription_plans (id, name, "displayName", description, "monthlyPrice", "yearlyPrice", currency, "trialDays", "maxUsers", "maxTables", "maxProducts", "maxCategories", "maxMonthlyOrders", "advancedReports", "multiLocation", "customBranding", "apiAccess", "prioritySupport", "inventoryTracking", "kdsIntegration", "isActive", "createdAt", "updatedAt", "discountEndDate", "discountLabel", "discountPercentage", "discountStartDate", "isDiscountActive") FROM stdin;
9f80ae2e-6ec2-4cd3-b053-6560bc939c87	FREE	Free Plan	Perfect for small restaurants getting started	0.00	0.00	USD	0	2	5	25	5	50	f	f	f	f	f	f	t	t	2025-12-08 20:34:32.45	2025-12-08 20:34:32.45	\N	\N	\N	\N	f
adf03da7-9a61-41ce-a6aa-0d64af892a06	BASIC	Basic Plan	Great for growing restaurants	29.99	299.99	USD	14	5	20	100	20	500	f	f	f	f	f	t	t	t	2025-12-08 20:34:32.534	2025-12-08 20:34:32.534	\N	\N	\N	\N	f
b7b653c0-8402-46f3-91ad-a616cf4e23eb	PRO	Pro Plan	For established restaurants with multiple locations	79.99	799.99	USD	14	15	50	500	50	2000	t	t	t	f	t	t	t	t	2025-12-08 20:34:32.564	2025-12-08 20:34:32.564	\N	\N	\N	\N	f
80d27c43-f36e-46fd-8306-90e436386f64	BUSINESS	Business Plan	Enterprise solution for large restaurant chains	199.99	1999.99	USD	14	-1	-1	-1	-1	-1	t	t	t	t	t	t	t	t	2025-12-08 20:34:32.592	2025-12-08 20:34:32.592	\N	\N	\N	\N	f
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscriptions (id, "tenantId", "planId", status, "billingCycle", "paymentProvider", "startDate", "currentPeriodStart", "currentPeriodEnd", "cancelledAt", "endedAt", "isTrialPeriod", "trialStart", "trialEnd", "stripeSubscriptionId", "stripeCustomerId", "paytrMerchantOid", "paytrPaymentToken", "renewalLinkSentAt", "renewalLinkToken", "graceEndDate", amount, currency, "autoRenew", "cancelAtPeriodEnd", "cancellationReason", "createdAt", "updatedAt") FROM stdin;
08bf4634-cd42-41e1-a3e4-998a2257d3ff	184f0210-b0ec-46fe-a276-db3c3b60bcc9	9f80ae2e-6ec2-4cd3-b053-6560bc939c87	ACTIVE	MONTHLY	STRIPE	2025-12-23 10:27:31.87	2025-12-23 10:27:31.87	2035-12-23 10:27:31.87	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	0.00	USD	t	f	\N	2025-12-23 10:27:31.873	2025-12-23 10:27:31.873
a733b724-b5b4-41b8-bea3-954de1e225ed	f919a93f-eb07-418a-b174-4e76d4f17940	9f80ae2e-6ec2-4cd3-b053-6560bc939c87	ACTIVE	MONTHLY	STRIPE	2025-12-25 17:17:45.26	2025-12-25 17:17:45.26	2035-12-25 17:17:45.26	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	0.00	USD	t	f	\N	2025-12-25 17:17:45.263	2025-12-25 17:17:45.263
50b97567-d86f-4159-b0e6-cf9ccafc69b0	6f066396-a840-4666-b849-33ec50ccc89c	9f80ae2e-6ec2-4cd3-b053-6560bc939c87	ACTIVE	MONTHLY	STRIPE	2025-12-23 10:06:23.153	2025-12-23 10:06:23.153	2035-12-23 10:06:23.153	2025-12-25 20:23:23.69	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	0.00	USD	f	t	Too expensive	2025-12-23 10:06:23.156	2025-12-25 20:23:23.694
c2f17883-c6b7-4adb-8bfb-e28304f64d4f	ca3f23f8-e990-4a9d-9ae8-bb2ced25a3d6	9f80ae2e-6ec2-4cd3-b053-6560bc939c87	ACTIVE	MONTHLY	STRIPE	2025-12-26 06:03:31.864	2025-12-26 06:03:31.864	2035-12-26 06:03:31.864	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	0.00	USD	t	f	\N	2025-12-26 06:03:31.874	2025-12-26 06:03:31.874
d7237827-c91c-4fab-a3d5-633b9cb9a42e	1d3a29b6-1bea-4b64-ab42-7a86e246258b	9f80ae2e-6ec2-4cd3-b053-6560bc939c87	ACTIVE	MONTHLY	STRIPE	2026-01-06 23:49:54.121	2026-01-06 23:49:54.121	2036-01-06 23:49:54.121	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	0.00	USD	t	f	\N	2026-01-06 23:49:54.125	2026-01-09 12:56:14.707
\.


--
-- Data for Name: tables; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tables (id, number, capacity, section, status, "tenantId", "createdAt", "updatedAt") FROM stdin;
d938f1f1-05ae-4e53-acd2-358a4e06a33e	1	2	Main Hall	AVAILABLE	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.328	2025-12-08 20:34:33.328
8013f072-4224-44ff-acc4-471ec83965f7	3	4	Main Hall	AVAILABLE	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.328	2025-12-08 20:34:33.328
20fb8a02-e066-4712-a482-c1b78f5aedd4	4	6	Main Hall	AVAILABLE	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.328	2025-12-08 20:34:33.328
35bef395-84ff-473f-9a6b-89b38b115dd6	6	4	Terrace	AVAILABLE	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.328	2025-12-08 20:34:33.328
a022c00a-413b-424c-af30-0881874288ac	7	8	Private Room	AVAILABLE	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.328	2025-12-08 20:34:33.328
f5ac50c5-9a11-4f94-b017-ab5498cc3e41	2	4	Main Hall	OCCUPIED	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.328	2025-12-08 20:56:21.273
edd045bc-3785-4084-8b01-9b8356c85e94	5	2	Terrace	OCCUPIED	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.328	2025-12-08 20:57:34.328
ab23caa1-ecd7-4a90-8fb3-393c807035e3	1	4	\N	AVAILABLE	184f0210-b0ec-46fe-a276-db3c3b60bcc9	2025-12-25 15:15:57.999	2025-12-25 15:15:57.999
8cf3599b-96df-4ad6-9abb-aaba2db46942	2	2	\N	AVAILABLE	f919a93f-eb07-418a-b174-4e76d4f17940	2025-12-25 17:40:24.33	2025-12-25 17:40:24.33
c39958cf-4130-4686-b1a4-412d45852f41	8	4	\N	AVAILABLE	f919a93f-eb07-418a-b174-4e76d4f17940	2025-12-25 17:40:06.588	2025-12-25 17:44:29.387
fb9460d5-9602-4d77-8406-be74ef67fad3	1	4	\N	AVAILABLE	6f066396-a840-4666-b849-33ec50ccc89c	2025-12-23 11:44:53.009	2025-12-26 17:25:01.771
6127c144-ea19-4546-a4a5-0044bf48f1e3	1	4	\N	OCCUPIED	1d3a29b6-1bea-4b64-ab42-7a86e246258b	2026-01-08 19:13:30.596	2026-01-09 12:55:45.417
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (id, name, subdomain, status, "currentPlanId", "paymentRegion", "trialUsed", "trialStartedAt", "trialEndsAt", "createdAt", "updatedAt", "closingTime", currency, "reportEmailEnabled", "reportEmails", timezone, latitude, "locationRadius", longitude) FROM stdin;
ef685100-b2a0-450d-a88f-345b64371b3d	Demo Restaurant	demo	ACTIVE	9f80ae2e-6ec2-4cd3-b053-6560bc939c87	INTERNATIONAL	f	\N	\N	2025-12-08 20:34:32.634	2025-12-08 20:34:32.634	23:00	TRY	f	{}	UTC	\N	100	\N
6f066396-a840-4666-b849-33ec50ccc89c	Tarık's Restaurant	tar-k-s-restaurant	ACTIVE	9f80ae2e-6ec2-4cd3-b053-6560bc939c87	INTERNATIONAL	f	\N	\N	2025-12-23 10:06:23.14	2025-12-23 10:06:23.14	23:00	TRY	f	{}	UTC	\N	100	\N
184f0210-b0ec-46fe-a276-db3c3b60bcc9	Muhammed Tarık's Restaurant	muhammed-tar-k-s-restaurant	ACTIVE	9f80ae2e-6ec2-4cd3-b053-6560bc939c87	INTERNATIONAL	f	\N	\N	2025-12-23 10:27:31.859	2025-12-23 10:27:31.859	23:00	TRY	f	{}	UTC	\N	100	\N
f919a93f-eb07-418a-b174-4e76d4f17940	ja's Restaurant	ja-s-restaurant	ACTIVE	9f80ae2e-6ec2-4cd3-b053-6560bc939c87	INTERNATIONAL	f	\N	\N	2025-12-25 17:17:45.245	2025-12-25 17:17:45.245	23:00	TRY	f	{}	UTC	\N	100	\N
ca3f23f8-e990-4a9d-9ae8-bb2ced25a3d6	tarık's Restaurant	tar-k-s-restaurant-w06jef	ACTIVE	9f80ae2e-6ec2-4cd3-b053-6560bc939c87	INTERNATIONAL	f	\N	\N	2025-12-26 06:03:31.811	2025-12-26 06:03:31.811	23:00	TRY	f	{}	UTC	\N	100	\N
1d3a29b6-1bea-4b64-ab42-7a86e246258b	tarikss	tarikss	ACTIVE	9f80ae2e-6ec2-4cd3-b053-6560bc939c87	INTERNATIONAL	f	\N	\N	2026-01-06 23:49:54.114	2026-01-08 21:58:28.723	23:00	TRY	f	{}	UTC	39.98322986908028	90	32.65492540180888
\.


--
-- Data for Name: user_notification_reads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_notification_reads (id, "notificationId", "userId", "readAt") FROM stdin;
1e459620-4827-454f-955f-6068a8163a31	1fb016e7-953a-43da-8145-59aa69910a70	8f4f118b-9979-44b5-9e36-463ca0391cc2	2026-01-06 23:51:15.508
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password, "firstName", "lastName", role, status, "emailVerified", "emailVerificationCode", "emailVerificationCodeExpires", "resetToken", "resetTokenExpiry", avatar, phone, "lastLogin", "tenantId", "createdAt", "updatedAt", "appleId", "authProvider", "googleId") FROM stdin;
0630de68-08fc-46e9-bf80-36cbcb447182	admin@restaurant.com	$2a$10$RZJ8J6EkuHxl.6fo0UF7de9NKe5XcNgj/Es4Gm4pVgmgPiRjaLkNK	John	Admin	ADMIN	ACTIVE	f	\N	\N	\N	\N	\N	\N	\N	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.146	2025-12-08 20:34:33.146	\N	local	\N
9e17410a-8b72-4ba8-9cd5-f31de6c72498	waiter@restaurant.com	$2a$10$RZJ8J6EkuHxl.6fo0UF7de9NKe5XcNgj/Es4Gm4pVgmgPiRjaLkNK	Jane	Waiter	WAITER	ACTIVE	f	\N	\N	\N	\N	\N	\N	\N	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.171	2025-12-08 20:34:33.171	\N	local	\N
cb8d6171-f9db-4477-87c6-02784a034601	kitchen@restaurant.com	$2a$10$RZJ8J6EkuHxl.6fo0UF7de9NKe5XcNgj/Es4Gm4pVgmgPiRjaLkNK	Mike	Chef	KITCHEN	ACTIVE	f	\N	\N	\N	\N	\N	\N	\N	ef685100-b2a0-450d-a88f-345b64371b3d	2025-12-08 20:34:33.192	2025-12-08 20:34:33.192	\N	local	\N
814b878e-8f35-44b0-b33d-7c22f1db31ec	tarik42777@gmail.com		Tarık	Uçar	ADMIN	ACTIVE	t	\N	\N	\N	\N	\N	\N	\N	6f066396-a840-4666-b849-33ec50ccc89c	2025-12-23 10:06:23.169	2025-12-23 10:06:23.169	\N	google	103540710481107596238
029db9ab-091a-484d-adb7-cf12b2a9845e	tas@gmail.com	$2a$10$kXKrsChzwSFAnSvuYmUZx.SuWheZpcCMdGtS7vyL.eMfEZOkJN.AO	Denem	Deneme	WAITER	ACTIVE	f	\N	\N	\N	\N	\N	\N	\N	6f066396-a840-4666-b849-33ec50ccc89c	2025-12-23 11:45:40.17	2025-12-23 11:45:40.17	\N	local	\N
e2fce0ef-0b70-46f7-8b1d-18275fdc1c0d	jarulla.f@gmail.com		ja	rullah	ADMIN	ACTIVE	t	\N	\N	\N	\N	\N	\N	\N	f919a93f-eb07-418a-b174-4e76d4f17940	2025-12-25 17:17:45.28	2025-12-25 17:17:45.28	\N	google	110935015641851194436
948dbccf-38e6-4f17-9672-9e4558d3d2e0	muhammedtarikucar@gmail.com		Muhammed Tarık	Uçar	ADMIN	ACTIVE	t	\N	\N	037e8796-132d-476b-a4eb-fa3068d551cd	2026-01-07 00:38:37.245	\N	\N	\N	184f0210-b0ec-46fe-a276-db3c3b60bcc9	2025-12-23 10:27:31.885	2026-01-06 23:38:37.247	\N	google	101117484835184287864
1ccb3e5c-0794-4025-8692-46e03a8629b3	tarik063442@gmail.com		tarık	uçar	ADMIN	ACTIVE	t	\N	\N	f45f5887-54cb-445a-abe7-e2af7fd9bac4	2026-01-07 00:38:53.73	\N	\N	\N	ca3f23f8-e990-4a9d-9ae8-bb2ced25a3d6	2025-12-26 06:03:31.924	2026-01-06 23:38:53.732	\N	google	106882803794941881132
8f4f118b-9979-44b5-9e36-463ca0391cc2	tarik063443@gmail.com	$2a$10$JJF5oN9HMv2BHl4z5GKYVuWgCBcDi2r5D3iUPPwr7qBKwmxj8MlZW	tarik	ucar	ADMIN	ACTIVE	f	322770	2026-01-07 00:49:54.332	\N	\N	\N	\N	\N	1d3a29b6-1bea-4b64-ab42-7a86e246258b	2026-01-06 23:49:54.315	2026-01-06 23:49:54.334	\N	local	\N
\.


--
-- Data for Name: waiter_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.waiter_requests (id, message, status, "sessionId", "tableId", "acknowledgedAt", "acknowledgedById", "completedAt", "createdAt", "updatedAt") FROM stdin;
0f0cd448-631f-46b5-a2af-b63a5dfadc81	\N	COMPLETED	4164be4c-ca5b-4d91-8a07-b8a4607fdef2	edd045bc-3785-4084-8b01-9b8356c85e94	2025-12-08 20:57:39.682	0630de68-08fc-46e9-bf80-36cbcb447182	2025-12-08 20:57:40.894	2025-12-08 20:57:08.836	2025-12-08 20:57:40.895
\.


--
-- Data for Name: z_reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.z_reports (id, "reportNumber", "reportDate", "closingTime", "closingType", "closedById", "branchName", "terminalId", "totalSales", "totalOrders", "totalDiscount", "totalRefunds", "netSales", "dineInSales", "dineInOrders", "takeawaySales", "takeawayOrders", "deliverySales", "deliveryOrders", "cashPayments", "cashPaymentCount", "cardPayments", "cardPaymentCount", "digitalPayments", "digitalPaymentCount", "openingCash", "expectedCash", "countedCash", "cashDifference", "cashInOut", "cancelledOrders", "cancelledOrdersAmount", "refundedPayments", "refundedAmount", "staffPerformance", "categoryBreakdown", "topProducts", "openChecks", "openChecksAmount", notes, "systemGenerated", "pdfExported", "pdfUrl", "excelExported", "excelUrl", "emailSent", "emailSentAt", "tenantId", "createdAt", "updatedAt", "emailError", "emailRecipients") FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: bill_requests bill_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_requests
    ADD CONSTRAINT bill_requests_pkey PRIMARY KEY (id);


--
-- Name: cash_drawer_movements cash_drawer_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cash_drawer_movements
    ADD CONSTRAINT cash_drawer_movements_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: contact_messages contact_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_messages
    ADD CONSTRAINT contact_messages_pkey PRIMARY KEY (id);


--
-- Name: customer_referrals customer_referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_referrals
    ADD CONSTRAINT customer_referrals_pkey PRIMARY KEY (id);


--
-- Name: customer_sessions customer_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_sessions
    ADD CONSTRAINT customer_sessions_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: desktop_releases desktop_releases_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.desktop_releases
    ADD CONSTRAINT desktop_releases_pkey PRIMARY KEY (id);


--
-- Name: integration_settings integration_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_settings
    ADD CONSTRAINT integration_settings_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: loyalty_transactions loyalty_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT loyalty_transactions_pkey PRIMARY KEY (id);


--
-- Name: modifier_groups modifier_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifier_groups
    ADD CONSTRAINT modifier_groups_pkey PRIMARY KEY (id);


--
-- Name: modifiers modifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifiers
    ADD CONSTRAINT modifiers_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: order_item_modifiers order_item_modifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item_modifiers
    ADD CONSTRAINT order_item_modifiers_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: page_views page_views_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_views
    ADD CONSTRAINT page_views_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: pending_plan_changes pending_plan_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_plan_changes
    ADD CONSTRAINT pending_plan_changes_pkey PRIMARY KEY (id);


--
-- Name: phone_verifications phone_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.phone_verifications
    ADD CONSTRAINT phone_verifications_pkey PRIMARY KEY (id);


--
-- Name: pos_settings pos_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pos_settings
    ADD CONSTRAINT pos_settings_pkey PRIMARY KEY (id);


--
-- Name: product_images product_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_pkey PRIMARY KEY (id);


--
-- Name: product_modifier_groups product_modifier_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_modifier_groups
    ADD CONSTRAINT product_modifier_groups_pkey PRIMARY KEY (id);


--
-- Name: product_to_images product_to_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_to_images
    ADD CONSTRAINT product_to_images_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: public_reviews public_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.public_reviews
    ADD CONSTRAINT public_reviews_pkey PRIMARY KEY (id);


--
-- Name: public_stats_cache public_stats_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.public_stats_cache
    ADD CONSTRAINT public_stats_cache_pkey PRIMARY KEY (id);


--
-- Name: qr_menu_settings qr_menu_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qr_menu_settings
    ADD CONSTRAINT qr_menu_settings_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: subscription_payments subscription_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT subscription_payments_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: tables tables_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT tables_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: user_notification_reads user_notification_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_reads
    ADD CONSTRAINT user_notification_reads_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: waiter_requests waiter_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waiter_requests
    ADD CONSTRAINT waiter_requests_pkey PRIMARY KEY (id);


--
-- Name: z_reports z_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.z_reports
    ADD CONSTRAINT z_reports_pkey PRIMARY KEY (id);


--
-- Name: api_keys_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "api_keys_isActive_idx" ON public.api_keys USING btree ("isActive");


--
-- Name: api_keys_key_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_keys_key_idx ON public.api_keys USING btree (key);


--
-- Name: api_keys_key_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX api_keys_key_key ON public.api_keys USING btree (key);


--
-- Name: api_keys_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "api_keys_tenantId_idx" ON public.api_keys USING btree ("tenantId");


--
-- Name: bill_requests_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "bill_requests_sessionId_idx" ON public.bill_requests USING btree ("sessionId");


--
-- Name: bill_requests_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bill_requests_status_idx ON public.bill_requests USING btree (status);


--
-- Name: bill_requests_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "bill_requests_tableId_idx" ON public.bill_requests USING btree ("tableId");


--
-- Name: cash_drawer_movements_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "cash_drawer_movements_createdAt_idx" ON public.cash_drawer_movements USING btree ("createdAt");


--
-- Name: cash_drawer_movements_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "cash_drawer_movements_tenantId_idx" ON public.cash_drawer_movements USING btree ("tenantId");


--
-- Name: cash_drawer_movements_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "cash_drawer_movements_userId_idx" ON public.cash_drawer_movements USING btree ("userId");


--
-- Name: cash_drawer_movements_zReportId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "cash_drawer_movements_zReportId_idx" ON public.cash_drawer_movements USING btree ("zReportId");


--
-- Name: categories_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "categories_tenantId_idx" ON public.categories USING btree ("tenantId");


--
-- Name: contact_messages_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "contact_messages_createdAt_idx" ON public.contact_messages USING btree ("createdAt");


--
-- Name: contact_messages_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX contact_messages_status_idx ON public.contact_messages USING btree (status);


--
-- Name: customer_referrals_referralCode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_referrals_referralCode_idx" ON public.customer_referrals USING btree ("referralCode");


--
-- Name: customer_referrals_referredId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_referrals_referredId_idx" ON public.customer_referrals USING btree ("referredId");


--
-- Name: customer_referrals_referredId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customer_referrals_referredId_key" ON public.customer_referrals USING btree ("referredId");


--
-- Name: customer_referrals_referrerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_referrals_referrerId_idx" ON public.customer_referrals USING btree ("referrerId");


--
-- Name: customer_referrals_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customer_referrals_status_idx ON public.customer_referrals USING btree (status);


--
-- Name: customer_sessions_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_sessions_customerId_idx" ON public.customer_sessions USING btree ("customerId");


--
-- Name: customer_sessions_expiresAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_sessions_expiresAt_idx" ON public.customer_sessions USING btree ("expiresAt");


--
-- Name: customer_sessions_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_sessions_sessionId_idx" ON public.customer_sessions USING btree ("sessionId");


--
-- Name: customer_sessions_sessionId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customer_sessions_sessionId_key" ON public.customer_sessions USING btree ("sessionId");


--
-- Name: customer_sessions_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customer_sessions_tenantId_idx" ON public.customer_sessions USING btree ("tenantId");


--
-- Name: customers_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customers_email_idx ON public.customers USING btree (email);


--
-- Name: customers_loyaltyTier_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customers_loyaltyTier_idx" ON public.customers USING btree ("loyaltyTier");


--
-- Name: customers_phone_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX customers_phone_idx ON public.customers USING btree (phone);


--
-- Name: customers_referralCode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customers_referralCode_idx" ON public.customers USING btree ("referralCode");


--
-- Name: customers_referralCode_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customers_referralCode_key" ON public.customers USING btree ("referralCode");


--
-- Name: customers_tenantId_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customers_tenantId_email_key" ON public.customers USING btree ("tenantId", email);


--
-- Name: customers_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "customers_tenantId_idx" ON public.customers USING btree ("tenantId");


--
-- Name: customers_tenantId_phone_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "customers_tenantId_phone_key" ON public.customers USING btree ("tenantId", phone);


--
-- Name: desktop_releases_published_pubDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "desktop_releases_published_pubDate_idx" ON public.desktop_releases USING btree (published, "pubDate");


--
-- Name: desktop_releases_releaseTag_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "desktop_releases_releaseTag_key" ON public.desktop_releases USING btree ("releaseTag");


--
-- Name: desktop_releases_version_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX desktop_releases_version_idx ON public.desktop_releases USING btree (version);


--
-- Name: desktop_releases_version_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX desktop_releases_version_key ON public.desktop_releases USING btree (version);


--
-- Name: integration_settings_integrationType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "integration_settings_integrationType_idx" ON public.integration_settings USING btree ("integrationType");


--
-- Name: integration_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "integration_settings_tenantId_idx" ON public.integration_settings USING btree ("tenantId");


--
-- Name: integration_settings_tenantId_integrationType_provider_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "integration_settings_tenantId_integrationType_provider_key" ON public.integration_settings USING btree ("tenantId", "integrationType", provider);


--
-- Name: invoices_dueDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_dueDate_idx" ON public.invoices USING btree ("dueDate");


--
-- Name: invoices_invoiceNumber_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_invoiceNumber_idx" ON public.invoices USING btree ("invoiceNumber");


--
-- Name: invoices_invoiceNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "invoices_invoiceNumber_key" ON public.invoices USING btree ("invoiceNumber");


--
-- Name: invoices_paymentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "invoices_paymentId_key" ON public.invoices USING btree ("paymentId");


--
-- Name: invoices_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX invoices_status_idx ON public.invoices USING btree (status);


--
-- Name: invoices_subscriptionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_subscriptionId_idx" ON public.invoices USING btree ("subscriptionId");


--
-- Name: loyalty_transactions_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "loyalty_transactions_createdAt_idx" ON public.loyalty_transactions USING btree ("createdAt");


--
-- Name: loyalty_transactions_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "loyalty_transactions_customerId_idx" ON public.loyalty_transactions USING btree ("customerId");


--
-- Name: loyalty_transactions_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX loyalty_transactions_type_idx ON public.loyalty_transactions USING btree (type);


--
-- Name: modifier_groups_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifier_groups_isActive_idx" ON public.modifier_groups USING btree ("isActive");


--
-- Name: modifier_groups_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifier_groups_tenantId_idx" ON public.modifier_groups USING btree ("tenantId");


--
-- Name: modifiers_groupId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifiers_groupId_idx" ON public.modifiers USING btree ("groupId");


--
-- Name: modifiers_isAvailable_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifiers_isAvailable_idx" ON public.modifiers USING btree ("isAvailable");


--
-- Name: modifiers_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "modifiers_tenantId_idx" ON public.modifiers USING btree ("tenantId");


--
-- Name: notifications_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "notifications_createdAt_idx" ON public.notifications USING btree ("createdAt");


--
-- Name: notifications_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "notifications_tenantId_idx" ON public.notifications USING btree ("tenantId");


--
-- Name: notifications_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "notifications_userId_idx" ON public.notifications USING btree ("userId");


--
-- Name: order_item_modifiers_modifierId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_item_modifiers_modifierId_idx" ON public.order_item_modifiers USING btree ("modifierId");


--
-- Name: order_item_modifiers_orderItemId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_item_modifiers_orderItemId_idx" ON public.order_item_modifiers USING btree ("orderItemId");


--
-- Name: order_items_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_items_orderId_idx" ON public.order_items USING btree ("orderId");


--
-- Name: order_items_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "order_items_productId_idx" ON public.order_items USING btree ("productId");


--
-- Name: orders_approvedById_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_approvedById_idx" ON public.orders USING btree ("approvedById");


--
-- Name: orders_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_customerId_idx" ON public.orders USING btree ("customerId");


--
-- Name: orders_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_sessionId_idx" ON public.orders USING btree ("sessionId");


--
-- Name: orders_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orders_status_idx ON public.orders USING btree (status);


--
-- Name: orders_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_tableId_idx" ON public.orders USING btree ("tableId");


--
-- Name: orders_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_tenantId_idx" ON public.orders USING btree ("tenantId");


--
-- Name: orders_tenantId_orderNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "orders_tenantId_orderNumber_key" ON public.orders USING btree ("tenantId", "orderNumber");


--
-- Name: orders_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "orders_userId_idx" ON public.orders USING btree ("userId");


--
-- Name: page_views_city_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX page_views_city_idx ON public.page_views USING btree (city);


--
-- Name: page_views_country_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX page_views_country_idx ON public.page_views USING btree (country);


--
-- Name: page_views_page_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "page_views_page_createdAt_idx" ON public.page_views USING btree (page, "createdAt");


--
-- Name: page_views_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "page_views_sessionId_idx" ON public.page_views USING btree ("sessionId");


--
-- Name: payments_idempotencyKey_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "payments_idempotencyKey_key" ON public.payments USING btree ("idempotencyKey");


--
-- Name: payments_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "payments_orderId_idx" ON public.payments USING btree ("orderId");


--
-- Name: payments_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payments_status_idx ON public.payments USING btree (status);


--
-- Name: pending_plan_changes_paymentStatus_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pending_plan_changes_paymentStatus_idx" ON public.pending_plan_changes USING btree ("paymentStatus");


--
-- Name: pending_plan_changes_scheduledFor_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pending_plan_changes_scheduledFor_idx" ON public.pending_plan_changes USING btree ("scheduledFor");


--
-- Name: pending_plan_changes_subscriptionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pending_plan_changes_subscriptionId_idx" ON public.pending_plan_changes USING btree ("subscriptionId");


--
-- Name: phone_verifications_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX phone_verifications_code_idx ON public.phone_verifications USING btree (code);


--
-- Name: phone_verifications_expiresAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "phone_verifications_expiresAt_idx" ON public.phone_verifications USING btree ("expiresAt");


--
-- Name: phone_verifications_phone_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "phone_verifications_phone_tenantId_idx" ON public.phone_verifications USING btree (phone, "tenantId");


--
-- Name: pos_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pos_settings_tenantId_idx" ON public.pos_settings USING btree ("tenantId");


--
-- Name: pos_settings_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "pos_settings_tenantId_key" ON public.pos_settings USING btree ("tenantId");


--
-- Name: product_images_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_images_tenantId_idx" ON public.product_images USING btree ("tenantId");


--
-- Name: product_modifier_groups_groupId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_modifier_groups_groupId_idx" ON public.product_modifier_groups USING btree ("groupId");


--
-- Name: product_modifier_groups_productId_groupId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "product_modifier_groups_productId_groupId_key" ON public.product_modifier_groups USING btree ("productId", "groupId");


--
-- Name: product_modifier_groups_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_modifier_groups_productId_idx" ON public.product_modifier_groups USING btree ("productId");


--
-- Name: product_to_images_imageId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_to_images_imageId_idx" ON public.product_to_images USING btree ("imageId");


--
-- Name: product_to_images_productId_imageId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "product_to_images_productId_imageId_key" ON public.product_to_images USING btree ("productId", "imageId");


--
-- Name: product_to_images_productId_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "product_to_images_productId_order_idx" ON public.product_to_images USING btree ("productId", "order");


--
-- Name: products_categoryId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "products_categoryId_idx" ON public.products USING btree ("categoryId");


--
-- Name: products_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "products_tenantId_idx" ON public.products USING btree ("tenantId");


--
-- Name: public_reviews_rating_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX public_reviews_rating_idx ON public.public_reviews USING btree (rating);


--
-- Name: public_reviews_status_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "public_reviews_status_createdAt_idx" ON public.public_reviews USING btree (status, "createdAt");


--
-- Name: qr_menu_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "qr_menu_settings_tenantId_idx" ON public.qr_menu_settings USING btree ("tenantId");


--
-- Name: qr_menu_settings_tenantId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "qr_menu_settings_tenantId_key" ON public.qr_menu_settings USING btree ("tenantId");


--
-- Name: stock_movements_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_movements_productId_idx" ON public.stock_movements USING btree ("productId");


--
-- Name: stock_movements_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_movements_tenantId_idx" ON public.stock_movements USING btree ("tenantId");


--
-- Name: stock_movements_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "stock_movements_userId_idx" ON public.stock_movements USING btree ("userId");


--
-- Name: subscription_payments_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscription_payments_createdAt_idx" ON public.subscription_payments USING btree ("createdAt");


--
-- Name: subscription_payments_paytrMerchantOid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscription_payments_paytrMerchantOid_key" ON public.subscription_payments USING btree ("paytrMerchantOid");


--
-- Name: subscription_payments_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX subscription_payments_status_idx ON public.subscription_payments USING btree (status);


--
-- Name: subscription_payments_stripePaymentIntentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscription_payments_stripePaymentIntentId_key" ON public.subscription_payments USING btree ("stripePaymentIntentId");


--
-- Name: subscription_payments_subscriptionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscription_payments_subscriptionId_idx" ON public.subscription_payments USING btree ("subscriptionId");


--
-- Name: subscription_plans_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX subscription_plans_name_key ON public.subscription_plans USING btree (name);


--
-- Name: subscriptions_currentPeriodEnd_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscriptions_currentPeriodEnd_idx" ON public.subscriptions USING btree ("currentPeriodEnd");


--
-- Name: subscriptions_paytrMerchantOid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscriptions_paytrMerchantOid_key" ON public.subscriptions USING btree ("paytrMerchantOid");


--
-- Name: subscriptions_planId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscriptions_planId_idx" ON public.subscriptions USING btree ("planId");


--
-- Name: subscriptions_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX subscriptions_status_idx ON public.subscriptions USING btree (status);


--
-- Name: subscriptions_stripeSubscriptionId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "subscriptions_stripeSubscriptionId_key" ON public.subscriptions USING btree ("stripeSubscriptionId");


--
-- Name: subscriptions_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "subscriptions_tenantId_idx" ON public.subscriptions USING btree ("tenantId");


--
-- Name: tables_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "tables_tenantId_idx" ON public.tables USING btree ("tenantId");


--
-- Name: tables_tenantId_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "tables_tenantId_number_key" ON public.tables USING btree ("tenantId", number);


--
-- Name: tenants_currentPlanId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "tenants_currentPlanId_idx" ON public.tenants USING btree ("currentPlanId");


--
-- Name: tenants_subdomain_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX tenants_subdomain_key ON public.tenants USING btree (subdomain);


--
-- Name: user_notification_reads_notificationId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_notification_reads_notificationId_idx" ON public.user_notification_reads USING btree ("notificationId");


--
-- Name: user_notification_reads_notificationId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "user_notification_reads_notificationId_userId_key" ON public.user_notification_reads USING btree ("notificationId", "userId");


--
-- Name: user_notification_reads_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "user_notification_reads_userId_idx" ON public.user_notification_reads USING btree ("userId");


--
-- Name: users_appleId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "users_appleId_key" ON public.users USING btree ("appleId");


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_googleId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "users_googleId_key" ON public.users USING btree ("googleId");


--
-- Name: users_resetToken_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "users_resetToken_key" ON public.users USING btree ("resetToken");


--
-- Name: users_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "users_tenantId_idx" ON public.users USING btree ("tenantId");


--
-- Name: waiter_requests_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "waiter_requests_sessionId_idx" ON public.waiter_requests USING btree ("sessionId");


--
-- Name: waiter_requests_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX waiter_requests_status_idx ON public.waiter_requests USING btree (status);


--
-- Name: waiter_requests_tableId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "waiter_requests_tableId_idx" ON public.waiter_requests USING btree ("tableId");


--
-- Name: z_reports_closedById_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "z_reports_closedById_idx" ON public.z_reports USING btree ("closedById");


--
-- Name: z_reports_reportDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "z_reports_reportDate_idx" ON public.z_reports USING btree ("reportDate");


--
-- Name: z_reports_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "z_reports_tenantId_idx" ON public.z_reports USING btree ("tenantId");


--
-- Name: z_reports_tenantId_reportNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "z_reports_tenantId_reportNumber_key" ON public.z_reports USING btree ("tenantId", "reportNumber");


--
-- Name: api_keys api_keys_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT "api_keys_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bill_requests bill_requests_acknowledgedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_requests
    ADD CONSTRAINT "bill_requests_acknowledgedById_fkey" FOREIGN KEY ("acknowledgedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bill_requests bill_requests_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_requests
    ADD CONSTRAINT "bill_requests_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cash_drawer_movements cash_drawer_movements_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cash_drawer_movements
    ADD CONSTRAINT "cash_drawer_movements_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: cash_drawer_movements cash_drawer_movements_zReportId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cash_drawer_movements
    ADD CONSTRAINT "cash_drawer_movements_zReportId_fkey" FOREIGN KEY ("zReportId") REFERENCES public.z_reports(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: categories categories_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "categories_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_referrals customer_referrals_referredId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_referrals
    ADD CONSTRAINT "customer_referrals_referredId_fkey" FOREIGN KEY ("referredId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_referrals customer_referrals_referrerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_referrals
    ADD CONSTRAINT "customer_referrals_referrerId_fkey" FOREIGN KEY ("referrerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_sessions customer_sessions_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_sessions
    ADD CONSTRAINT "customer_sessions_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: customers customers_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT "customers_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: integration_settings integration_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_settings
    ADD CONSTRAINT "integration_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoices invoices_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public.subscription_payments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: loyalty_transactions loyalty_transactions_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT "loyalty_transactions_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: modifier_groups modifier_groups_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifier_groups
    ADD CONSTRAINT "modifier_groups_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: modifiers modifiers_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifiers
    ADD CONSTRAINT "modifiers_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public.modifier_groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: modifiers modifiers_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modifiers
    ADD CONSTRAINT "modifiers_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_item_modifiers order_item_modifiers_modifierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item_modifiers
    ADD CONSTRAINT "order_item_modifiers_modifierId_fkey" FOREIGN KEY ("modifierId") REFERENCES public.modifiers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: order_item_modifiers order_item_modifiers_orderItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item_modifiers
    ADD CONSTRAINT "order_item_modifiers_orderItemId_fkey" FOREIGN KEY ("orderItemId") REFERENCES public.order_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_items order_items_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "order_items_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_items order_items_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "order_items_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: orders orders_approvedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_approvedById_fkey" FOREIGN KEY ("approvedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orders orders_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payments payments_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pending_plan_changes pending_plan_changes_currentPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_plan_changes
    ADD CONSTRAINT "pending_plan_changes_currentPlanId_fkey" FOREIGN KEY ("currentPlanId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pending_plan_changes pending_plan_changes_newPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_plan_changes
    ADD CONSTRAINT "pending_plan_changes_newPlanId_fkey" FOREIGN KEY ("newPlanId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pending_plan_changes pending_plan_changes_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_plan_changes
    ADD CONSTRAINT "pending_plan_changes_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pos_settings pos_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pos_settings
    ADD CONSTRAINT "pos_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_images product_images_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT "product_images_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_modifier_groups product_modifier_groups_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_modifier_groups
    ADD CONSTRAINT "product_modifier_groups_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public.modifier_groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_modifier_groups product_modifier_groups_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_modifier_groups
    ADD CONSTRAINT "product_modifier_groups_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_to_images product_to_images_imageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_to_images
    ADD CONSTRAINT "product_to_images_imageId_fkey" FOREIGN KEY ("imageId") REFERENCES public.product_images(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_to_images product_to_images_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_to_images
    ADD CONSTRAINT "product_to_images_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: products products_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "products_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: products products_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "products_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: qr_menu_settings qr_menu_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qr_menu_settings
    ADD CONSTRAINT "qr_menu_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT "stock_movements_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT "stock_movements_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT "stock_movements_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: subscription_payments subscription_payments_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT "subscription_payments_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT "subscriptions_planId_fkey" FOREIGN KEY ("planId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: subscriptions subscriptions_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT "subscriptions_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tables tables_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT "tables_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tenants tenants_currentPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT "tenants_currentPlanId_fkey" FOREIGN KEY ("currentPlanId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_notification_reads user_notification_reads_notificationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_reads
    ADD CONSTRAINT "user_notification_reads_notificationId_fkey" FOREIGN KEY ("notificationId") REFERENCES public.notifications(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_notification_reads user_notification_reads_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notification_reads
    ADD CONSTRAINT "user_notification_reads_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: waiter_requests waiter_requests_acknowledgedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waiter_requests
    ADD CONSTRAINT "waiter_requests_acknowledgedById_fkey" FOREIGN KEY ("acknowledgedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: waiter_requests waiter_requests_tableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waiter_requests
    ADD CONSTRAINT "waiter_requests_tableId_fkey" FOREIGN KEY ("tableId") REFERENCES public.tables(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: z_reports z_reports_closedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.z_reports
    ADD CONSTRAINT "z_reports_closedById_fkey" FOREIGN KEY ("closedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: z_reports z_reports_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.z_reports
    ADD CONSTRAINT "z_reports_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict a7IGwLf5jerC4bDbtqfnA9TQPwZaG9GVPzrHSGFYgc0SBlXQg5TlPridBhzQMFm

